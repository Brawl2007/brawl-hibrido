# Brawl Híbrido v62

Sinergias BrawlScope nos perfis com o mesmo formato de cartões dos counters: imagem, nome do aliado, percentagem, fonte e vista Geral/modo. Atalho Ver sinergias abaixo das métricas do brawler. O filtro identifica que controla counters e sinergias; as listas ficam juntas, antes da matriz completa de confrontos.

Mantidos os valores e cálculos da v61, as fontes e a atualização após publicação. Sem lista importada para a vista, o perfil informa a ausência de dados. Não foram inventadas sinergias.

Substitui o ZIP anterior na raiz do GitHub por este. Mantém o mesmo MySQL para recuperar os dados guardados. A troca de ZIP não atualiza os valores da fonte; novos valores BrawlScope dependem de importar e publicar nova captura.

Validação: verificação de tipos/imports e build local. Sem publicação ou validação visual no Render.
