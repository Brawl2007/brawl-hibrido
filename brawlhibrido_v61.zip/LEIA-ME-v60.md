# Brawl Híbrido v60

Substitui o ZIP antigo na raiz do GitHub por brawlhibrido_v60.zip. Mantém apenas um ZIP na raiz; o Render extrai o projeto no build.

## Sinergias BrawlScope

- Geral e cada modo têm listas independentes, no perfil e no Draft.
- Uma vista sem sinergias publicadas não reutiliza a lista geral nem o catálogo antigo.
- Um valor publicado de 0% não se transforma num bónus padrão.
- Publicar a importação atualiza a consulta do site; voltar à janela também permite recuperar atualizações perdidas.
- O limite contextual e a prioridade de composição do mapa continuam a aplicar-se ao cálculo final.

Para atualizar os valores, importa um novo JSON de resultados e clica em Publicar fichas. No Draft, escolhe a leitura Geral ou Por modo pretendida. Um JSON antigo continua a conter os valores da captura antiga.

A recolha automática permanece com a configuração da v59. Publicar uma importação não depende de ativar essa recolha, mas requer que o banco aceite gravações. Esta versão não libera espaço no MySQL nem altera o plano do Render.

Validação local: 23 testes passaram; 1 teste opcional de ficheiro externo foi ignorado. Verificação de tipos/imports e build de produção concluídos. Sem validação no Render ou no banco de produção.
