# Brawl Híbrido v61

## Instalar
Substitui o ZIP anterior na raiz do GitHub por brawlhibrido_v61.zip. Mantém apenas um ZIP na raiz. O Render extrai e compila; não precisas extrair no Chromebook.

## Dados já importados
As fichas são gravadas no MySQL, fora do ZIP. Corrigida a recuperação quando as matrizes já tinham sido carregadas antes das fichas. A importação agora recupera as fichas guardadas antes de adicionar outro lote.

Mantém a mesma DATABASE_URL. Trocar o ZIP não requer importar de novo um JSON já gravado e publicado. Se o MySQL estiver cheio, desligado, ou tiver sido trocado/apagado, o ZIP não consegue recuperar dados que o banco não guardou. Guarda os teus JSON como cópia de segurança.

## Rotação ranqueada e novos brawlers
A ranqueada atualiza 30 segundos após arrancar e depois a cada hora enquanto o servidor está a correr. Isto funciona por padrão mesmo com BRAWL_LIVE_SYNC_ENABLED=false. BRAWL_RANKED_SYNC_ENABLED=false desativa esta atualização separada. O botão Atualizar agora continua disponível.

Corrigidos filtros fixos no servidor e no catálogo de mapas do cliente que excluíam mapas novos. A leitura passa a seguir o roster publicado. Índice incompleto preserva a última snapshot guardada. Mapas novos precisam de estatísticas para entrar nas recomendações. Novos nomes publicados nas tabelas de estatísticas são aceites; o catálogo oficial completo exige BRAWL_STARS_API_KEY válida. Classe, alcance e counters novos ainda dependem de dados disponíveis; não são inventados.

A atualização de ranqueada não recolhe automaticamente o BrawlScope. Counters e sinergias BrawlScope continuam a usar a última importação publicada; novos valores requerem nova captura. A disponibilidade das fontes, espaço no banco e servidor ativo são condições necessárias. Nenhum código garante futuras mudanças de formato de sites externos.

## Mid e Lanes 1×1
Resumo visível de pontos finais, base, ajuste em pontos e percentagem, lado a lado. Counters, fontes e cálculo completo ficam numa secção expansível. Sem bibliotecas ou animações adicionais.

## Validação
Testes locais de persistência/reinício, rotação, novos mapas/brawlers, importação e agendamento. Verificação TypeScript e build de produção. Não publicado nem testado no Render/MySQL de produção.
