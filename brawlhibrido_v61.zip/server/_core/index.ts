import { VERSAO_DO_SITE } from "@shared/version";
import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { handleCounterSyncScheduled, handleRankedSyncScheduled } from "../scheduled";
import { handleObservedMatchCollectionScheduled } from "../observedMatchScheduled";
import { getPublicCounterSyncSnapshot } from "../counterSync";
import { getNextRefreshAt, getPublicRankedSnapshot } from "../rankedSync";
import { addCounterClient, addRankedClient } from "../realtime";
import { getLiveSyncState, startLiveSync } from "../liveSync";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  app.post("/api/scheduled/rankedSync", handleRankedSyncScheduled);
  app.post("/api/scheduled/counterSync", handleCounterSyncScheduled);
  app.post("/api/scheduled/observedMatchCollection", handleObservedMatchCollectionScheduled);
  app.get("/api/realtime/status", (_req, res) => {
    res.json(getLiveSyncState());
  });
  app.get("/api/realtime/ranked", async (_req, res) => {
    res.status(200).set({
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    });
    res.flushHeaders();
    let disconnected = false;
    res.once("close", () => { disconnected = true; });
    const snapshot = await getPublicRankedSnapshot();
    if (disconnected) return;
    const capturedAt = snapshot.capturedAt ? new Date(snapshot.capturedAt) : null;
    res.write(`event: ranked_snapshot\ndata: ${JSON.stringify({
      version: snapshot.version,
      capturedAt: snapshot.capturedAt,
      syncState: snapshot.version === "bundled-static" ? "bundled" : "success",
      nextRefreshAt: getNextRefreshAt(capturedAt)?.toISOString() ?? null,
      sourceStatus: snapshot.sourceStatus,
      sourceNotes: snapshot.sourceNotes,
      rowCount: snapshot.rowCount,
      payload: snapshot.payload,
    })}\n\n`);
    const removeClient = addRankedClient(res);
    const heartbeat = setInterval(() => res.write(": heartbeat\n\n"), 25_000);
    res.on("close", () => {
      clearInterval(heartbeat);
      removeClient();
    });
  });
  app.get("/api/realtime/counters", async (_req, res) => {
    res.status(200).set({
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    });
    res.flushHeaders();
    let disconnected = false;
    res.once("close", () => { disconnected = true; });
    const snapshot = await getPublicCounterSyncSnapshot();
    if (disconnected) return;
    if (snapshot) {
      /**
       * As quebras de linha aqui são significativas: o protocolo SSE separa os
       * campos com `\n` e fecha cada evento com uma linha em branco. Estavam
       * escritas como `\\n`, o que envia uma barra invertida literal — o
       * browser nunca via o fim do evento e o primeiro instantâneo de counters
       * nunca chegava ao Draft.
       */
      res.write(`event: counter_snapshot\ndata: ${JSON.stringify({ version: snapshot.version, capturedAt: snapshot.capturedAt, payload: snapshot.payload })}\n\n`);
    }
    const removeClient = addCounterClient(res);
    const heartbeat = setInterval(() => res.write(": heartbeat\n\n"), 25_000);
    res.on("close", () => {
      clearInterval(heartbeat);
      removeClient();
    });
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = parseInt(process.env.PORT || "3000", 10);

  server.listen(port, () => {
    /**
     * A versão no arranque.
     *
     * É a primeira linha a procurar num registo de publicação: diz de imediato
     * se o que subiu é o que se esperava, sem ter de abrir o site nem comparar
     * datas de ficheiros.
     */
    console.log(`[Brawl Híbrido] Versão ${VERSAO_DO_SITE} em execução.`);
    console.log(`Server running on http://localhost:${port}/`);
    startLiveSync();
  });
}

/**
 * Uma falha na recolha não pode derrubar o site.
 *
 * A recolha corre em segundo plano, fora de qualquer pedido. Desde o Node 18,
 * uma promessa rejeitada sem tratamento MATA o processo — e um processo morto é
 * exatamente o que o utilizador vê como "Service Unavailable" em todas as
 * páginas, incluindo as que não precisavam de recolha nenhuma.
 *
 * Este site serve estatísticas em leitura. Ficar de pé com uma fonte em falta é
 * sempre melhor do que ir abaixo por causa dela. Por isso as duas classes de
 * falha de fundo passam a ser registadas em vez de fatais — e ficam bem
 * visíveis no log, para não se tornarem silenciosas.
 */
process.on("unhandledRejection", (motivo) => {
  console.error("[Processo] Promessa rejeitada sem tratamento; o servidor continua ativo:", motivo);
});

process.on("uncaughtException", (erro) => {
  console.error("[Processo] Exceção não tratada; o servidor continua ativo:", erro);
});

startServer().catch((erro) => {
  // Aqui sim é fatal: sem servidor não há nada para servir. Falhar com uma
  // mensagem clara é melhor do que ficar meio de pé a responder erros.
  console.error("[Arranque] O servidor não conseguiu arrancar:", erro);
  process.exit(1);
});
