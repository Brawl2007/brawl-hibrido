# Brawl Híbrido v58 — coleta e importação mais rápidas

Base: brawlhibrido_v57_render_fix.zip enviado em 14/09. Mantidas as alterações do projeto recebido, incluindo as de Render.

O que muda
- Extensão avança com o carregamento da página e um temporizador de 2 segundos. O alarme de 30 segundos serve apenas para recuperação do worker. Continua a recolher uma página de cada vez e pausa em bloqueios/verificações.
- Importação de até 20 fichas por gravação. 756 fichas exigem 38 grupos em vez de 756 gravações da snapshot. O progresso só avança após confirmação; reabrir o mesmo JSON retoma o checkpoint.
- Publicar fichas passa a usar os resultados importados, sem recolher novamente BrawlScope, Brawl Planet ou PL Prodigy. Só confirma sucesso depois de gravar e notifica os clientes.
- A publicação substitui apenas os brawlers/vistas capturados, incluindo as listas de sinergia. Preserva outras vistas e outras fontes.
- Login do dono por palavra-passe e sessão assinada deixa de depender de MySQL. Importar/publicar continuam a exigir banco disponível.

Como atualizar
1. Exporta e guarda os resultados da extensão atual; pausa a coleta.
2. Substitui o ZIP antigo no GitHub por este, mantendo apenas um ZIP na raiz. Não precisas extrair o projeto no Chromebook.
3. Após o Render mostrar v58, abre Importação em lote e clica Baixar extensão v58.
4. Para a extensão, é necessário extrair esse pequeno ZIP. Substitui os ficheiros na MESMA pasta da extensão instalada e clica Recarregar em chrome://extensions. Não desinstales a extensão para não apagar o progresso.
5. Retoma a fila ou carrega uma nova. Os JSON anteriores continuam compatíveis.

Limites
- Não foi medida uma coleta completa no BrawlScope real. O tempo depende do navegador, da fonte e do banco; não existe promessa de duração fixa.
- Fichas sem dados e respostas bloqueadas continuam pendentes; nenhuma informação é inventada.
- Os valores não se atualizam sozinhos enquanto não fizeres nova coleta e importação.

Validação: TypeScript/imports/CSS e build aprovados; 42 testes de servidor e 5 testes da extensão aprovados. Um teste opcional dependente de arquivo externo não executado.
