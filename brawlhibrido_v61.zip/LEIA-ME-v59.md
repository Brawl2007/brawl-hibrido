# v59 — contenção de disco e memória

Dois problemas distintos: Aiven MySQL sem disco pode recusar gravações; Render sem RAM reinicia o processo. Este ZIP reduz trabalho e crescimento futuros, mas não libera o disco já ocupado nem muda o plano contratado.

Mudanças
- Coleta automática passa a ser opt-in: BRAWL_LIVE_SYNC_ENABLED=true. Por padrão, atualização manual. A restauração das fichas guardadas continua funcionando com a coleta automática desligada.
- Auditoria adicional de cada ciclo passa a ser opt-in: BRAWL_EVIDENCE_HISTORY_ENABLED=true. A snapshot atual mantém as relações e suas fontes. Nenhum histórico existente é apagado.
- Coleta de mapas limitada a duas páginas por fonte, em vez de todos os mapas simultaneamente. Coletas de counters também usam duas tarefas por grupo.
- Clientes SSE lentos/desconectados não ficam acumulando snapshots ou temporizadores.
- Mantidas importação em grupos, publicação local e login da v58.

Ação imediata no Render
Em Environment, define BRAWL_LIVE_SYNC_ENABLED=false e BRAWL_EVIDENCE_HISTORY_ENABLED=false. Guarda e reimplanta. Isso também prevalece sobre variáveis antigas configuradas explicitamente como true. Atualizar só o render.yaml dentro do ZIP não altera automaticamente as variáveis de um serviço já criado.
Substitui o ZIP antigo pelo v59 no GitHub, deixando apenas um ZIP na raiz. A extensão v58 continua compatível e não precisa ser reinstalada.

Disco MySQL
Pausa importações enquanto a gravação estiver bloqueada. Guarda os JSON exportados.
O arquivo scripts/diagnostico-disco.sql contém apenas SELECT: identifica modo somente leitura e tamanhos estimados das tabelas. Não executa limpeza.
Não apagues tabelas, não desatives proteção de escrita e não executes OPTIMIZE TABLE às cegas. A otimização pode precisar de espaço adicional. Se as tabelas não explicarem o espaço, verifica logs/arquivos do serviço com o suporte Aiven.
Os próximos passos dependem dos tamanhos e de um backup: limpeza seletiva autorizada ou aumento de capacidade. Nenhuma dessas ações foi executada.

Fontes oficiais consultadas
https://aiven.io/docs/products/mysql/howto/prevent-disk-full
https://aiven.io/docs/products/mysql/howto/identify-disk-usage-issues
https://aiven.io/docs/products/mysql/howto/reclaim-disk-space
https://render.com/docs/service-metrics

Validação: 10 testes direcionados aprovados; TypeScript, imports, CSS e build aprovados. Não houve acesso aos painéis, banco de produção ou medições de RAM do Render. Não há garantia de que esta alteração, sozinha, elimine todas as causas de falta de memória.
