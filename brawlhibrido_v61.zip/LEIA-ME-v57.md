# Brawl Híbrido v57

- Comparação percentual dos pontos das equipas e duelos brawler contra brawler (mid e lanes) novamente visíveis, fora do painel recolhido.
- Atalho «Comparar pontos % · Mid e Lanes» junto ao contexto do tabuleiro.
- Cartões compactos mostram o ajuste em pontos e em percentagem.
- Configuração da sequência continua recolhida separadamente.

A mudança restaura a apresentação; não altera fórmulas, fontes ou pesos. Verificação de código e build executados. Conferência visual no Chromebook ainda necessária.

Substitua o ZIP antigo por este no GitHub, mantendo apenas um ZIP. Não precisa extrair. Confirme v57 após o deploy do Render.
