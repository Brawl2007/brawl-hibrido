import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { brawlScopeSlugFromName } from "@shared/brawlScopeSlugs";

/**
 * A FILA DE COLAGEM
 *
 * Com o BrawlScope a recusar qualquer servidor, quem traz estes números é uma
 * pessoa — e são 106 brawlers vezes sete vistas. A pessoa não sai do meio; o
 * que sai é o trabalho inútil à volta de cada passagem: escolher o modo de cada
 * vez, carregar num botão, e lembrar-se de cor por onde ia.
 */
const ler = (caminho: string) => readFileSync(resolve(process.cwd(), caminho), "utf-8");

describe("fila de colagem", () => {
  const fila = () => ler("client/src/components/FilaDeColagem.tsx");

  it("o servidor diz QUAIS já foram coladas, não só quantas", () => {
    const counterSync = ler("server/counterSync.ts");
    expect(counterSync).toContain("export function getBrawlScopeColagemFeita");
    const routers = ler("server/routers.ts");
    expect(routers).toMatch(/colagemFeita: publicProcedure/);
  });

  it("guarda assim que se cola, sem botão pelo meio", () => {
    const fonte = fila();
    expect(fonte).toContain("importar.mutate({ html: texto, view: vista })");
    // Guardado dentro de um efeito sobre o texto: é a chegada do texto que
    // dispara, não um clique.
    expect(fonte).toMatch(/useEffect\(\(\) => \{[\s\S]{0,400}importar\.mutate/);
  });

  it("não dispara duas vezes com a mesma colagem", () => {
    const fonte = fila();
    expect(fonte).toContain("importar.isPending) return");
  });

  it("devolve o cursor à caixa depois de guardar", () => {
    expect(fila()).toContain("caixaRef.current?.focus()");
  });

  it("ordena por pontuação, não por alfabeto — parar a meio deixa o melhor feito", () => {
    const fonte = fila();
    expect(fonte).toContain("melhorPontuacao");
    expect(fonte).toMatch(/pontosB - pontosA/);
  });

  it("o endereço da próxima ficha leva o modo escolhido", () => {
    const fonte = fila();
    expect(fonte).toContain("brawlscope.com/counters/");
    expect(fonte).toMatch(/vista === "overall" \? "" : `\?mode=\$\{vista\}`/);
  });

  it("o endereço usa o slug do projeto, com as exceções conhecidas", () => {
    // "Larry & Lawrie" tem um endereço que não sai do nome por regra nenhuma.
    expect(brawlScopeSlugFromName("Larry & Lawrie")).toBe("larry-lawrie");
    expect(brawlScopeSlugFromName("8-Bit")).toBe("8-bit");
    expect(brawlScopeSlugFromName("Mr. P")).toBe("mr-p");
    expect(fila()).toContain("brawlScopeSlugFromName");
  });

  it("não faz um único pedido ao BrawlScope — quem abre a página é a pessoa", () => {
    const fonte = fila();
    expect(fonte).not.toMatch(/\bfetch\s*\(/);
    expect(fonte).not.toMatch(/axios/);
    // A ligação é um <a> que a pessoa carrega, num separador dela.
    expect(fonte).toContain('target="_blank"');
  });

  it("está montada no Draft", () => {
    expect(ler("client/src/pages/Draft.tsx")).toContain("<FilaDeColagem />");
  });
});

/**
 * O CICLO SEM FIM
 *
 * A colagem guardava sozinha com uma condição só: "há texto e não está a
 * correr". Quando uma leitura falhava, o texto ficava na caixa e o "a correr"
 * voltava a falso — as duas condições reuniam-se outra vez e a mesma ficha era
 * enviada de novo, e de novo, tantas vezes por segundo quantas o navegador
 * aguentasse. Uma ficha que falhasse chegava para pendurar o painel inteiro.
 *
 * Foi o que aconteceu ao abrir o Estado das fontes.
 */
describe("a colagem automática não se repete", () => {
  const fila = () => ler("client/src/components/FilaDeColagem.tsx");

  it("guarda o texto já enviado e não o manda outra vez", () => {
    const fonte = fila();
    expect(fonte).toContain("jaEnviado");
    expect(fonte).toMatch(/if \(pronto === jaEnviado\.current\) return;/);
    // A marca é posta ANTES do envio: entre marcar e enviar não pode haver
    // espaço para um segundo desenho entrar pelo meio.
    const efeito = fonte.slice(fonte.indexOf("const pronto = texto.trim()"));
    expect(efeito.indexOf("jaEnviado.current = pronto")).toBeLessThan(efeito.indexOf("importar.mutate"));
  });

  it("a marca é levantada quando a ficha fica guardada", () => {
    const fonte = fila();
    const sucesso = fonte.slice(fonte.indexOf("onSuccess"), fonte.indexOf("onError"));
    expect(sucesso).toContain('jaEnviado.current = ""');
  });

  it("a referência é criada antes de quem a usa", () => {
    const fonte = fila();
    expect(fonte.indexOf("const jaEnviado = useRef")).toBeLessThan(fonte.indexOf("jaEnviado.current"));
  });
});

/**
 * DUAS COISAS COM O MESMO NOME
 *
 * A rota devolvia `views` com os NOMES já colados e, na mesma linha, espalhava
 * a cobertura — que traz um `views` seu, com CONTAGENS. O segundo apagava o
 * primeiro sem um aviso, e o ecrã ia percorrer uma lista que afinal era
 * `{ profiles, pairs }`:
 *
 *     TypeError: ((intermediate value) ?? []).map is not a function
 *
 * E não caiu só o painel: levou o Draft inteiro atrás.
 */
describe("os nomes colados e as contagens não se pisam", () => {
  it("cada um vai no seu campo, sem espalhar por cima do outro", () => {
    const routers = ler("server/routers.ts");
    const rota = routers.slice(routers.indexOf("colagemFeita: publicProcedure"));
    const bloco = rota.slice(0, 300);
    expect(bloco).toContain("feitas: getBrawlScopeColagemFeita()");
    expect(bloco).toContain("cobertura: getBrawlScopeMatchupCoverage()");
    // Espalhar a cobertura à solta é o que criava a colisão.
    expect(bloco).not.toContain("...getBrawlScopeMatchupCoverage()");
  });

  it("o painel confirma que recebeu uma lista antes de a percorrer", () => {
    const fila = ler("client/src/components/FilaDeColagem.tsx");
    expect(fila).toContain("Array.isArray(valor) ? valor : []");
    // Nada percorre a resposta do servidor sem passar por essa confirmação.
    expect(fila).not.toMatch(/progresso\.data\?\.feitas\?\.\[[^\]]+\] \?\? \[\]\)\.map/);
  });

  it("a devolver nomes, devolve mesmo nomes", () => {
    const counterSync = ler("server/counterSync.ts");
    const funcao = counterSync.slice(counterSync.indexOf("export function getBrawlScopeColagemFeita"));
    expect(funcao.slice(0, 400)).toContain("Object.keys(perfis).sort()");
  });
});
