/**
 * Linha de montagem para colar as fichas do BrawlScope.
 *
 * POR QUE ISTO EXISTE
 *
 * O BrawlScope responde 403 a qualquer servidor, e isso não vai ser contornado.
 * A consequência é que a única forma de trazer estes números é uma pessoa abrir
 * a página e copiá-la — 106 brawlers vezes sete vistas, se fosse tudo.
 *
 * Não dá para tirar a pessoa do meio. Dá para fazer com que cada passagem custe
 * três teclas em vez de uma dúzia de cliques, e para o site saber por onde vai:
 *
 *  - diz qual é a PRÓXIMA ficha e abre-a num clique;
 *  - guarda assim que se cola, sem botão nenhum pelo meio;
 *  - avança sozinho e volta a pôr o cursor na caixa, pronto para a seguinte;
 *  - marca o que já está feito, para ninguém repetir nem saltar.
 *
 * A ordem não é alfabética: é pela pontuação na rotação ativa. Quem decide
 * drafts primeiro entra primeiro, e parar a meio deixa sempre o melhor feito.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useRankedSync } from "@/contexts/RankedSyncContext";
import { brawlScopeModes } from "@shared/brawlScopeModes";
import { brawlScopeSlugFromName } from "@shared/brawlScopeSlugs";

const VISTAS = [{ id: "overall", label: "Geral" }, ...brawlScopeModes.map((modo) => ({ id: modo.id as string, label: modo.label }))];

const normalizar = (nome: string) => nome.trim().toLocaleLowerCase().replace(/[^a-z0-9]+/g, "");

function enderecoDaFicha(brawler: string, vista: string) {
  const slug = brawlScopeSlugFromName(brawler);
  return `https://brawlscope.com/counters/${slug}${vista === "overall" ? "" : `?mode=${vista}`}`;
}

export default function FilaDeColagem() {
  const rankedSync = useRankedSync();
  const utils = trpc.useUtils();
  const [vista, setVista] = useState("overall");
  const [texto, setTexto] = useState("");
  const [ultima, setUltima] = useState<string | null>(null);
  const caixaRef = useRef<HTMLTextAreaElement | null>(null);
  /** O texto que já foi enviado. Ver a nota no efeito que guarda a ficha. */
  const jaEnviado = useRef("");

  const progresso = trpc.counterSync.colagemFeita.useQuery(undefined, { staleTime: 10_000 });

  /**
   * O roster por ordem de importância: melhor pontuação primeiro.
   *
   * Alfabético seria arbitrário — quem parasse a meio ficaria com metade do
   * alfabeto e nenhuma garantia de ter os brawlers que joga.
   */
  const roster = useMemo(() => {
    const melhorPontuacao = new Map<string, number>();
    for (const linha of rankedSync.snapshot?.rows ?? []) {
      const atual = melhorPontuacao.get(linha.brawler) ?? -Infinity;
      if (linha.score > atual) melhorPontuacao.set(linha.brawler, linha.score);
    }
    for (const brawler of rankedSync.snapshot?.officialBrawlers ?? []) {
      if (!melhorPontuacao.has(brawler.name)) melhorPontuacao.set(brawler.name, -1);
    }
    return Array.from(melhorPontuacao.entries())
      .sort(([nomeA, pontosA], [nomeB, pontosB]) => pontosB - pontosA || nomeA.localeCompare(nomeB))
      .map(([nome]) => nome);
  }, [rankedSync.snapshot?.rows, rankedSync.snapshot?.officialBrawlers]);

  /**
   * A lista do que já foi colado, com a forma confirmada antes de ser usada.
   *
   * Isto rebentou a página inteira uma vez: o servidor mandava, sem querer, um
   * objeto onde devia estar uma lista, e o `.map` aqui levou o Draft todo
   * atrás. Um painel que não consegue ler o que recebe deve ficar vazio e
   * deixar o resto do site funcionar — nunca derrubá-lo.
   */
  const nomesFeitos = (vistaId: string): string[] => {
    const valor = progresso.data?.feitas?.[vistaId];
    return Array.isArray(valor) ? valor : [];
  };

  const feitas = useMemo(
    () => new Set(nomesFeitos(vista).map(normalizar)),
    [progresso.data?.feitas, vista],
  );
  const emFalta = useMemo(() => roster.filter((nome) => !feitas.has(normalizar(nome))), [roster, feitas]);
  const proxima = emFalta[0];

  const importar = trpc.counterSync.importPage.useMutation({
    onSuccess: async (resultado) => {
      if (!resultado.ok) {
        toast.error("Não consegui ler essa página.", { description: resultado.error });
        return;
      }
      /**
       * O relatório diz sempre a conta completa.
       *
       * "103 confrontos" sozinho não distingue duas coisas muito diferentes: a
       * página só ter 103 — o que é normal, o número muda de brawler para
       * brawler — ou duas linhas terem-se colapsado numa por lerem o mesmo
       * nome. A segunda é um defeito, e tem de aparecer.
       */
      const repetidos = resultado.duplicated ?? [];
      const novos = resultado.unknownNames ?? [];
      setUltima([
        `${resultado.brawler} · ${resultado.pairs} confrontos`,
        repetidos.length ? `${repetidos.length} linha(s) repetida(s): ${repetidos.slice(0, 4).join(", ")}` : "",
        novos.length ? `nomes novos aceites: ${novos.join(", ")}` : "",
      ].filter(Boolean).join(" · "));
      setTexto("");
      // Guardada: a marca pode ser levantada, e a mesma ficha pode voltar a ser
      // colada noutra vista se for essa a intenção.
      jaEnviado.current = "";
      await Promise.all([progresso.refetch(), utils.counterSync.matchups.invalidate()]);
      // O cursor volta à caixa: a passagem seguinte é abrir a ficha e Ctrl+V.
      caixaRef.current?.focus();
    },
    onError: (erro) => toast.error(erro.message || "Não foi possível guardar a ficha."),
  });

  /**
   * Guardar assim que se cola.
   *
   * O botão "Guardar ficha" era mais um clique em cada uma de centenas de
   * passagens. Como a ficha traz sempre o nome do brawler lá dentro, não há nada
   * a perguntar: o texto chega, lê-se e guarda-se.
   *
   * O QUE CORRIA MAL SEM ESTA MARCA
   *
   * A condição era só "há texto e não está a correr". Quando uma leitura
   * falhava, o texto ficava na caixa e `isPending` voltava a falso — o que
   * reunia as duas condições outra vez, e mandava a mesma ficha de novo. E
   * outra vez. Um ciclo sem fim, a bater no servidor tantas vezes por segundo
   * quantas o navegador aguentasse, com a página a bloquear à vista de toda a
   * gente. Uma ficha que falhasse chegava para pendurar o painel inteiro.
   *
   * A marca guarda o texto que já foi enviado. O mesmo texto nunca vai duas
   * vezes: se falhou, falhou, e fica à espera de uma colagem diferente.
   */
  useEffect(() => {
    const pronto = texto.trim();
    if (pronto.length < 400 || importar.isPending) return;
    if (pronto === jaEnviado.current) return;
    jaEnviado.current = pronto;
    importar.mutate({ html: texto, view: vista });
  }, [texto, vista, importar.isPending]);

  const total = roster.length;
  const prontas = total - emFalta.length;

  return (
    <details className="paste-queue" open>
      <summary>Fila de colagem — {prontas} de {total} em {VISTAS.find((v) => v.id === vista)?.label}</summary>

      <div className="paste-queue-controls">
        <label>
          <span>Vista</span>
          <select value={vista} onChange={(evento) => setVista(evento.target.value)}>
            {VISTAS.map((v) => (
              <option key={v.id} value={v.id}>
                {v.label} ({nomesFeitos(v.id).length})
              </option>
            ))}
          </select>
        </label>
        <div className="paste-queue-bar" role="progressbar" aria-valuemin={0} aria-valuemax={total} aria-valuenow={prontas}>
          <span style={{ width: total ? `${(prontas / total) * 100}%` : "0%" }} />
        </div>
      </div>

      {proxima ? (
        <div className="paste-queue-next">
          <span className="paste-queue-step">1</span>
          <a href={enderecoDaFicha(proxima, vista)} target="_blank" rel="noreferrer">
            Abrir a ficha do <b>{proxima}</b>
          </a>
          <span className="paste-queue-hint">depois <b>Ctrl+A</b>, <b>Ctrl+C</b>, e <b>Ctrl+V</b> aqui em baixo</span>
        </div>
      ) : (
        <p className="paste-queue-done">Esta vista está completa: {total} de {total}.</p>
      )}

      <textarea
        ref={caixaRef}
        value={texto}
        onChange={(evento) => setTexto(evento.target.value)}
        rows={3}
        placeholder={importar.isPending ? "A ler…" : "Ctrl+V aqui — guarda sozinho"}
        spellCheck={false}
        aria-label="Colar a ficha"
      />

      {ultima && <p className="paste-queue-last">Guardada: {ultima}</p>}

      {emFalta.length > 1 && (
        <p className="paste-queue-upcoming">
          A seguir: {emFalta.slice(1, 6).join(", ")}
          {emFalta.length > 6 ? ` … e mais ${emFalta.length - 6}` : ""}
        </p>
      )}
    </details>
  );
}
