import { useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { brawlScopeCaptureFileSchema, type BrawlScopeCapture } from "@shared/brawlScopeCapture";

export function downloadJson(filename: string, value: unknown) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(value)], { type: "application/json" }));
  const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function ImportarLote({ urls }: { urls: string[] }) {
  const [profiles, setProfiles] = useState<BrawlScopeCapture[]>([]);
  const [index, setIndex] = useState(0);
  const [running, setRunning] = useState(false);
  const [status, setStatus] = useState("");
  const storageKey = useRef("");
  const stop = useRef(false);
  const busy = useRef(false);
  const importer = trpc.counterSync.importCapture.useMutation();
  const publisher = trpc.counterSync.publishCaptures.useMutation();
  const utils = trpc.useUtils();

  async function openFile(file?: File) {
    if (!file || busy.current) return;
    try {
      if (file.size > 50 * 1024 * 1024) throw new Error("O lote excede 50 MB.");
      const text = await file.text();
      const parsed = brawlScopeCaptureFileSchema.safeParse(JSON.parse(text));
      if (!parsed.success) throw new Error(`Lote inválido: ${parsed.error.issues[0]?.message}`);
      const hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)))).map(v => v.toString(16).padStart(2, "0")).join("");
      storageKey.current = `brawl-capture-v54:${hash}`;
      let saved = 0;
      try { saved = Number(localStorage.getItem(storageKey.current) || 0); } catch { /* importing still works without local storage */ }
      setProfiles(parsed.data.profiles);
      setIndex(Number.isInteger(saved) && saved >= 0 && saved <= parsed.data.profiles.length ? saved : 0);
      setStatus("Lote validado. Só avançamos depois da confirmação de gravação do servidor.");
    } catch (error) {
      setProfiles([]); setIndex(0); setStatus(error instanceof Error ? error.message : "Não consegui abrir o lote.");
    }
  }

  async function run() {
    if (busy.current) return;
    busy.current = true; stop.current = false; setRunning(true);
    let completed = index;
    let failed = false;
    try {
      for (let i = index; i < profiles.length && !stop.current; i++) {
        const profile = profiles[i];
        setStatus(`A guardar ${profile.brawler} · ${profile.view}`);
        const result = await importer.mutateAsync(profile);
        if (!result.ok || !result.persisted) throw new Error("A gravação não foi confirmada. A ficha fica pendente.");
        completed = i + 1; setIndex(completed);
        try { localStorage.setItem(storageKey.current, String(completed)); } catch { /* file can be reimported idempotently */ }
      }
      setStatus(completed === profiles.length ? "Todas as fichas deste lote foram guardadas." : "Pausado. Podes retomar neste ponto.");
    } catch (error) {
      failed = true;
      setStatus(`Parado em ${profiles[completed]?.brawler ?? "ficha"}: ${error instanceof Error ? error.message : "erro"}`);
    } finally {
      if (completed > index) {
        try {
          await publisher.mutateAsync();
          await Promise.all([utils.counterSync.colagemFeita.invalidate(), utils.counterSync.matchups.invalidate()]);
        } catch {
          if (!failed) setStatus("Fichas guardadas. A publicação nos perfis ficou pendente; usa Publicar fichas.");
        }
      }
      busy.current = false; setRunning(false);
    }
  }

  return <details className="paste-box">
    <summary>Importação em lote · v54</summary>
    <p className="paste-help">Exporta as fichas pendentes para a extensão. Depois carrega aqui o ficheiro de resultados e importa tudo, sem copiar e colar cada página.</p>
    <p><a href="/brawlscope-helper/README.txt" target="_blank" rel="noreferrer">Como instalar e usar a extensão</a></p>
    <div className="paste-actions">
      <button type="button" disabled={running || !urls.length} onClick={() => downloadJson("brawlscope-fila.json", { format: "brawlhibrido-queue-v1", urls })}>Exportar {urls.length} fichas pendentes</button>
      <label>Resultados da extensão <input type="file" accept=".json,application/json" disabled={running} onChange={e => void openFile(e.target.files?.[0])} /></label>
    </div>
    <p aria-live="polite">{index} / {profiles.length} fichas confirmadas. {status}</p>
    <div className="paste-actions">
      <button type="button" disabled={running || index >= profiles.length} onClick={() => void run()}>{index ? "Retomar importação" : "Importar lote"}</button>
      <button type="button" disabled={!running} onClick={() => { stop.current = true; setStatus("A pausar após a gravação em curso…"); }}>Pausar</button>
      <button type="button" disabled={running || publisher.isPending} onClick={() => void publisher.mutateAsync().then(() => setStatus("Publicação iniciada.")).catch(e => setStatus(String(e)))}>Publicar fichas</button>
    </div>
    <p className="paste-help">Mantém esta página aberta durante a importação. Se fechar, reabre o mesmo ficheiro para retomar. A extensão pode ser retomada separadamente. Não contorna 403 nem verificações.</p>
  </details>;
}
