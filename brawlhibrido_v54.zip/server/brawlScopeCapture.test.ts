import { beforeEach, describe, expect, it, vi } from "vitest";
import { brawlScopeCaptureSchema, type BrawlScopeCapture } from "../shared/brawlScopeCapture";

const db = vi.hoisted(() => ({ payload: "", persist: true }));
vi.mock("./db", () => ({
  getCounterSyncSnapshot: vi.fn(async () => ({ id: 1, payload: db.payload, version: "test" })),
  upsertCounterSyncSnapshot: vi.fn(async (snapshot) => { if (!db.persist) return undefined; db.payload = snapshot.payload; return snapshot; }),
}));
import { clearImportedBrawlScope, getBrawlScopeMatchupMatrix, importBrawlScopeCapture, persistMatchupMatricesNow, restoreBrawlScopeMatchupMatrices, toPublicCounterSnapshotPayload } from "./counterSync";

const profile = (): BrawlScopeCapture => ({
  url: "https://brawlscope.com/counters/bibi", brawler: "Bibi", view: "overall", capturedAt: "2026-09-13T01:00:00.000Z", expectedCount: 3,
  rows: [
    { opponent: "Bea", rate: 52.2, average: 46.7, delta: 5.5 },
    { opponent: "Frank", rate: 49.3, average: 49.3, delta: 0 },
    { opponent: "Wendy", rate: 49.1, average: 59.6, delta: -10.5 },
  ], counteredBy: [{ brawler: "Bea", delta: 5.5 }], targets: [{ brawler: "Wendy", delta: -10.5 }], synergies: [{ brawler: "Amber", delta: 10.1 }],
});
beforeEach(() => { clearImportedBrawlScope(); db.persist = true; db.payload = JSON.stringify({ schemaVersion: 2, capturedAt: "2026-09-13", relations: [], sourceStates: {} }); });
describe("v54 capture integrity", () => {
  it("preserves the published delta and zero without merging short names", () => {
    const p = profile(); p.rows[0] = { opponent: "Nita", rate: 58, average: 52.5, delta: 5.4 }; p.counteredBy = [{ brawler: "Nita", delta: 5.4 }];
    importBrawlScopeCapture(p);
    expect(getBrawlScopeMatchupMatrix("overall")?.Bibi).toEqual({ Nita: 5.4, Frank: 0, Wendy: -10.5 });
  });
  it.each([
    ["incomplete", (p: BrawlScopeCapture) => { p.expectedCount++; }],
    ["duplicate", (p: BrawlScopeCapture) => { p.rows[1] = p.rows[0]; }],
    ["wrong owner", (p: BrawlScopeCapture) => { p.brawler = "Lou"; }],
    ["wrong mode", (p: BrawlScopeCapture) => { p.view = "heist"; }],
    ["wrong rank", (p: BrawlScopeCapture) => { p.url += "?rank=all"; }],
    ["lookalike host", (p: BrawlScopeCapture) => { p.url = "https://evilbrawlscope.com/counters/bibi"; }],
    ["invalid URL", (p: BrawlScopeCapture) => { p.url = "not a URL"; }],
    ["bad delta", (p: BrawlScopeCapture) => { p.rows[0].delta = 20; }],
    ["wrong direction", (p: BrawlScopeCapture) => { p.targets = [{ brawler: "Bea", delta: 5.5 }]; }],
  ])("rejects %s before mutation", (_, mutate) => {
    const p = profile(); mutate(p);
    expect(brawlScopeCaptureSchema.safeParse(p).success).toBe(false);
    expect(() => importBrawlScopeCapture(p)).toThrow();
    expect(getBrawlScopeMatchupMatrix("overall")).toBeUndefined();
  });
  it("imports idempotently and preserves other modes and profiles", () => {
    importBrawlScopeCapture(profile());
    const second = { ...profile(), brawler: "Lou", url: "https://brawlscope.com/counters/lou?mode=heist", view: "heist" as const };
    importBrawlScopeCapture(second); importBrawlScopeCapture(profile());
    expect(Object.keys(getBrawlScopeMatchupMatrix("overall")!)).toEqual(["Bibi"]);
    expect(getBrawlScopeMatchupMatrix("heist")?.Lou).toBeDefined();
  });
  it("persists captures and preserves old matrix rows on restart", async () => {
    importBrawlScopeCapture(profile());
    expect((await persistMatchupMatricesNow()).saved).toBe(true);
    const saved = db.payload;
    clearImportedBrawlScope(); db.payload = saved;
    await restoreBrawlScopeMatchupMatrices();
    expect(getBrawlScopeMatchupMatrix("overall")?.Bibi.Wendy).toBe(-10.5);
    await persistMatchupMatricesNow();
    expect(JSON.parse(db.payload).browserCaptures[0].synergies).toEqual([{ brawler: "Amber", delta: 10.1 }]);
    expect(toPublicCounterSnapshotPayload(JSON.parse(db.payload))).not.toHaveProperty("browserCaptures");
  });
  it("does not report persistence when the database returns no snapshot", async () => {
    importBrawlScopeCapture(profile()); db.persist = false;
    expect((await persistMatchupMatricesNow()).saved).toBe(false);
  });
});
