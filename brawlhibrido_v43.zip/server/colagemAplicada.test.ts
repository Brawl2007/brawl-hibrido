import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

/**
 * DA COLAGEM ATÉ AO SCORE
 *
 * Colar uma ficha grava a matriz no servidor. Isso não chega: os números só
 * contam quando chegam ao Draft e ao perfil do brawler. Entre uma coisa e a
 * outra havia três pontos onde o caminho se cortava, e nenhum deles dava erro —
 * a pessoa colava, via "105 confrontos lidos", e depois não via mudar nada.
 */
const ler = (caminho: string) => readFileSync(resolve(process.cwd(), caminho), "utf-8");

describe("os valores colados chegam ao Draft e aos perfis", () => {
  it("o perfil do brawler carrega as matrizes, e não só o Draft", () => {
    const perfil = ler("client/src/pages/BrawlerDetail.tsx");
    expect(perfil).toContain("useBrawlScopeLiveMatchups");
    // O perfil lê os confrontos com getMatchupValue, que consulta essas matrizes.
    expect(perfil).toContain("getMatchupValue");
  });

  it("o perfil refaz-se quando uma matriz nova chega", () => {
    const perfil = ler("client/src/pages/BrawlerDetail.tsx");
    expect(perfil).toMatch(/matrizesVivas\.version/);
  });

  it("colar invalida todas as vistas, não só a geral", () => {
    const draft = ler("client/src/pages/Draft.tsx");
    // Sem isto, colar a ficha de um modo não mudava nada durante cinco minutos.
    expect(draft).toContain("utilsColagem.counterSync.matchups.invalidate()");
    const depoisDeColar = draft.slice(draft.indexOf("importPage.useMutation"));
    expect(depoisDeColar.slice(0, 900)).toContain("matchups.invalidate()");
  });

  it("apagar as fichas coladas também limpa as matrizes em cache", () => {
    const draft = ler("client/src/pages/Draft.tsx");
    const depoisDeApagar = draft.slice(draft.indexOf("clearImported.useMutation"));
    expect(depoisDeApagar.slice(0, 700)).toContain("matchups.invalidate()");
  });

  it("o hook pede um desenho novo depois de guardar as matrizes", () => {
    const hook = ler("client/src/lib/brawlScopeMatchups.ts");
    // As matrizes vivem fora do React: sem isto, quem lê durante o desenho em
    // que elas chegam ainda lê as antigas.
    expect(hook).toContain("setAplicadas");
    expect(hook).toMatch(/version: `\$\{aplicadas\}/);
  });

  it("a rota das matrizes é pública — o Draft lê-as sem sessão", () => {
    const routers = ler("server/routers.ts");
    expect(routers).toMatch(/matchups: publicProcedure/);
  });
});

/**
 * AS LISTAS DO PERFIL VÊM DA SNAPSHOT, NÃO DA MATRIZ
 *
 * São dois caminhos diferentes e só um deles era imediato. A matriz — de onde
 * saem as percentagens de cada confronto — recebia a ficha colada na hora. As
 * listas de counters que o perfil mostra vêm da snapshot publicada, e a
 * snapshot só se refaz quando corre um ciclo de recolha: até quinze minutos
 * depois, ou nunca, se o site reiniciasse pelo meio.
 *
 * Quem colava via os números certos no Draft e as listas antigas no perfil.
 */
describe("colar refaz a snapshot publicada", () => {
  it("a importação arranca a republicação em segundo plano", () => {
    const routers = ler("server/routers.ts");
    const importacao = routers.slice(routers.indexOf("importPage: protectedProcedure"));
    const bloco = importacao.slice(0, 2400);
    expect(bloco).toContain("startSyncJob(COUNTER_SYNC_JOB");
    expect(bloco).toContain("republishing");
  });

  it("não espera pela republicação para responder", () => {
    const routers = ler("server/routers.ts");
    const importacao = routers.slice(routers.indexOf("importPage: protectedProcedure"), routers.indexOf("clearImported:"));
    // `await startSyncJob(...)` deixava a caixa de colar parada minutos a fio —
    // exatamente o defeito que o botão "Atualizar agora" já teve.
    expect(importacao).not.toMatch(/await\s+startSyncJob/);
  });

  it("o trabalho em curso absorve uma segunda colagem em vez de duplicar a recolha", () => {
    const jobs = ler("server/syncJobs.ts");
    expect(jobs).toContain("alreadyRunning: true");
  });
});
