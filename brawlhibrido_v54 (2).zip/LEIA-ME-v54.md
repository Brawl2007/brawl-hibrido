# Brawl Híbrido v54

## Correção da importação do lote real

O arquivo brawlscope-resultados.json enviado pelo dono contém 707 fichas, 59.383 confrontos e 7.006 entradas de sinergia. A validação anterior rejeitava 21 fichas exclusivamente pelo sinal do delta de uma lista, embora esse delta coincidisse exatamente com a linha da matriz. A validação agora preserva a lista literal e o número publicado; continua verificando URL, modo, contagem, duplicações dentro das listas, correspondência com a matriz e coerência das percentagens.

As 707 fichas passaram pela validação corrigida sem nenhuma alteração nos seus campos. Um teste com banco simulado importou, persistiu e restaurou o lote inteiro e comparou todas as matrizes e capturas. Não foi feita importação em produção.

Publique este ZIP, atualize a página do Draft e selecione o MESMO brawlscope-resultados.json em Importação em lote. Não é preciso repetir a coleta nem reinstalar a extensão. Fichas inválidas futuras são separadas e identificadas, permitindo importar as válidas. O checkpoint acompanha a sequência validada; um checkpoint de uma versão anterior pode exigir reimportação idempotente.

O arquivo registra também 15 falhas de coleta, sem dados inventados: sete vistas de Cosmo, sete de Vince e Ollie em Roubo (sem lista de sinergia encontrada). Essas páginas não estão entre as 707 fichas recuperadas.

## Funções e bônus de ban

- Shade, Melodie e Cordelius passam a Lane; Rico passa a Flex.
- Conectado como dono, abra **Editar funções · Mid / Lane / Flex** no Draft, na lista de brawlers ou no perfil individual. Cada mudança fica na base de dados do site. Há busca e botão para restaurar o padrão de cada brawler.
- A edição recalcula filtros, composição e bônus de função do Draft sem apagar os picks. Outros navegadores abertos recebem a configuração na consulta periódica (30 segundos) ou ao voltar à janela.
- O bônus de ban passa a usar a união das listas literais de counters do BrawlScope e PL Prodigy (até dez por fonte). O mesmo ban conta uma vez; continua exigindo que o counter banido esteja no Top 25 por Score Híbrido base do mapa. Banir alguém que o candidato countera não ativa esse bônus.
- A edição de funções precisa de conexão com a base de dados. Uma falha na gravação é exibida e não confirma a mudança.
- Testes específicos: `npx vitest run server/draftCustomization.test.ts`.

Esta versão acrescenta coleta pelo Chrome e importação em lote à Fila de colagem, com progresso salvo e retomada. A fila pode incluir todos os brawlers e as sete vistas do site.

Correção do deploy no Render: a verificação de build compara uma assinatura SHA-256 do código, gravada no final da compilação, em vez das datas dos arquivos do ZIP. Assim, datas futuras não provocam outra compilação na inicialização. Arquivos alterados e assets em falta continuam detectados. Teste: `node --test scripts/ensure-build.test.mjs`.

Para destravar um deploy que já compilou com sucesso: no Render, Settings → Build & Deploy → Start Command, use `node dist/index.js` e salve. Faça o deploy novamente. Ao publicar este ZIP corrigido, também pode usar o comando original `node scripts/ensure-build.mjs && node dist/index.js`.

## Como usar

1. Publique o projeto atualizado seguindo `PUBLICAR.md`.
2. Instale a extensão local da pasta `client/public/brawlscope-helper` conforme o `README.txt` dessa pasta.
3. No Draft, exporte a fila em **Importação em lote**.
4. Carregue a fila na extensão, inicie e exporte os resultados.
5. Importe o JSON no Draft, conectado como dono do site.

A extensão lê páginas abertas normalmente pelo Chrome e pausa diante de bloqueios. Não contorna HTTP 403 ou CAPTCHA. A coleta real ainda precisa ser validada no navegador com o formato atual do BrawlScope.

## Validação desta entrega

- 55 testes de captura/importação e parser passaram.
- 11 testes locais da extensão passaram, com páginas e APIs do Chrome simuladas.
- Verificação TypeScript, imports e tokens CSS passou.
- Build de produção passou.

As fichas são validadas antes da importação; o avanço depende da confirmação de gravação. Deltas publicados, listas de counters e sinergias são preservados. A sincronização e a importação compartilham uma fila de gravação no processo do servidor.

Este ZIP contém o código atualizado. Não publica automaticamente o site nem atualiza dados de produção.
