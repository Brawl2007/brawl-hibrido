import { appRouter } from "./server/routers.ts";

const now = new Date();
const admin = {
  id: 1,
  openId: "owner-verification",
  email: "owner@example.com",
  name: "Owner Verification",
  loginMethod: "verification",
  role: "admin",
  createdAt: now,
  updatedAt: now,
  lastSignedIn: now,
};

const ctx = {
  user: admin,
  req: { protocol: "http", headers: {} },
  res: { clearCookie() {} },
};

const caller = appRouter.createCaller(ctx);
const refresh = await caller.rankedSync.refresh();
const snapshot = await caller.rankedSync.snapshot();
const status = await caller.rankedSync.status();

console.log(JSON.stringify({
  refresh: {
    ok: refresh.ok,
    version: refresh.version,
    rowCount: refresh.rowCount,
    sourceStatus: refresh.sourceStatus,
    sourceNotes: refresh.sourceNotes ?? null,
  },
  snapshot: {
    version: snapshot.version,
    rowCount: snapshot.rowCount,
    capturedAt: snapshot.capturedAt,
    sourceStatus: snapshot.sourceStatus,
    sourceNotes: snapshot.sourceNotes ?? null,
  },
  status: {
    lastStatus: status.lastStatus,
    snapshotVersion: status.snapshotVersion,
    rowCount: status.rowCount,
    runCount: status.runs.length,
  },
}, null, 2));

// The verification process must terminate after printing; the app itself keeps its
// database pool alive, but this one-shot check should not.
setTimeout(() => process.exit(0), 0);
