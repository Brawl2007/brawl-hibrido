# Publicação do Brawl Híbrido

Documento curto e prático. Se só leres uma coisa, lê o primeiro ponto.

## 1. O build tem de correr antes de servir

O repositório **não** inclui a pasta `dist/`. Isso é de propósito.

Antes, o projeto trazia um `dist/` compilado que já não correspondia ao
código-fonte. Servir essa pasta não dava erro nenhum — simplesmente publicava uma
versão antiga do site, e o `index.html` apontava para ficheiros `/assets/...` que
já não existiam, o que dá **ecrã branco**. Um deploy assim parece bem-sucedido.

Sequência correta:

```bash
pnpm install
pnpm build      # vite build (cliente) + esbuild (servidor)
pnpm start      # NODE_ENV=production node dist/index.js
```

`pnpm start` corre `scripts/ensure-build.mjs` antes de arrancar — encadeado com
`&&` dentro do próprio script, não como `prestart`, porque o pnpm ignora os
scripts `pre`/`post` por omissão desde a v7 e a guarda nunca chegaria a correr.
Essa guarda:

- reconstrói se `dist/` estiver em falta ou mais antigo que `client/`, `server/`
  ou `shared/`;
- confirma que todos os ficheiros `/assets/...` referidos pelo `index.html`
  existem mesmo — é esta verificação que apanha o ecrã branco;
- **falha com código de saída 1** se não conseguir reconstruir, em vez de deixar
  arrancar algo errado.

Para verificar sem arrancar o servidor: `pnpm verify:build`.

Se o pipeline já faz o build noutra etapa e a verificação estorva:
`SKIP_BUILD_CHECK=1 pnpm start`. Só usar isto sabendo que se está a abdicar da
rede de segurança.

> **Nota sobre as dependências:** o build precisa das `devDependencies`
> (vite, esbuild, typescript). Se o ambiente de produção instala só as
> `dependencies`, o build tem de acontecer **antes** dessa limpeza.

## 2. Variáveis de ambiente

| Variável | Para quê |
|---|---|
| `DATABASE_URL` | Ligação MySQL (Drizzle). |
| `SESSION_SECRET` | Assinatura do cookie de sessão. |
| `BRAWL_STARS_API_TOKEN` | API oficial, para dados de jogador. |
| `NODE_ENV` | `production` em publicação. |

### O cookie de sessão e o HTTPS

O login depende de o cookie de sessão ser aceite pelo browser. A regra que o
código aplica (`server/_core/cookies.ts`):

- **com HTTPS** → `SameSite=None; Secure` (permite o site em iframe/domínio
  próprio);
- **sem HTTPS** → `SameSite=Lax` sem `Secure`.

Isto importa porque `SameSite=None` **sem** `Secure` é silenciosamente
descartado por todos os browsers modernos — o utilizador faz login, o servidor
responde 200, e a sessão nunca existe. Se o site correr atrás de um proxy,
garantir que o cabeçalho `X-Forwarded-Proto` chega ao Express e que
`app.set("trust proxy", 1)` está ativo, ou a deteção de HTTPS falha.

## 3. Sincronização de dados

Arranca sozinha com o servidor (`server/liveSync.ts`) e repete de 15 em 15
minutos. Não é preciso configurar nada.

- O botão **"Atualizar agora"** força as 7 vistas do BrawlScope, ignorando a
  cache — é a diferença entre ver dados novos e rever os mesmos.
- Se uma fonte bloquear os pedidos, o servidor regista-o em `sourceHealth` e o
  site continua a funcionar com o catálogo do repositório. Não há queda.
- O estado aparece no Draft, por baixo do painel de recomendação.

### Os counters por modo demoram a aparecer — é normal

Num servidor acabado de publicar, com base de dados vazia, a leitura **"Por
modo"** começa a funcionar com o catálogo geral e só vai ficando completa ao
longo de cerca de **1h45m**.

Não é uma avaria. A recolha lê **uma vista por ciclo de 15 minutos** (Overall
mais os seis modos, sete ao todo), de propósito: são ~735 páginas por volta
completa, e ir mais depressa é pedir para a fonte bloquear os pedidos.

O que fazer: nada. Entretanto o painel das regras do Draft diz quantos perfis
cada modo já tem e quais estão em direto. Se não quiseres esperar, o botão
**"Atualizar agora"** força as sete vistas de uma vez.

A partir daí as matrizes ficam gravadas com a snapshot e são recarregadas no
arranque — **reiniciar o servidor deixou de custar essas duas horas**.

## 4. Antes de anunciar que está no ar

- [ ] `pnpm build` correu **nesta** versão do código.
- [ ] A página abre (não é ecrã branco) — confirma no DevTools que não há 404 em `/assets/`.
- [ ] O login funciona e sobrevive a um refresh da página.
- [ ] O Draft mostra sinergias do BrawlScope com valores em percentagem.
- [ ] O botão "Atualizar agora" muda a hora da última sincronização.
- [ ] A leitura "Por modo" ainda incompleta **não é problema** no primeiro dia (ver acima).
