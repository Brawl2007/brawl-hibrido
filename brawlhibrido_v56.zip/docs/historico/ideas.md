# Brawl Híbrido - Design & Architectural Concepts

## Approach Options

### 1. Brawl Stars Championship Arena (Selected)
- **Very Brief Intro**: A high-energy, immersive gamer aesthetic that mirrors official Brawl Stars esports broadcasts, featuring electric purples, cyan accents, dark carbon backgrounds, and bold arcade typography.
- **Probability**: 0.03

### 2. Starr Park Neon Terminal
- **Very Brief Intro**: A sleek, dark-mode terminal layout with neon green highlights and monospace data tables tailored for hardcore meta-analysts.
- **Probability**: 0.02

### 3. Retro Brawler Arcade
- **Very Brief Intro**: A nostalgic 8-bit arcade cabinet feel with vibrant primary colors, pixelated borders, and chunky retro buttons.
- **Probability**: 0.01

---

## Chosen Approach: Brawl Stars Championship Arena

- **Design Movement**: Modern Esports & Competitive Gaming UI
- **Core Principles**: 
  1. High visual contrast between dark carbon surfaces and vibrant neon tier badges (S, A, B).
  2. Instant data clarity through structured table cards and map selector tabs.
  3. Immersive feedback with smooth transitions and hover elevation.
- **Color Philosophy**: Deep dark slate background (`#0B0E14`) paired with electric violet (`#8B5CF6`), vibrant cyan (`#06B6D4`), and gold/amber highlights for Tier S items (`#F59E0B`).
- **Layout Paradigm**: Asymmetric top navigation header with live rotation stats, followed by a filterable map grid and a comprehensive data table with sorting and search capabilities.
- **Signature Elements**: Glowing border highlights, badge pills for Tiers, and mini progress bars representing Win Rate and Hybrid Score proportions.
- **Interaction Philosophy**: Snappy, tactile responses with subtle scaling on hover and instant client-side filtering.
- **Animation**: Fluid fade-ins and scale transitions powered by Tailwind and Framer Motion.
- **Typography System**: Headings in a bold display style (`Montserrat` / `Teko` via Google Fonts), body text in clean sans-serif (`Inter`).
- **Brand Essence**: The ultimate competitive intelligence hub for Ranked mode, built by players for players.
- **Brand Voice**: Sharp, analytical, energetic, and professional.
- **Wordmark & Logo**: A stylized "BH" emblem with a crown/star motif.
- **Signature Brand Color**: Electric Violet (`#7C3AED`).

## Style Decisions
- Use OKLCH color harmony for custom tier badges.
- Ensure 100% responsive layout for mobile phones (Google Sheets copy friendly).
- Include exact formula explanation modal for transparency.
- Repetir o emblema BH como selo de transmissão nos principais blocos, sem o reduzir a um ícone de navegação.
- Reservar âmbar/ouro para Tier S e elite, ciano para força/progresso e violeta elétrico para estados activos e identidade.
- Usar enquadramentos HUD angulares, linhas de arena e acentos luminosos para que a biblioteca de mapas e a tabela mantenham a energia do hero.
