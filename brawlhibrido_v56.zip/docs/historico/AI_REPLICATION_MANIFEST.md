# Manifeste de Reprodução por IA — Brawl Híbrido

Este documento serve como prompt/instrução direta para outra IA clonar, imitar e reconstruir exatamente a aplicação **Brawl Híbrido**, sem perder nenhuma regra de negócio, estilo visual ou dado construído.

---

## 1. Visão Geral da Aplicação
- **Nome**: Brawl Híbrido (Esports-Grade Dashboard & Draft Tool para Brawl Stars).
- **Estética Visual**: *Championship Arena* (superfícies carbono escuro, roxo elétrico `#8b5cf6`, ciano de telemetria `#06b6d4`, âmbar para Tier S `#f59e0b`, design assimétrico e orientado a dados).
- **Stack**: React 19, Tailwind CSS v4, tRPC 11, Drizzle ORM, Express, Vitest (77 testes).

---

## 2. Fórmulas Matemáticas e Regras de Negócio Críticas

### 2.1 Score Híbrido (Ranked)
$$\text{Score Híbrido} = (\text{Win Rate Brawl Planet} \times 0.80) + \left(\left(\frac{\text{Score TopBrawl}}{13}\right) \times 100 \times 0.20\right)$$

### 2.2 Motor de Draft (`shared/draft.ts`)
$$\text{Draft Score} = \text{Hybrid Score} + \text{Counter} + \text{Missing Mid} + \text{Missing Side} + \text{Ban} + \text{Opening} + \text{Synergy} - \text{Enemy Counter} - \text{Same Class} - \text{Worst Teammate}$$

- **Counters (Prodigy)**: $+10\%$ por counter literal face a inimigos visíveis.
- **Fit / Lane (Mid / Side)**: $+7\%$ se a brawler encaixar na posição necessária.
- **Ban Rate**: $+3\%$ a $+7\%$ por counter direto banido.
- **Opening / Long Range**: $+4\%$ para brawlers com alcance $>4$ ou $>8$ blocos nas primeiras escolhas.
- **Sinergia (Best Teammates - Brawl Planet)**: $+4\%$ por aliado sinérgico.
- **Desbônus de Enemy Counter**: $-5\%$ por brawler inimigo que seja counter literal do candidato.
- **Desbônus de Mesma Classe**: $-5\%$ por aliado já escolhido na mesma classe (ex: Tanks, Lançadores).
- **Desbônus de Worst Teammate**: $-5\%$ acumulativo por cada aliado na lista de sinergia negativa do Brawl Planet.

---

## 3. Fontes de Dados e Relacionamentos Multifuente (`shared/counterSourceRelations.ts`)
1. **Power League Prodigy**: Fonte primária e autoritária para counters de Draft.
2. **Brawl Planet**: Fornece *Best Teammates* (sinergia positiva), *Worst Teammates* (sinergia negativa com deltas), *Strong Against* e *Struggles Against*.
3. **Brawl Calculator**: Fornece explicações textuais (*tips/reasons*) exibidas no resumo do Draft e na Matriz 1v1.
4. **TopBrawl**: Fonte exclusiva de estatísticas de meta e win rates (sem listas diretas de counters).

### 3.1 Dicas Brawl Calculator — comportamento obrigatório
- `getBrawlCalculatorTips(atacante, defensor)` devolve apenas razões literais do par e preserva a direção atacante → defensor.
- Quando não existe relação direta para o par selecionado, `getBrawlCalculatorTipsForBrawler(brawler)` devolve as razões literais publicadas no perfil como fallback editorial, sem inventar texto.
- O Draft deve dar prioridade às dicas diretas e mostrar o fallback identificado como tal nas perspetivas Azul e Vermelha.
- A Matriz 1v1 deve apresentar a inteligência das duas perspetivas, incluindo a razão literal e a ligação à fonte Brawl Calculator; a ausência de matchup direto nunca deve resultar num painel vazio se o perfil tiver razões publicadas.

---

## 4. Estrutura de Ficheiros a Replicar
- `shared/draft.ts`: Motor de simulação de Draft, classes, bónus e penalidades.
- `shared/counterSourceRelations.ts`: Adaptador unificado multifuente.
- `client/src/pages/Draft.tsx`: Interface de Draft (equipas, bans, recomendações, Duelo Central 1v1).
- `client/src/pages/MatchupMatrix.tsx`: Matriz 1v1 por modo e mapa (limiar de $\ge 30$ partidas).
- `client/src/pages/BrawlerDetail.tsx`: Fichas individuais com Best/Worst Teammates e Counters.
- `server/draftEngine.test.ts` e `server/counterSourceRelations.test.ts`: Suite de 77 testes unitários e de regressão.

---

## 5. Instruções para a Nova IA
1. Lê este manifesto e importa a árvore de código contida no ZIP `brawl-hibrido-export.zip`.
2. Instala as dependências com `pnpm install`.
3. Executa a suite de testes com `pnpm test` (deve passar 77/77).
4. Compila o projeto com `pnpm build`.
5. Confirma visualmente `/draft` e `/matchups`; as razões do Brawl Calculator devem estar visíveis no painel de dicas.
6. Preserva rigorosamente a identidade visual *Championship Arena* e a lógica matemática descrita.
