# Guia Oficial de Preservação e Restuperação — Brawl Híbrido

A transição operacional da plataforma para operações independentes estabelece marcos temporais críticos que requerem atenção imediata para garantir a continuidade dos serviços, bases de dados e códigos associados ao projeto **Brawl Híbrido** [1]. Este documento sintetiza o plano de ação oficial, detalhando os procedimentos exigidos antes da janela de indisponibilidade que se inicia a **23 de agosto de 2026** [2].

---

## 1. Cronograma Operacional e Âmbito

O processo de separação e reestruturação de dados obedece rigorosamente às datas e horários operacionais descritos na tabela seguinte. É fundamental concluir todas as exportações antes do prazo limite para evitar a perda de dados.

| Marco Operacional | Data e Hora (SGT / GMT+8) | Descrição do Estado do Sistema |
| :--- | :--- | :--- |
| **Prazo Limite de Cópia de Segurança** | **23 de agosto de 2026, às 07:59** | Último momento em que a plataforma e a ferramenta de exportação permanecem totalmente acessíveis [2]. |
| **Período de Indisponibilidade** | **23 de agosto (08:00) a 25 de agosto (07:59)** | Os sites entram em modo de manutenção e o acesso direto às bases de dados e capacidades de IA fica temporariamente suspenso [2] [3]. |
| **Abertura da Restauração** | **25 de agosto de 2026, às 08:00** | Disponibilização do portal para importação dos pacotes de cópia de segurança e retoma automática dos serviços [2]. |

> «Affected users must complete the required backup before August 23 at 7:59 a.m. SGT using the Data Backup Tool.» [1]

---

## 2. Diferença Crítica: Código Fonte versus Cópia de Segurança de Tarefa (Task Data Backup)

Um erro comum durante processos de migração é assumir que descarregar apenas o código-fonte (ou clonar o repositório) é suficiente. Para aplicações full-stack baseadas em webdev como o **Brawl Híbrido**, o código isolado **não contém**:
1. A base de dados da aplicação e os seus registos persistidos [4].
2. Ficheiros e recursos carregados [4].
3. Variáveis de ambiente, segredos e chaves de API configuradas [4].
4. Configurações de integrações de terceiros e serviços alojados [4].

Por conseguinte, a única forma de garantir a recuperação integral do ecossistema é gerar um **Task Data Backup** oficial através da ferramenta de salvaguarda da plataforma [4].

---

## 3. Procedimento Passo a Passo para Salvar o Projeto

Para assegurar que o **Brawl Híbrido** seja integralmente preservado, execute os seguintes passos antes de 23 de agosto de 2026:

1. **Aceda à Ferramenta Oficial de Salvaguarda**: Visite o portal dedicado em [manus.im/backup](https://manus.im/backup) [1].
2. **Selecione a Exportação Abrangente**: Escolha a opção **Export task data → Export more → All tasks → All time → Start export** (ou em alternativa, a opção restrita a websites em **Custom export → Website tasks**) [5].
3. **Descarregue os Pacotes**: Certifique-se de guardar todos os ficheiros gerados num local seguro (como o seu computador pessoal ou armazenamento em nuvem de confiança). **Não modifique nem renomeie os pacotes**, pois a integridade estrutural é indispensável para a validação no momento da restauração [1].

> «Every export is a fixed point-in-time snapshot. For a website with live users, recommend regular Task Data exports during the backup window and one final fresh export as close to the deadline as practical.» [3]

---

## 4. Restauração e Comportamento dos Domínios

A partir das **08:00 de 25 de agosto de 2026**, o processo de restabelecimento do serviço decorre de forma célere desde que utilize o pacote correto [2]:

- **Carregamento do Pacote**: Aceda novamente a [manus.im/backup](https://manus.im/backup) após a abertura do portal e submeta o seu **Task Data Backup** [1]. A plataforma consolida e desduplica automaticamente múltiplos pacotes caso tenha efetuado exportações parceladas [1].
- **Retoma do Site**: O **Brawl Híbrido** será reconstruído internamente com o mesmo estado, código, segredos e base de dados vigentes no momento da última exportação [4].
- **Domínios e Endereços**: 
  - O subdomínio padrão `manus.space` (como `brawlhub-hv3h5xuy.manus.space`) volta a ficar ativo automaticamente após o redeploy [6].
  - Caso utilize um domínio personalizado, a associação é preservada; se necessário, poderá confirmar o apontamento DNS e reconfirmar a ligação no painel de gestão em **Settings → Domains** [6].

---

## 5. Referências

1. [Data Back Up and Restoration collection](https://help.manus.im/en/collections/19704025-data-back-up-and-restoration)
2. [What’s Happening and Am I Affected?](https://help.manus.im/en/articles/16147831-service-change-overview-what-s-happening-and-am-i-affected)
3. [How to Back Up Your Data](https://help.manus.im/en/articles/16147892-service-change-overview-how-to-back-up-your-data)
4. [Websites During the August 2026 Data Separation](https://help.manus.im/en/articles/16147892-service-change-overview-how-to-back-up-your-data)
5. [How to Restore Your Data](https://help.manus.im/en/articles/16147895-service-change-overview-how-to-restore-your-data)
6. [Welcome Back Bonus for Affected Users](https://help.manus.im/en/articles/16147914-service-change-overview-welcome-back-bonus-for-affected-users)
