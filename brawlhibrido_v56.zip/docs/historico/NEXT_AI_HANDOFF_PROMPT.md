# Prompt de Transferência Completo — Brawl Híbrido

> **Copia todo o bloco abaixo e entrega-o à próxima IA juntamente com o ZIP/exportação completa do projeto.** Este documento descreve o estado canónico do Brawl Híbrido em **16 de agosto de 2026**, depois do checkpoint `22225675`.

---

## Prompt para a próxima IA

Tu vais continuar o desenvolvimento de um projeto existente chamado **Brawl Híbrido**. Trata-o como um produto competitivo de Brawl Stars, não como um protótipo. Antes de fazer qualquer alteração, lê integralmente:

1. `NEXT_AI_HANDOFF_PROMPT.md` (este documento);
2. `TECHNICAL_ARCHITECTURE.md`;
3. `MIGRATION_GUIDE.md`;
4. `CONVERSATION_HISTORY_MEMORY.md`;
5. `AI_REPLICATION_MANIFEST.md`;
6. `todo.md`;
7. `visual_validation.md`.

O código vive em `/home/ubuntu/brawl-hibrido`. O último checkpoint conhecido é **`22225675`**. O domínio publicado anterior é `https://brawlhub-hv3h5xuy.manus.space`; numa nova conta será gerado outro domínio. **Nunca presumas que segredos, base de dados, sessões OAuth ou configurações de agendamento migram automaticamente.**

### 1. Objetivo do produto

O Brawl Híbrido é uma aplicação profissional para Ranked de Brawl Stars que junta:

| Área | Função obrigatória |
|---|---|
| Dashboard | Lista a rotação Ranked, mapas, modo, Score Híbrido, tiers e estatísticas de meta. |
| Draft | Simula bans e picks Azul/Vermelho, recomenda brawlers em tempo real e explica o impacto de cada decisão. |
| Brawlers | Fichas individuais com counters, quem countera, sinergias, sinergias negativas, dados por fonte e dicas. |
| Matriz 1v1 | Mostra confrontos por modo e mapa, com amostra mínima de 30 partidas observadas. |
| Sync | Usa dados publicados e dados oficiais quando disponíveis; mantém fallback seguro se uma fonte falhar. |

A estética deve continuar **Championship Arena**: fundo carbono/azul-noite, roxo elétrico como acento principal, ciano para telemetria, âmbar para Tier S, cartões densos e legíveis, layout profissional de esports e responsividade móvel. Não substituas esta identidade por um dashboard genérico claro.

### 2. Regras inegociáveis de dados

**Não inventes, completes automaticamente, simules ou hardcodes counters, sinergias, avaliações, reviews, taxas ou explicações.** Toda a relação precisa de origem literal e indicada na UI.

| Dado | Fonte canónica | Regra de utilização |
|---|---|---|
| Counter usado no motor de Draft | Power League Prodigy | Relação literal/direcional. Não criar fallback de counter. |
| Best Teammates / Worst Teammates | Brawl Planet | Melhor aliado é sinergia positiva; Worst Teammate gera penalização negativa. |
| Strong Against / Struggles Against | Brawl Planet | Exibir como relações da fonte, sem trocar direção. |
| Dicas táticas | Brawl Calculator | Priorizar dica direta atacante → defensor. Se não existir, só usar fallback editorial literal do perfil, identificado como fallback. |
| Win rate, score, uso e builds de meta | Brawl Planet e TopBrawl | Respeitar proveniência; TopBrawl não deve ser apresentado como fonte de listas diretas de counters. |
| Observações 1v1 | Logs/partidas Ranked oficiais acumuladas | Separar por modo e mapa; abaixo de 30 partidas, indicar amostra insuficiente. |

O catálogo de classes deve seguir a taxonomia oficial usada por `shared/draft.ts`. Há uma distinção importante: o catálogo de perfis/classes cobre **106 perfis públicos**, enquanto a tabela Ranked pode ter **105 linhas de brawlers** por mapa. Não alteres este comportamento para “forçar” a contagem sem primeiro auditar as fontes.

### 3. Fórmulas e lógica do Draft

O **Score Híbrido** de mapa é:

```text
Score Híbrido = (Win Rate Brawl Planet × 0,80) + ((Score TopBrawl / 13) × 100 × 0,20)
```

O motor central está em `shared/draft.ts`. A pontuação de recomendação é explicável: parte do score base e aplica bónus/penalidades contextuais. Não reescrevas a fórmula por intuição; consulta primeiro as constantes e as regressões no ficheiro.

| Sinal atual | Efeito base | Regra essencial |
|---|---:|---|
| Counter literal | +10% | Por inimigo que o candidato countera, usando Prodigy. |
| Fit de função | +7% | Para Mid/Side em falta; não duplicar um bónus por ter função flexível. |
| Counter banido | +3% | Aumenta quando o counter direto do candidato está banido. |
| Opening / alcance | +4% | Aplicável a condições de escolha inicial e alcance definidas no motor. |
| Sinergia | +4% | Por Best Teammate aliado literal de Brawl Planet. |
| Enemy Counter | −5% | Por inimigo pickado que countera literalmente o candidato. |
| Mesma classe | −5% | Por **Pick aliado** da mesma classe oficial. |
| Worst Teammate | −5% | Por aliado constante da lista Worst Teammates do candidato. É acumulativo. |

#### Regra crítica de picks versus bans

1. **Apenas Picks aliados** acionam o desbónus de mesma classe.
2. **Bans nunca** acionam ou explicam a penalização de mesma classe, enemy counter ou worst teammate.
3. O brawler banido tem de ficar indisponível para pick/recomendação na simulação atual.
4. O brawler já escolhido deve ser removido das recomendações.
5. As equipas Azul e Vermelha têm perspetivas próprias: nunca aplicar uma penalização de composição da equipa Azul à equipa Vermelha, ou vice-versa.

#### Visibilidade obrigatória das penalizações

O utilizador insistiu que não basta uma explicação escondida. A interface atual deve preservar os três níveis de explicação:

1. **Faixa de composição acima da lista de recomendações**: avisa a classe repetida, a percentagem e o Pick aliado ativador, por exemplo `DANO — −5% ativado por: Pearl`.
2. **Selo individual dentro de cada cartão afetado**: cada candidato da mesma classe mostra `DESBÓNUS DE CLASSE · −5%`, classe e ativadores, por exemplo `Ativado por: Pearl`.
3. **Bloco “Desbónus Totais” em cada cartão**: soma `Enemy Counter`, `Mesma Classe` e `Worst Teammate` em pontos e lista todos os brawlers que ativaram cada categoria.

Esta exibição é universal para **todas** as classes oficiais — incluindo Destruidor/Dano, Tank, Lançador, Assassino, Controlador, Artilheiro/Marksman, Suporte e Curador. Não implementes exceções somente para Pearl/Carl. Os exemplos Pearl, Carl, Bolt e Bo foram usados apenas para validação visual.

### 4. Estado mais recente do trabalho

O trabalho concluído mais recentemente foi a explicação de desbónus no Draft:

| Alteração recente | Estado |
|---|---|
| Correção do catálogo de classes e exclusão de bans | Concluída e regressivamente testada. |
| Aviso persistente de composição antes das recomendações | Concluído. |
| Selo de desbónus por mesma classe em cada cartão afetado | Concluído para todas as classes. |
| Soma de penalizações por cartão (Enemy Counter + Mesma Classe + Worst Teammate) | Concluída. |
| Nome/classe dos brawlers ativadores | Exibidos nas penalizações aplicáveis. |
| Regressão estrutural do total de penalizações | Adicionada em `server/draftEngine.test.ts`. |
| Validação mais recente | `pnpm test`: **84/84**; `pnpm build`: concluído. |

O último build pode necessitar de limitar a memória em ambientes pequenos. Se o build for terminado por falta de memória, para temporariamente o servidor de desenvolvimento e usa:

```bash
NODE_OPTIONS=--max-old-space-size=768 pnpm build
```

O aviso de chunk grande do Vite é um aviso de otimização, não um erro de compilação. Não quebres o build tentando resolver esse aviso sem necessidade.

### 5. Estrutura técnica e ficheiros que não podes ignorar

```text
client/src/
  App.tsx                         # Rotas e shell da aplicação
  index.css                       # Tema Championship Arena e estilos de cartões/chips
  pages/Home.tsx                  # Dashboard
  pages/Draft.tsx                 # Simulador, recomendações, alertas e cartões
  pages/MatchupMatrix.tsx         # Matriz 1v1 por modo/mapa
  pages/BrawlerDetail.tsx         # Página individual e relações por fonte

shared/
  draft.ts                        # Motor de scoring, sequência de draft, funções, classes e explicações
  counterSourceRelations.ts       # Adaptador literal de fontes e dicas direcionais
  brawlPlanetRelationData.ts      # Relações Brawl Planet
  brawlCalculatorCounterData.ts   # Dicas Brawl Calculator
  prodigyCounterData.ts           # Relações Prodigy
  observedMatchups.ts             # Dados da matriz observada

server/
  routers.ts                      # Procedimentos tRPC
  db.ts                           # Acesso a dados/Drizzle
  rankedSync.ts                   # Atualização das fontes
  draftEngine.test.ts             # Regressões do motor de Draft
  *.test.ts                       # Cobertura de dados, modos, sync e API

drizzle/
  schema.ts                       # Esquema de base de dados
  migrations/                     # Migrações
```

O projeto é React 19 + Tailwind 4 + Wouter no frontend e Express + tRPC 11 + Drizzle/MySQL no backend. Usa os procedimentos tRPC já existentes, não introduzas chamadas REST/adapters paralelos sem uma razão real. Para alterações de schema, altera `drizzle/schema.ts`, gera migração e aplica a SQL com o mecanismo controlado da plataforma.

### 6. Rotas, UI e comportamento competitivo

Preserva e testa estas áreas:

| Rota/área | Comportamento esperado |
|---|---|
| `/` | Dashboard com rotação, mapas/modos, scores, fontes e atualização manual. |
| `/draft` | Mapa/mode, lado inicial, sequência competitiva/customizada, skip bans, picks, pesquisa rápida, recomendações e explicações. |
| `/matchup-matrix` | Seleção de modo e mapa, linha 1v1, amostra/vitórias/derrotas, dicas de ambas as perspetivas. |
| `/brawlers` e detalhes | Relações por fonte, imagens, navegação cruzada e dicas. |

O Draft precisa continuar rápido no telemóvel: a pesquisa limpa após seleção, chips e tabelas devem quebrar corretamente sem esconder a informação de score/penalidade, e os controlos de pick/ban devem ficar visualmente próximos do tabuleiro.

### 7. Sincronização, API e segredos

Existe integração com a API oficial do Brawl Stars e mecanismos de sincronização/atualização. A chave relevante é `BRAWL_STARS_API_KEY`. **Nunca coloques tokens em código, documentação, logs, commits ou mensagens.** Se migrares de conta, pede/configura novamente o segredo através do mecanismo seguro da plataforma.

Quando a API oficial responde `403` ou uma fonte externa não responde, o comportamento correto é manter o último snapshot válido/fallback e comunicar indisponibilidade, sem apagar dados ou bloquear o Draft. Logs de `403` durante desenvolvimento não significam automaticamente que o motor de Draft está quebrado.

O projeto já teve sincronização programada de hora a hora e atualização manual. Antes de alterar qualquer agendamento, lê as instruções de periodic updates da plataforma e confirma a configuração/Heartbeat existente. Não cries loops em background no frontend.

### 8. Testes obrigatórios antes de publicar

```bash
pnpm install
pnpm test
pnpm build
```

O ponto de partida de regressão é **84/84 testes**. Se acrescentares uma funcionalidade ao Draft, cria ou atualiza testes em `server/draftEngine.test.ts` para a regra de negócio correspondente. Para alterações visuais relevantes, confirma pelo browser/screenshot em desktop e em móvel; se a automação visual falhar, regista a limitação e não inventes que a validação ocorreu.

Antes de publicar: atualiza `todo.md`, lê-o para verificar o estado, cria um checkpoint e comunica o checkpoint à pessoa utilizadora. O projeto usa publicação automática após checkpoint.

### 9. Migração para outra conta

1. Exporta/descarrega o código completo/ZIP e inclui este documento.
2. Cria um projeto full-stack compatível na nova conta e importa o repositório.
3. Configura segredos, especialmente `BRAWL_STARS_API_KEY`; os segredos, cookies OAuth e estado de runtime anterior não são portáteis.
4. Confirma a base de dados/migrações e recria a configuração de sincronização agendada, se necessária.
5. Executa testes e build antes do primeiro checkpoint/publicação.
6. Não reutilizes o domínio `manus.space` antigo como se fosse transferível; associa o novo domínio através do painel da nova conta.

### 10. Como trabalhar a partir daqui

Quando receberes um pedido de melhoria:

1. Explica brevemente o que vais fazer e confirma a interpretação se o pedido for ambíguo.
2. Regista a tarefa em `todo.md` antes de programar.
3. Consulta o motor e os testes antes de mexer em fórmulas/dados.
4. Não escondas uma explicação importante dentro de listas longas: esta foi a causa de várias reclamações do utilizador.
5. Aplica alterações globais para todas as classes/brawlers, nunca exemplos isolados.
6. Testa, compila, valida visualmente quando possível e cria checkpoint.

O utilizador valoriza fidelidade de fonte, rapidez de uso durante o draft, explicações visíveis e regras aplicadas a **todos** os brawlers. Se houver conflito entre uma UI bonita e uma explicação clara de score/counter/desbónus, prioriza a explicação clara.

### 11. Prioridades futuras já sugeridas

1. Filtro na lista para mostrar apenas brawlers com penalização.
2. Clique nos ativadores de penalidade para abrir a ficha do brawler e a origem literal.
3. Exportação do draft final em TSV/JSON com picks, bans, score e breakdown.
4. Filtros de fonte na Matriz 1v1 (Prodigy vs. Brawl Calculator/Brawl Planet, onde aplicável).
5. Melhorias móveis nos source callouts e nos chips de escolha.

**Regra final:** preserva os dados existentes e as relações literais. Se não encontrares uma fonte real, mostra estado indisponível/sem dados em vez de preencher com conteúdo inventado.

---

## Referências internas a incluir na transferência

| Documento | Finalidade |
|---|---|
| `TECHNICAL_ARCHITECTURE.md` | Arquitetura e fórmulas de referência. |
| `MIGRATION_GUIDE.md` | Passos de migração, secrets e deploy. |
| `MIGRATION_AUDIT_REPORT.md` | Itens exportáveis e itens a recriar. |
| `CONVERSATION_HISTORY_MEMORY.md` | Histórico de decisões do utilizador. |
| `AI_REPLICATION_MANIFEST.md` | Manifesto anterior; usar como complemento, pois há métricas antigas. |
| `visual_validation.md` | Evidências das correções de visibilidade mais recentes. |
| `todo.md` | Histórico de funcionalidades concluídas e futuras tarefas. |
