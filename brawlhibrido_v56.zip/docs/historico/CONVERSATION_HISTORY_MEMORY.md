# Memória Histórica e Contexto Integral de Conversas — Brawl Híbrido

Este documento consolida o histórico completo de interações, evoluções, correções, solicitações e decisões de design tomadas no desenvolvimento do **Brawl Híbrido**, servindo como base de conhecimento e "memória de sessão" para importar e continuar o projeto noutra conta ou ambiente.

---

## 1. Origem e Objetivo Inicial do Projeto
- **Início**: O utilizador solicitou um extrator e base de dados focada em Brawl Stars, acedendo em tempo real aos sites `topbrawl.com` e `brawlplanet.com` para mapear os 18 mapas ativos da rotação Ranked.
- **Fórmula do Score Híbrido**: Atualizada em 17 de agosto de 2026 para priorizar o desempenho publicado por mapa:
  $$\text{Score Híbrido} = (\text{Win Rate Brawl Planet} \times 0.80) + \left(\left(\frac{\text{Score TopBrawl}}{13}\right) \times 100 \times 0.20\right)$$
- **Tiers**: S ($\ge 75$), A ($65 - 74.99$), B ($< 65$).

---

## 2. Integração da API Oficial da Supercell e Coleta de Logs
- **Configuração da API**: O utilizador forneceu a chave da API oficial (`BRAWL_STARS_API_KEY`) ligando o Chromebook Linux e autenticando os pedidos tRPC e sincronizadores de servidor.
- **Mapeamento de Batalhas**: Implementou-se um recolhedor/sincronizador (`rankedSync.ts`) para fundir dados oficiais com fontes web, mantendo robustez contra falhas de rede (`PROTOCOL_CONNECTION_LOST` corrigido com reconexão resiliente) e preservação da última snapshot válida em caso de erro.
- **Matriz 1v1 por Partidas Observadas**:
  - Construída com base em logs reais da API.
  - Exigência rigorosa: **amostra mínima de 30 partidas** observadas por par de brawlers e por modo; abaixo disso, exibe explicitamente o estado **"amostra insuficiente"**, sem estimativas artificiais.
  - Isolamento por modo de jogo (Fute-Brawl, Pique-Gema, Zona Recôndita, Roubo, Caça-Estrelas, Nocaute).

---

## 3. Evolução do Motor de Draft (Nível Coach & Prodigy)
- **Fontes de Counters**:
  - **Power League Prodigy**: Fonte primária e canónica para o motor de Draft, recomendações de counters literais, bónus e penalidades.
  - **Brawl Planet**: Fonte de Best Teammates (sinergia positiva) e Worst Teammates (sinergia negativa).
  - **Brawl Calculator**: Fonte de dicas táticas textuais (`reason`) para o resumo final e Matriz 1v1.
  - **TopBrawl**: Fonte exclusiva de estatísticas, modos e builds de referência (sem listas públicas de counters).
- **Fórmula de Pontuação de Draft**:
  - Baseada no Score Híbrido do mapa, penalidades e bónus contextuais.
  - **Penalidades Implementadas**:
    1. **Enemy Counter Penalty (`-5%`)**: Por cada brawler inimigo pickado que seja counter literal (Prodigy) do brawler avaliado.
    2. **Same-Class Penalty (`-5%`)**: Por cada aliado da mesma classe já pickado na equipa (ex: tanques repetidos na mesma composicão).
    3. **Worst Teammate Penalty (`-5%` acumulativo)**: Por cada aliado na lista de sinergia negativa (Worst Teammates do Brawl Planet) do brawler candidato.
  - **Bónus Contextuais**: Counter (+10%), Ban (+3%), Fit (+7%), Opening (+4%), Synergy (+4%).

---

## 4. Correções de Interface, Mapas e Modos
- **Mapas Ranked**: Correção estrita da associação de cada um dos 27 mapas ranked ao seu modo oficial exato (ex: *Deathcap Trap* corrigido para Pique-Gema, *Open Business* para Zona Estratégica, *Belle's Rock* e *Out in the Open* para Nocaute).
- **Exportação TSV**: Funcionalidade implementada para exportar a tabela completa de mapas e modos em formato TSV, permitindo cópia direta para o clipboard ou descarga de ficheiro.
- **Interface Championship Arena**:
  - Estética baseada em dark carbon, electric violet, cyan e amber.
  - Tabuleiros de Draft interativos com simulação em tempo real, gestão de bans e picks para as equipas Azul e Vermelha, alternância de lado inicial (Scrim Lab) e perspetiva inimiga.
  - Fichas individuais (`BrawlerDetail.tsx`) sem limites artificiais de counters, agrupando proveniência por fonte (Brawl Calculator, Power League Prodigy, Brawl Planet).

---

## 5. Testes e Resiliência
- **Suite de Testes**: 76/76 testes Vitest a passar com 100% de sucesso.
- **Build de Produção**: Validado e publicado com sucesso no domínio `brawlhub-hv3h5xuy.manus.space`.

---
*Este documento resume o fio condutor, todas as decisões arquiteturais e os requisitos cumpridos desde a primeira mensagem do utilizador até à conclusão da migração.*
