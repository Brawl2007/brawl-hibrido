# Pesquisa de fontes para counters por mapa

## Evidência recolhida em 16 de agosto de 2026

| Fonte | URL | Evidência verificável | Limite para importação de counter por mapa |
|---|---|---|---|
| Brawl Planet — Bibi | https://www.brawlplanet.com/brawlers/bibi | A página publica matchups globais; Bibi aparece em **Struggles Against: Bea −4,7**, ou seja, a fonte global indica vantagem de Bea no confronto. Também apresenta estatísticas por modo, mapas melhores/piores e uma secção Ranked. | A página extraída não oferece o delta de matchup **Bea × Bibi por mapa individual**. Não é suficiente, sozinha, para gravar uma direção contextual de mapa. |
| Brawl Planet — Open Business | https://www.brawlplanet.com/maps/openbusiness_hotzone | A página de mapa publica estatísticas individuais de win rate, pick rate e star player por brawler, com amostra explícita de 230 227 partidas. No snapshot, Bibi tem 53,5% e Bea 49,7%. | Estes valores são desempenho individual no mapa; não medem o confronto direto entre Bea e Bibi. Não devem ser convertidos em counter automático. |
| BrawlStuff — mapas | https://brawlstuff.com/brawl_stars_stats/maps/ | O índice publica mapas e listas de melhores brawlers/combinações por mapa. | A página consultada não apresentou percentagem de confronto direto entre dois brawlers, logo serve como sinal de mapa e não como prova de direção de counter. |

## Hipótese em validação

O relato “Bea countera Bibi em mapas abertos” é consistente com a relação global publicada pelo Brawl Planet (Bibi tem Bea em *Struggles Against*). Contudo, a amostra de Open Business mostra que o desempenho individual do mapa não substitui uma estatística de matchup. A regra correta é aguardar uma fonte que exponha a relação direta e o mapa no mesmo registo, ou calcular essa relação a partir de partidas observadas com amostra suficiente.

## Fontes adicionais verificadas

| Fonte | URL | O que permite confirmar | Decisão para o importador contextual |
|---|---|---|---|
| Brawl Calculator — Backyard Bowl | https://brawlcalculator.com/maps/backyard-bowl/ | Classifica Backyard Bowl como extremamente aberto e inclui Bea no tier S, justificando a escolha com alcance sem obstruções, tiros carregados e lentidão contra portadores que avançam. | Usar apenas como **evidência de fit de mapa** para Bea; a página não afirma diretamente Bea → Bibi. Não gravar `counter_relations` com este dado isoladamente. |
| Brawl Planet — Bea | https://www.brawlplanet.com/brawlers/bea | Publica diretamente Bea em *Strong Against Bibi +4,7* e identifica Backyard Bowl como um dos melhores mapas de Bea (53,8% no snapshot). | Relação global direta reutilizável. O desempenho de mapa pode reforçar a confiança, mas não prova um counter Bea → Bibi específico de Backyard Bowl. |
| BrawlBuddy scraper | https://github.com/BrawlBuddy/scraper | Documenta coleta de battle records e tem uma matriz 1v1 global e um ficheiro de win rate individual por mapa. O próprio repositório marca a metodologia 1v1 como pendente de revisão. | Não importar os resultados publicados. O conceito de coletar partidas é útil, mas o nosso cálculo deve guardar **mapa e participantes da mesma batalha** antes de inferir um counter. |
| BrawlStarsBattleRecord / Brawl Meta | https://github.com/JH-Ha/BrawlStarsBattleRecord | Demonstra coleta horária de logs e publicação de win rate de brawler por mapa a partir da API oficial. | Boa referência de arquitetura para coleção, mas não disponibiliza um matchup direto por mapa na evidência consultada. Não usar como prova de direção. |
| Brawl Stats club tracker | https://github.com/louisbgl/brawl-stats | Mantém battlelogs deduplicados de jogadores consultados periodicamente; o limite da API oficial é 25 partidas por consulta. | Referência de armazenamento de logs. Só seria fonte contextual após recolher uma rede de jogadores suficientemente grande e calcular a matriz em nosso próprio banco. |
| BrawlStars Draft Helper | https://github.com/mr-devlinder/BrawlStars-Draft-Helper | Separa explicitamente perfis de mapa e counters globais, permitindo substituições manuais sobre dados embutidos. | Confirma o desenho de produto, mas os dados do repositório são configurações editáveis; não são fonte independente para importação automática. |

## Conclusão parcial

As fontes abertas verificadas disponibilizam **duas peças diferentes**: relações de counter globais e força individual por mapa. Nenhuma das páginas públicas analisadas oferece, de forma pronta e verificável, a taxa **Bea contra Bibi no mesmo mapa**. Por isso, o importador deve manter a relação global Brawl Planet `Bea → Bibi` e criar uma relação por mapa somente quando houver uma estatística de confronto direto ou quando a nossa base acumular partidas com mapa, modo, equipas e resultado.

Para evitar inventar precisão, a expressão “mapa aberto” pode servir de etiqueta de revisão editorial e de justificativa de fit, mas não como uma alteração automática de direção de counter.

## Caso prioritário: Bea × Bibi

| Evidência | Observação | Uso correto no Draft |
|---|---|---|
| Brawl Planet, matchup global de Bea | Bea aparece em *Strong Against Bibi +4,7*. A métrica já ajusta o efeito de ambos os brawlers estarem fortes ou fracos no update. | Confirma `Bea → Bibi` como counter global da fonte. |
| Brawl Planet, Backyard Bowl — Ranked | Em 199 379 partidas Ranked: Bibi 55,8% de win rate e Bea 52,3%. Bea foi a 4.ª mais escolhida, com 18,7% de pick rate. | São métricas individuais no mesmo mapa; não permitem concluir Bibi → Bea nem invalidar Bea → Bibi. |
| Brawl Planet, Backyard Bowl — Trophy Ladder | Em 1 446 947 partidas: Bea 53,8% e Bibi 45,3%. | Também é estatística individual; reforça apenas que a força geral dos dois muda entre públicos. |
| Brawl Calculator, Backyard Bowl | Define o mapa como aberto, coloca Bea no tier S e explica que linhas de visão desobstruídas favorecem os tiros carregados e a lentidão. | Evidência editorial de fit de mapa para Bea, não um matchup direto. |
| Brawl Calculator, páginas de Bea e Bibi | O guia de Bea não lista Bibi como counter explícito e o guia de Bibi não lista Bea. As listas de mapas em que cada uma brilha não se sobrepõem: Bea inclui Backyard Bowl, enquanto Bibi inclui Pit Stop, Dueling Beetles, Parallel Plays, No Good Deed, Singed Earth e Plain Text. | Confirma que o Brawl Calculator separa a sua lista global de counters do fit de mapa e não fornece um dado automático `Bea → Bibi` por mapa. |

**Resultado da validação:** há base suficiente para conservar **Bea → Bibi como relação global Brawl Planet** e para marcar **Backyard Bowl** como mapa favorável a Bea. Ainda não existe, nas fontes públicas verificadas, evidência de matchup direto por mapa que autorize criar `Bea → Bibi` especificamente em Backyard Bowl. Portanto, não foi alterada a direção contextual no banco.

## Cobertura para os 132 pares contraditórios

| Nível de evidência | Fontes disponíveis | Pode criar counter por mapa automaticamente? |
|---|---|---|
| Relação direta global | Brawl Planet publica *Strong Against* e *Struggles Against* por brawler; Brawl Calculator e Prodigy fornecem guias globais. | Não. Serve como fallback global. |
| Desempenho individual por mapa | Brawl Planet, Brawlify, Brawl Time, Noff e Brawl Calculator por mapa. | Não. Win rate, pick rate, tier e descrição de mapa não identificam quem venceu o confronto direto. |
| Relação direta por mapa | Nenhuma fonte pública verificada expôs uma tabela ou endpoint de pares `atacante × defensor × mapa`. A inspeção da página Brawl Planet de Backyard Bowl mostrou recursos de renderização e estatísticas agregadas, não uma chamada pública de matchup contextual. | Não há importação automática segura a partir dessas páginas. |
| Relação calculada a partir de partidas | Battlelogs guardados pelo próprio projeto, com mapa, modo, duas equipas, resultado, patch e período. | Sim, depois de uma amostra mínima e de validações de composição. |

### Regra recomendada para todos os pares contraditórios

1. Manter as fontes atuais como **global**.
2. Acrescentar `map_id` somente quando um cálculo de partidas armazenar o matchup no mesmo mapa e modo, ou quando uma fonte publicar explicitamente o par e o mapa.
3. Exigir uma amostra mínima, intervalo de confiança e superioridade estatística antes de substituir o fallback global; se não passar, não criar registo contextual.
4. Guardar a URL, data de recolha, método e tamanho da amostra em `counter_relations` para cada importação.
