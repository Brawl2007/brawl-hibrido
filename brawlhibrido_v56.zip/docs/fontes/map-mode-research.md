# Auditoria externa dos modos dos mapas Ranked

Data da consulta: 2026-08-14.

## Fontes consultadas

- TopBrawl, Deathcap Trap: https://topbrawl.com/rankeds/15000009
  - Título: “Best Brawlers for Gem Grab on Deathcap Trap”.
  - A página agrupa Deathcap Trap em GEM GRAB/Pique-Gema.
  - A lista de mapas da própria página inclui Deathcap Trap dentro de GEM GRAB.

- Resultados públicos consultados para Open Business:
  - NoFF: https://www.noff.gg/brawl-stars/map/open-business — apresenta Open Business como mapa de Hot Zone/Zona Estratégica.
  - Brawlify: https://brawlify.com/maps/15000292 — apresenta Open Business como mapa de Hot Zone/Zona Estratégica.
  - BrawlTime: https://brawltime.ninja/tier-list/mode/hot-zone/map/Open-Business — apresenta Open Business em Hot Zone.

## Correção a aplicar

- Deathcap Trap deve ser exclusivamente Pique-Gema (`gem-grab`). Não deve aparecer em Fute-Brawl nem como mapa duplicado noutro modo.
- Open Business deve ser exclusivamente Zona Estratégica/Hot Zone (`hot-zone`). Não deve aparecer em Roubo nem como mapa duplicado noutro modo.

## Nota de implementação

A fonte única deve alimentar `mapModeOverrides`, `rankedMaps`, `additionalRankedMaps`, resumos, filtros do Dashboard, seletor e telemetria do Draft. A validação deve rejeitar qualquer mapa duplicado com modos diferentes e verificar os 27 mapas por nome e `modeId`.
