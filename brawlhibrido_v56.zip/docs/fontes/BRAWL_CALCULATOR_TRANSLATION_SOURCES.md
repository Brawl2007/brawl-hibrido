# Dicas Brawl Calculator — proveniência e tradução

As relações de counter e as explicações originais provêm das páginas públicas de counter do [Brawl Calculator](https://brawlcalculator.com/counters/), preservadas literalmente em `shared/brawlCalculatorCounterData.ts`. Cada dica no Draft conserva a direção original `atacante → defensor`, o URL da página de origem e os nomes de brawlers.

Em 16 de agosto de 2026, as 1.129 explicações literais foram traduzidas uma única vez para português e gravadas estaticamente em `shared/brawlCalculatorTipTranslations.ts`. A tradução foi produzida por uma fonte pública de tradução automática, [Google Translate](https://translate.googleapis.com/translate_a/single), apenas para apresentação no Draft. Não foi usada para criar, alterar ou inferir relações de counter.

O texto original em inglês permanece acessível pelo link **Brawl Calculator · texto original** em cada painel de duelo, para que a tradução possa ser conferida contra a fonte literal.
