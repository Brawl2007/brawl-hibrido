# Fontes da auditoria de classes

## Taxonomia válida

A Supercell estabelece sete classes de brawler: Damage Dealer, Assassin, Marksman, Artillery, Tank, Support e Controller. No Draft, estas são representadas de forma consistente como **Destruidor**, **Assassino**, **Artilheiro**, **Lançador**, **Tank**, **Suporte** e **Controlador**. [1]

## Confirmação de Bolt

A página pública de perfil de Bolt no NOFF classifica-o explicitamente como **“Tank epic”** e apresenta-o também na lista “Other Tank Brawlers”. Por isso, o catálogo do Draft deve guardar Bolt como **Tank**, nunca como Artilheiro. [2]

A ficha comunitária Brawl Stars Wiki descreve Bolt como um brawler épico de **vida elevada**, contacto direto e Super com redução de dano, características consistentes com a classificação Tank. Esta segunda referência sustenta a correção, mas a etiqueta explícita usada pelo catálogo é a do NOFF. [3]

## Correção da categoria Lutador

"Lutador" não é uma das sete classes publicadas pela Supercell. As quatro entradas que ainda usavam essa etiqueta foram verificadas em perfis públicos: **Ash**, **Bibi** e **Sam** são Tank, enquanto **Carl** é Damage Dealer. Estas correções removem a categoria não oficial do motor de desbónus e impedem que esses brawlers penalizem candidatos de uma classe diferente. [5]

## Correções específicas — Rico, Gene, Chuck, Darryl e Eve

As fichas atuais do Brawlify identificam **Rico** e **Eve** como Damage Dealer, **Gene** e **Chuck** como Controller e **Darryl** como Tank. No catálogo português do Draft, esses valores passam respetivamente a **Destruidor**, **Destruidor**, **Controlador**, **Controlador** e **Tank**. A mesma atualização substitui as etiquetas antigas de apresentação em todos os brawlers, para que tanto o filtro como o desbónus trabalhem com uma única taxonomia. [6]

## Correção específica — Colt e 8-Bit

As fichas atuais do Brawlify classificam **Colt** e **8-Bit** como **Damage Dealer**. No catálogo do Draft, ambos passam a **Destruidor**. Consequentemente, um Pick aliado de Colt e 8-Bit ativa o desbónus de mesma classe de −5%; ambos deixam de afetar ou ser afetados como Artilheiros. [7]

O NOFF expõe uma etiqueta explícita no cabeçalho de cada perfil e agrupa cada brawler por essa etiqueta. Por exemplo, Amber aparece como **“Controller legendary”** e no grupo “Other Controller Brawlers”, o que coincide com o catálogo atual. A fonte é útil para verificar cobertura e divergências, mas não substitui a etiqueta apresentada no cliente oficial; por isso, apenas divergências suportadas por evidência clara e pelo pedido do utilizador serão aplicadas automaticamente. [4]

## Referências

[1] [Supercell Support — Brawler Classes](https://support.supercell.com/brawl-stars/en/articles/brawler-classes.html)

[2] [NOFF — Brawl Stars Bolt Stats & Abilities](https://www.noff.gg/brawl-stars/brawler/bolt)

[3] [Brawl Stars Wiki — Bolt](https://brawlstars.fandom.com/wiki/Bolt)

[4] [NOFF — Brawl Stars Amber Stats & Abilities](https://www.noff.gg/brawl-stars/brawler/amber)

[5] [NOFF — Ash](https://www.noff.gg/brawl-stars/brawler/ash), [Bibi](https://www.noff.gg/brawl-stars/brawler/bibi), [Carl](https://www.noff.gg/brawl-stars/brawler/carl) e [Sam](https://www.noff.gg/brawl-stars/brawler/sam)

[6] [Brawlify — Rico](https://brawlify.com/brawlers/16000004), [Gene](https://brawlify.com/brawlers/16000021), [Chuck](https://brawlify.com/brawlers/16000073), [Darryl](https://brawlify.com/brawlers/16000018) e [Eve](https://brawlify.com/brawlers/16000056)

[7] [Brawlify — Colt](https://brawlify.com/brawlers/16000001) e [8-Bit](https://brawlify.com/brawlers/16000027)
