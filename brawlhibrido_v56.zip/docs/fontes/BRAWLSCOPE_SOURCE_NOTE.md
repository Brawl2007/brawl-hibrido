# Verificação de fonte — BrawlScope Counters

## 18 de agosto de 2026

Foram verificadas as páginas públicas `https://brawlscope.com/counters` e `https://www.brawlscope.com/sk/counters?brawler=sam`. Ambas expõem a secção pública de Counters e indicam navegação/filtro por brawler, mas a extração textual estática não devolveu as relações de counter. A página individual encontrada nos resultados de pesquisa descreve o conteúdo como “Best picks against Sam, who Sam punishes, and their strongest teammates, measured against each pick's own win rate”.

Antes de substituir dados no projeto, é necessário obter o payload público que alimenta esse conteúdo dinâmico e verificar a cobertura por brawler. Nenhuma relação foi importada nesta etapa.

## Extração validada

Foi obtido o conteúdo público renderizado de 106 páginas de brawler em `https://brawlscope.com/counters?brawler=<slug>`. O BrawlScope publica duas listas por brawler: **PUNEM** (brawlers que o alvo countera) e **PUNIDO POR** (brawlers que counteram o alvo). A exportação histórica guardou estes grupos em campos técnicos trocados: `counteredBy` bruto contém PUNEM e `targets` bruto contém PUNIDO POR. O adaptador canónico corrige essa inversão ao expor PUNEM como `targets` e PUNIDO POR como `counteredBy`.

Na primeira recolha, foram encontradas relações legíveis em **99 de 106** entradas. Uma recolha complementar das sete páginas inicialmente sem texto de relações recuperou listas publicadas para **Alli, Bibi, Gale, Grom, Jae-Yong e Max**. A fonte estática contém agora relações BrawlScope literais para **105 de 106** brawlers.

**Gus** continua sem listas legíveis publicadas na sua página de BrawlScope e não recebeu relações por inferência nem por dados do Power League Prodigy. Todas as relações importadas conservam a URL individual BrawlScope para auditoria.

Cada direção preserva a ordem publicada e utiliza até os **10 primeiros** brawlers: Top 10 que o alvo countera (`targets` canónico) e Top 10 que counteram o alvo (`counteredBy` canónico). Quando uma página pública expõe menos de dez relações legíveis, o catálogo mantém apenas as relações que a fonte publicou.

## 11 de setembro de 2026 — orientação do delta e regeneração das listas

### O sinal publicado é a perspetiva do adversário

A página de cada brawler mede cada confronto **contra a taxa de vitória do próprio
adversário**. Por isso, na ficha de Nori, `Counter with · Doug +9,6` significa que
Doug ganha 9,6 pontos de win rate quando enfrenta Nori, e `Punishes · Mico −9,8`
significa que Mico perde 9,8 contra Nori.

| Valor publicado | Leitura da fonte | Leitura do projeto |
|---|---|---|
| positivo | o adversário pune o titular | negativo para o titular |
| negativo | o titular pune o adversário | positivo para o titular |

O projeto lê sempre na perspetiva do brawler escolhido: positivo significa que ele
countera o adversário. A conversão está isolada em `toOwnerPerspective`, em
`shared/counterMatchupValue.ts`. Antes desta correção o motor usava o valor cru e,
sem evidência literal das listas, premiava escolher um brawler counterado.

### Listas Top 10 regeneradas a partir da mesma tabela

`shared/brawlScopeCounterData.ts` passou a ser gerado por
`server/scripts/rebuild-brawlscope-counters.mjs` a partir de
`shared/brawlScopeMatchupDeltas.generated.ts` — a tabela completa de matchups da
própria fonte, que é o que alimenta as duas listas visíveis do perfil. `counteredBy`
são os dez maiores deltas positivos e `targets` os dez mais negativos, pela ordem
da fonte.

Verificação contra a página pública de Nori no dia da alteração:

| Secção publicada | Três primeiros | Delta no catálogo |
|---|---|---|
| `Counter with` | Doug, Buster, Jae-Yong | 9,7 · 8,7 · 7,7 |
| `Punishes` | Mico, Melodie, Eve | −10 · −9 · −8,7 |

As listas antigas estavam desatualizadas (a de Nori ainda trazia Sirius, Surge e
Edgar) e é essa a razão de aparecerem agora nomes diferentes. A cobertura subiu de
104 para 106 perfis: **Gus** e **Wendy**, que não tinham listas legíveis, passam a
ter as relações que a tabela publica.

Dezasseis perfis têm menos de dez relações num dos sentidos porque a fonte não
publica mais pares nesse sentido — por exemplo, Amber, Gus e Wendy não têm nenhum
adversário com delta positivo. Essas listas ficam curtas em vez de serem completadas.

### Fim da troca de Ruffs

A inversão histórica dos dois arrays de Ruffs existia porque a exportação antiga
guardava os campos trocados. Com o catálogo regerado a partir da tabela de matchups,
todos os perfis ficam na mesma orientação e a exceção foi removida do adaptador e do
`counterSync`.

### Counter banido

O bónus de Counter banido passa a exigir que o ban esteja na lista literal
`counteredBy` do candidato — o Top 10 de counters que a fonte publica para ele. Um
delta positivo residual deixou de transformar qualquer brawler em counter: Shade, por
exemplo, não aparece mais nas leituras de Edgar, porque não consta do Top 10 dele.

### Um brawler sem counters não é uma lista em falta

Amber, Gus e Wendy têm os 105 confrontos publicados e nenhum adversário com
vantagem sobre eles — é assim que a fonte descreve um brawler dominante no meta
atual. Shade tem apenas um. Do lado oposto, Crow tem 103 counters e só 2 presas.

A ficha do brawler passa a dizer isso por palavras, em vez de mostrar o estado
genérico de "sem dados": `getBrawlScopeCoverage` distingue os dois casos e a lista
vazia aparece como "não tem counters", com o total de confrontos lidos e o
confronto mais equilibrado da tabela.

### Duas leituras, cada uma no sítio certo

O número mostrado na **ficha do brawler** é agora exatamente o que a fonte publica:
positivo quando o adversário leva vantagem, negativo quando o titular pune. Quem
comparar o site com o perfil vê o mesmo valor, com o mesmo sinal.

O **Draft** continua na perspetiva do pick, porque ali o valor vira bónus ou
desbónus de Score: um confronto favorável tem de somar pontos, não subtrair. A
conversão entre as duas leituras está em `toPublishedMatchupValue`, e o painel do
perfil diz isso por escrito para ninguém achar que há dois números diferentes.

| Par | Ficha do brawler | Draft |
|---|---|---|
| Nori vs Doug | +11,7% | −11,7% |
| Nori vs Mico | −14% | +14% |

### Fichas que se contradizem: manda a ficha do brawler avaliado

A fonte mede cada confronto contra a média do próprio adversário, por isso dois
brawlers dominantes aparecem, cada um na sua página, a punir o outro:

| Ficha consultada | Valor publicado | Leitura |
|---|---|---|
| Wendy → Shade | −4,1 | a Wendy pune o Shade |
| Shade → Wendy | −12,6 | o Shade pune a Wendy |

O motor usava a magnitude da ficha do titular mas deixava a lista do adversário
decidir o sentido. Resultado: oito brawlers "counteravam" a Wendy, que não tem um
único counter publicado, e escolhê-la perdia pontos no Draft. O mesmo acontecia
com a Amber e o Gus.

Passa a valer a ficha de quem está a ser avaliado. Escolher a Wendy contra o Shade
soma pontos pela ficha dela; escolher o Shade contra a Wendy soma pontos pela dele.
A contagem de counters de cada brawler no motor passou a bater certo com a fonte:
Wendy, Amber e Gus com 0, Shade com 1, Crow com 103, Nori com 60. O aviso de Counter
Top ganhou a mesma salvaguarda.

### Vistas da fonte: Overall e Lendário+

Os links de filtro da própria página revelam como as duas dimensões funcionam:

| Filtro | URL |
|---|---|
| Legendary+ | `/counters/nori` *(sem parâmetro)* |
| All ranks | `/counters/nori?rank=all` |
| Diamond+ / Mythic+ / Masters+ | `?rank=diamond` · `?rank=mythic` · `?rank=masters` |
| Overall (todos os modos) | *(sem parâmetro `mode`)* |
| Um modo | `?mode=knockout` (ids em camelCase, iguais aos do projeto) |

Ou seja: **Lendário+ é o valor por omissão da fonte e não leva parâmetro**; `rank=all`
é que significa "todas as patentes". A vista canónica do projeto é **Overall +
Lendário+** — a ficha sem qualquer filtro.

O `counterSync` lia apenas as seis vistas por modo e nunca a Overall, pelo que a
leitura global vinha só do catálogo estático. Passa a ler sete vistas: Overall
primeiro, depois os seis modos, todas fixadas em Lendário+ por `brawlScopeProfileUrl`.
Cada relação e cada sinergia guarda o `rankId` lido, para uma mudança de omissão no
site não passar despercebida. As restantes patentes ficam a um parâmetro de distância
(`--rank=all` no importador).

### Tudo em tempo real: matchups completos por modo

O `liveSync` já corria sozinho — primeiro ciclo um segundo depois do servidor subir e
depois a cada 15 minutos (`BRAWL_LIVE_SYNC_INTERVAL_MS`), sem depender de login nem do
botão "Atualizar agora". O que lhe faltava era **ler a tabela completa** das páginas que
ele próprio já descarrega.

`parseBrawlScopeEveryMatchup` lê agora a secção "Every matchup" de cada ficha, no mesmo
HTML, **sem um único pedido extra**. Cada linha traz o seu controlo: a taxa de vitória do
par menos o delta tem de dar a média publicada do adversário; a linha que não fechar é
descartada em vez de entrar com um valor duvidoso.

| Camada | Onde vive |
|---|---|
| Leitura das sete vistas | `collectBrawlScopeModes` (Overall + 6 modos, Lendário+) |
| Matrizes completas | memória do servidor, refeitas a cada ciclo |
| Entrega ao cliente | `counterSync.matchups` (fora do SSE, por tamanho) |
| Aplicação no motor | `setBrawlScopeLiveMatchups`, com prioridade sobre o catálogo |

As matrizes não viajam no evento SSE porque são grandes — cerca de 11 mil pares por
vista. O cliente pede a vista geral e, na leitura "Por modo", a do mapa ativo; a resposta
é revalidada quando a snapshot muda de versão. Um par sem dados em direto continua a usar
o catálogo do repositório, por isso o Draft nunca fica sem leitura.

Counters e sinergias já viajavam no snapshot e continuam a ter prioridade sobre o
catálogo estático. Com esta peça, as três leituras — counters, sinergias e matchups
completos por modo — passam a vir da mesma recolha automática.

### Se a fonte bloquear a recolha

Uma fonte pública pode recusar um robô, e o código passa a assumir isso em vez de
insistir:

| Resposta | O que acontece |
|---|---|
| 429 ou 503 | Respeita o `Retry-After`; sem ele, espera 10 min e duplica a cada falha, até 6 h |
| 401 ou 403 | Marca a origem como fechada e **não faz mais nenhum pedido** até o prazo passar |
| 5xx | Uma repetição com espera curta; à terceira, desiste daquela ficha |
| Tudo bem | Limpa o contador de falhas |

O ciclo pára à primeira porta fechada, em vez de percorrer as vistas seguintes. E a
carga baixou: em vez de 742 pedidos de uma assentada (7 vistas × 106 fichas), cada
ciclo renova **uma vista** — cerca de 106 páginas — e o conjunto completa-se ao longo
da hora. As vistas não renovadas continuam a valer, por isso o Draft nunca fica sem
dados. `BRAWLSCOPE_VIEWS_PER_CYCLE` e `BRAWLSCOPE_REQUEST_SPACING_MS` ajustam o ritmo,
e `BRAWLSCOPE_USER_AGENT` permite identificar o projeto de outra forma.

O estado fica visível: `counterSync.status` devolve `sourceHealth` (bloqueada, último
código HTTP, falhas consecutivas) e `matchupCoverage`, e o painel de regras do Draft
mostra se há recolha em direto ou se está a usar as tabelas do repositório.

**Nota importante sobre o que não consigo garantir daqui:** este ambiente não alcança o
brawlscope.com diretamente, por isso não pude testar a recolha do lado do servidor. Há
duas hipóteses de falha que só se veem em produção — o site responder 403 a um pedido
de servidor, ou a tabela ser montada no browser e não vir no HTML. Nos dois casos o
`sourceHealth` mostra o que aconteceu e os catálogos do repositório continuam a servir
o Draft, que é precisamente para isso que eles existem.

### O botão "Atualizar agora"

A rotação lenta é para os ciclos automáticos. Um pedido manual passa `force` e relê
**as sete vistas**, sem respeitar o intervalo de uma hora nem o teto de uma vista por
ciclo — caso contrário o botão devolvia dados em cache e parecia avariado.

A mensagem de sucesso deixou de prometer o que não houve: mostra o número de relações e
de sinergias e, por baixo, a nota da própria origem ("7/7 vistas em Lendário+, renovadas
por pedido manual…", ou o motivo do bloqueio quando existe).

Continua a exigir sessão de administrador, como estava. Sem sessão, a resposta é
*Please login (10001)* — é a rota protegida a funcionar, não uma avaria.
