# Bolt — pesquisa de counters

## Fontes consultadas

1. Power League Prodigy — https://powerleagueprodigy.com/bolt
   - Bolt countera: Grom, Mr. P, Buster, Frank, Squeak, Lumi, Leon e Carl.
   - Counteram Bolt: Gale, Charlie, Buzz, Willow, Clancy, Rosa e Melodie.
   - A página também lista Meg como brawler que countera Bolt.

2. Brawl Planet — https://www.brawlplanet.com/brawlers/bolt
   - Matchups fortes de Bolt: Sprout (+9,9), Grom (+9,2), Najia (+8,7), Ziggy (+8,5) e Mico (+7,9).
   - Matchups difíceis para Bolt: Damian (-9,8), Charlie (-7,8), Bull (-7,7), Clancy (-7,5) e Rosa (-7,5).
   - Os valores são desvios do resultado esperado do matchup, não uma garantia universal.

3. Brawl Stars Wiki — https://brawlstars.fandom.com/wiki/Bolt
   - Bolt é um tanque cujo dano aumenta com a velocidade; tem recarga lenta e depende de manter linhas de movimento.
   - Knockback, controlo de grupo, paredes e efeitos que interrompem a aproximação podem reduzir a eficácia de Bolt.

## Resumo

A resposta ao utilizador deve distinguir entre a lista do Prodigy e os dados estatísticos do Brawl Planet. Os matchups variam por mapa, modo, build e versão; portanto, devem ser apresentados como tendências de draft, não como counters absolutos.
