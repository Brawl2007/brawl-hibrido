# Pesquisa de fontes de counter — mudança de temporada

## Critérios de aceitação

Uma fonte só poderá influenciar o motor do Draft se publicar relações explícitas de direção entre brawlers, puder ser atribuída a uma origem e tiver uma política clara de atualização. Métricas de win rate, tier lists, vídeos e comentários da comunidade podem servir para revisão humana, mas não devem criar counters automáticos sem uma relação literal verificável.

## Descobertas iniciais

| Fonte | URL | Sinal encontrado | Estado inicial |
|---|---|---|---|
| Brawl Calculator | https://brawlcalculator.com/ | O próprio site descreve um seletor de até três picks inimigos e devolve brawlers que os counteram. | Já integrado; confirmar cobertura e atualização pós-patch. |
| BrawlBrawl | https://www.brawlbrawl.com/counters | A página de counters informa que permite selecionar até três brawlers e remete às fichas individuais para os counter picks. | Candidato forte; verificar cobertura, estrutura e atualização. |
| noff.gg | https://www.noff.gg/brawl-stars/app/build/17034/every-counters-for-each-brawlers-- | Publica guias de comunidade que alegam cobrir counters de todos os brawlers e reconhecem dependência de mapa/matchup. | Apenas fonte auxiliar para revisão humana; autoria e atualização não são garantidas. |
| Reddit / vídeos | https://www.reddit.com/r/BrawlStarsCompetitive/ | Resultados incluem listas comunitárias e vídeos de counters. | Não usar no motor automático; podem sinalizar pares para auditoria. |

## Verificação direta

### BrawlBrawl

A página de [Counters](https://www.brawlbrawl.com/counters) declara que aceita até três brawlers inimigos e devolve os counter picks mais eficazes. A lista visível inclui o catálogo atual de brawlers, incluindo lançamentos recentes como Alli, Gigi, Jae-Yong, Kaze, Lumi, Mina, Ollie e Pierce. Isto confirma **cobertura de catálogo atual** e uma relação de direção (inimigo selecionado → pick recomendado), mas a página não exibiu data de atualização, metodologia ou contexto de mapa/modo na leitura inicial. A integração exigiria verificar as fichas individuais e a disponibilidade técnica dos pares sem depender de opiniões não atribuídas.

### Brawlify

A página inicial de [Brawlify](https://brawlify.com/) apresenta-se como plataforma de meta, eventos e rankings, com notificações separadas para rotação de eventos e atualizações/balanceamentos. A pesquisa também aponta páginas por mapa com win rate, pick rate e composições de equipa. Na página verificada, não foi encontrada uma matriz ou lista explícita de brawler → brawler. Por isso, Brawlify deve ser usado como **monitor de rotação e validação estatística por mapa**, não como origem direta para criar relações de counter.

### Noff

O [Brawler Matchup](https://www.noff.gg/brawl-stars/brawler-matchup) da Noff compara até três brawlers e apresenta estatísticas, raridade, alcance e win/pick rate. A própria explicação diz que o duelo é uma estimativa baseada em estatísticas-base, reconhecendo que habilidades e gadgets importam. É útil para uma **comparação manual de atributos e sanity check**, mas não publica, na página validada, uma relação literal `A countera B`; não deve alimentar penalizações/bonificações automáticas.

### Deep Draft

O [Deep Draft](https://deepdraft.fr/) declara oferecer recomendações em tempo real por mapa com sinergias, counters inimigos e uma análise final de probabilidade de vitória; também disponibiliza tier lists por mapa e um explorador de base de partidas. A página de Draft explicita que a recomendação é calculada a partir de milhares de partidas e define `Counter` como a vantagem de um brawler contra um inimigo específico, com bónus ou penalidade de counter dentro da pontuação de recomendação. Também expõe mapas competitivos individualmente. É, portanto, a fonte adicional mais promissora para **evidência quantitativa por mapa**, desde que seja possível obter pares e metadados de atualização de uma maneira permitida e estável.

### Brawl Calculator — confirmação

O [Brawl Calculator](https://brawlcalculator.com/) confirma que fornece guia completo por brawler — quem vence, quem é vencido e o porquê do matchup — e indica `data updated July 2026`. Também atribui os counterpicks primariamente a dados de ranking de SpenLC. Entre as fontes verificadas, é a mais transparente para relações literais e continua adequada como fonte canónica, sujeita a uma auditoria de data a cada temporada.

### Brawl Stars AI Coach

O [Brawl Stars AI Coach](https://brawlstarsaicoach.com/) promove picks e bans sensíveis a mapa, counter analysis e dados de meta atualizados em tempo real. Contudo, a informação visível é uma recomendação fechada de produto: não expõe uma matriz, os pares literais, uma metodologia reprodutível ou uma interface pública de dados. Pode servir de **referência externa durante uma revisão manual**, mas não como fonte integrada no motor.

### PL Prodigy — excluído do motor

O [PL Prodigy](https://powerleagueprodigy.com/) continua a publicar recomendações por mapa, guides e leituras de matchup, incluindo publicações rápidas sobre brawlers novos. Ainda assim, está **deliberadamente excluído** de todos os cálculos de counter deste projeto por requisito do Draft. Pode ser acompanhado como notícia/contexto de balanceamento, mas nunca reintroduzido como origem de relações automáticas.

## Comparação e decisão

| Fonte | Relação literal de counter | Contexto por mapa | Atualização declarada | Papel recomendado |
|---|---:|---:|---:|---|
| BrawlScope | Sim, já integrado | Não confirmado nesta auditoria | Conforme o conjunto publicado | Prioridade 1 para pares já cobertos. |
| Brawl Calculator | Sim, com explicação de matchup | Mapas com picks/bans pesquisados | Julho de 2026 na página verificada | Prioridade 2; auditoria de data na virada da temporada. |
| BrawlBrawl | Sim, recomenda picks contra até três inimigos | Não visível na página verificada | Não exibida | Prioridade 3, apenas depois de validar pares individuais e data de atualização. |
| Deep Draft | Quantitativa, derivada de partidas | Sim, explicitamente por mapa e composição | Não exibida | Fonte de validação por mapa e candidata futura, não substituir relações literais sem export verificável. |
| Brawl Planet / Brawlify | Não como matriz direta verificada | Sim, métricas e composição por mapa | Brawlify declara dados atualizados com frequência | Contexto de meta, sinergia e confirmação estatística; não criar counters. |
| Noff / Brawl Stars AI Coach / guias comunitários | Não verificável como matriz pública | Parcial ou fechado | Variável | Revisão humana apenas. |

> **Regra para a nova temporada:** nenhuma mudança de balanceamento deve criar um counter automaticamente. O sistema só altera um par quando pelo menos uma fonte literal atualizada o publica, ou quando duas fontes independentes de dados por mapa sustentam a revisão e ela é aprovada numa auditoria manual.

## Fluxo sazonal recomendado

1. No lançamento da temporada, atualizar mapas e estatísticas normalmente.
2. Verificar a data e as relações do BrawlScope e Brawl Calculator para brawlers afetados pelo patch.
3. Usar BrawlBrawl para cobrir pares ausentes, guardando fonte, direção e data de recolha em cada relação.
4. Confrontar pares controversos com Deep Draft por mapa; se o efeito depender do mapa, guardar esse contexto em vez de trocar uma relação global.
5. Manter Brawlify/Brawl Planet para confirmar mudanças de meta, win rate e composição, sem transformar correlação em counter automático.

## Próxima verificação

Abrir BrawlBrawl, Brawl Calculator e uma fonte estatística de mapa para distinguir relações literais de simples desempenho agregado antes de recomendar integração.

## Patch de agosto de 2026 — fila de auditoria

As fontes consultadas reportam mudanças gerais em **Crow, Griff, 8-Bit, Max, Surge, Damian, Bolt e Starr Nova**. Uma delas classifica a informação como sujeita a alteração antes do lançamento, enquanto a outra diz que a manutenção ocorreu em 4 de agosto; por isso, estes dados são uma **fila de revisão**, não uma alteração direta no motor.[^aug-blog] [^aug-sports]

| Prioridade | Brawlers afetados | Motivo para rever matchups | Estado no Draft |
|---|---|---|---|
| Muito alta | Crow, Surge, Bolt, Damian, Starr Nova | Mudanças de dano, velocidade de ataque, vida, escudo ou geração de Super podem inverter duelos diretos. | Pendente confirmação de pares atuais em fontes literais. |
| Alta | 8-Bit, Max, Griff | Mudanças de Super, velocidade, gadget ou área podem alterar composição, lane e algumas respostas específicas. | Pendente confirmação de pares atuais em fontes literais. |
| Contexto NanoPower | Belle, Tara, Fang, Mr. P, Sprout, Buzz, Bo, Edgar, Mortis, Rico, Penny, Barley, Angelo, Frank, Alli, Sirius, Ziggy, Tick | As mudanças listadas são específicas de NanoPower; só devem afetar o Draft se o modo competitivo ativo realmente usar essa camada. | Não alterar relações globais sem confirmação do modo. |

> **Decisão de segurança:** nesta fase não foram adicionados, removidos ou invertidos counters. Primeiro é necessário que BrawlScope, Brawl Calculator ou outra fonte literal atualizada publique a direção de cada par envolvido.

### Confirmação BrawlScope — 19 de agosto de 2026

A página pública de counters do BrawlScope declara utilizar dados live da API oficial, mas a extração textual não expôs os pares individuais. A tier list da mesma fonte foi atualizada em 18 de agosto de 2026 e mostra alterações relevantes de meta para brawlers afetados pelo patch, incluindo Griff, Surge, Max, 8-Bit, Starr Nova, Crow, Damian e Bolt. Isto confirma que a fonte está atualizada como contexto de meta, mas **não autoriza uma alteração de direção de counter sem recuperar o par literal**.[^brawlscope-tier]

[^brawlscope-tier]: [BrawlScope — Tier List](https://brawlscope.com/tier-list), dados declarados como atualizados em 18 ago. 2026; consultado em 19 ago. 2026.

[^aug-blog]: [Brawl Stars Blog — August 2026 Balance Changes](https://brawlstarsblog.com/august-2026-balance-changes/), consultado em 19 ago. 2026.
[^aug-sports]: [Sportsdunia — Brawl Stars Balance Changes August 2026](https://www.sportsdunia.com/gaming/brawl-stars-balance-changes-august-2026-released), consultado em 19 ago. 2026.
