# Catálogo de Materiais Públicos — Counter e Draft

## Regra de uso

Este catálogo não cria nem altera relações no motor do Draft. Um material só pode ser promovido de referência para revisão humana a evidência candidata quando identificar um autor ou organização, tiver data verificável, indicar uma direção de matchup entre brawlers e, idealmente, separar mapa/modo ou explicar a condição do counter. Vídeos, posts e PDFs sem pares literais continuam úteis para a revisão competitiva, mas não podem gerar bónus ou desbónus automaticamente.

## Lista de pesquisa

| Categoria | Objetivo | Estado |
|---|---|---|
| PDFs e documentos | Encontrar guias estruturados de draft, matchup ou counter com autoria e data. | Catalogado; não surgiu nova matriz auditável. |
| Vídeos | Encontrar análises competitivas recentes com pares de brawlers e contexto de mapa/modo. | Catalogado; úteis para revisão humana. |
| Posts competitivos | Encontrar threads e publicações datadas que apontem pares para auditoria manual. | Catalogado; variam por patch e autor. |
| Ferramentas de draft | Identificar sites que transformem picks inimigos em sugestões de counter e verificar transparência. | Catalogado; apenas fontes transparentes podem avançar. |

## Classificação

| Nível | Critério | Uso permitido |
|---|---|---|
| A — fonte literal rastreável | Pares direcionais publicados, origem e data verificáveis. | Candidata ao resolvedor, após auditoria. |
| B — evidência contextual | Pares ou recomendações por mapa/modo, mas sem export/metodologia integral. | Confirmação e revisão manual. |
| C — orientação estratégica | Guia, vídeo ou post com análise sem matriz verificável. | Formação, descoberta de pares e revisão humana. |
| D — conteúdo não auditável | Autor, data ou afirmação de matchup não comprováveis. | Não utilizar. |

## Materiais encontrados

| Material | Formato e data | Evidência encontrada | Nível | Uso recomendado |
|---|---|---|---|---|
| [Basic Drafting 101](https://www.reddit.com/r/BrawlStarsCompetitive/comments/1tmv5bv/basic_drafting_101/) — No-Emergency-7251 | Post competitivo, cerca de maio de 2026 | Publica princípios por pick e exemplos explícitos como Otis → Chester, Nani → Belle e Emz → Nita. | C | Revisão de fluxo de pick e descoberta de pares, nunca alimentar o motor. |
| [Drafting Tips for Ranked](https://brawlstars.fandom.com/f/p/4400000000000144559) — MetroDontTrustYou | Post comunitário, 4 set. 2025 | Lista pares e condições: Buster/Crow contra Cordelius, Tara/Kaze contra Gus, e recomendações por fase de pick. | C | Triangulação manual; está datado e é opinião comunitária. |
| [Every Counters for Each Brawlers](https://www.noff.gg/brawl-stars/app/build/17034/every-counters-for-each-brawlers--) — IDarkYsf_BrawlStars | Guia comunitário, atualizado em 31 ago. 2025 | Guia longo com pares direcionais e justificações mecânicas, mas declara que depende de mapa, outros matchups e circunstâncias. | C | Catálogo de candidatos para revisão humana; não converter pares diretamente em regras. |
| [Brawl Stars Meta Counters (May)](https://www.scribd.com/document/868292280/Brawl-Stars-Meta-Counters-May) — Tomás Hirmas | Documento/PDF, maio de 2025 | Declara ser lista visual de brawlers meta e respectivos counters; a pré-visualização não expõe os pares nem a metodologia. | D | Não utilizar até obter uma cópia acessível, atribuída e legível que permita confirmar os pares. |
| [Identifying and clustering counter relationships of team compositions in PvP games](https://arxiv.org/abs/2408.17180) | Artigo académico, 2024 | Estuda relações de counter de composições, incluindo modos trio de Brawl Stars, como metodologia de análise de equilíbrio. | B metodológico | Útil para desenho de uma futura matriz observada; não fornece lista atual de counters por brawler. |
| [The BEST COUNTERS to EVERY Brawler](https://www.youtube.com/watch?v=4sI_nX9TIts) — Bief | Vídeo, 10 jun. 2026, 14:39 | Descreve-se como guia dos melhores counters de todos os brawlers para uso no Draft; a página não expõe pares ou transcrição estruturada. | C | Fonte recente para revisão humana por vídeo; não extrair relações automaticamente. |
| [How To Counter All 95 Brawler!](https://www.youtube.com/watch?v=naUuJAvXHUE) — SnakeThug | Vídeo, 26 set. 2025, 48:25 | Tem capítulos por 95 brawlers e afirma explicar como counterá-los, mas fornece técnicas de jogo e não uma matriz explícita de pares. | C | Pesquisa manual de explicações mecânicas por brawler; não adicionar pares sem confirmação de outra fonte. |
| [Ultimate Cheat Sheet for Ranked — Season 53](https://www.youtube.com/watch?v=diaxHse4hOU) | Vídeo, 16 ago. 2026 | O resultado aponta mapa a mapa, mas a página pública consultada não disponibilizou conteúdo para verificação. | D | Reavaliar apenas se o vídeo/transcrição ficar publicamente acessível. |
| [Brawl Stars Drafting Guide (2026)](https://trophycoach.com/brawl-stars/guides/brawl-stars-drafting-guide) — TrophyCoach | Guia web, atualizado em jul. 2026 | Organiza o Draft por mapa/modo e apresenta padrões de counter, como anti-tanks contra 2 tanks, assassinos contra duas marksmen e quebra-paredes contra throwers. | B contextual | Útil para validar riscos de composição e alertas de Draft; não contém matriz completa nem metodologia observada para pares individuais. |
| [r/BrawlStarsCompetitive](https://www.reddit.com/r/BrawlStarsCompetitive/) | Discussões comunitárias contínuas | Descobre pares e problemas recentes de meta, mas a extração de vários tópicos devolve apenas o post inicial sem comentários verificáveis. | C/D variável | Usar apenas posts com autor, data e pares explícitos no próprio conteúdo; não usar comentários isolados como fonte. |
| [BrawlStars-Draft-Helper](https://github.com/mr-devlinder/BrawlStars-Draft-Helper) | Projeto de código aberto, criado em jun. 2026 | Expõe uma estrutura editável de dados para mapas, perfis e `globalCounters`; os dados de matchups são mantidos manualmente e podem receber overrides Supabase. | C | Referência de arquitetura e de formato de revisão, não fonte factual independente de pairs. |
| [ANDI-neV/brawl-ai](https://github.com/ANDI-neV/brawl-ai) | Projeto de código aberto, GPL-3.0 | Utiliza modelo treinável e batalhas recolhidas via API; declara atualizar o modelo perante patches, mas não publica matriz de counter legível nem validação por patch. | B metodológico / C factual | Referência para futura análise estatística própria; não copiar recomendações nem modelo GPL para este projeto. |
| [BrawlTrack Draft Tool](https://brawltrack.app/draft-tool) | Ferramenta web | A página pública apenas confirma analytics, meta e catálogo de API; não expõe relações de counter, método ou data de dados. | D factual | Não usar até API/documentação demonstrar pares explícitos e atualização rastreável. |
| [BrawlDraft](https://apps.apple.com/pl/app/brawldraft/id6761122238) | Aplicação móvel | Declara mostrar stats, counters e modos recomendados ao selecionar um brawler. | C pendente | Verificar se os dados são visíveis, datados e exportáveis; não integrar dados fechados. |
| [SpenLC guide to countering all brawlers](https://www.reddit.com/r/BrawlStarsCompetitive/comments/1ickl4x/spenlc_guide_to_countering_all_brawlers_up_to/) | Transcrição comunitária de vídeo, cerca de 2025 | Expõe uma lista extensa de counter-picks e condições mecânicas, declara que usa mapas 3v3 comuns e inclui ressalvas de modo, como Crow em Heist ou Piper em mapas abertos. Os comentários mostram discordâncias, confirmando que não é consenso estável. | B contextual / C factual | Excelente fila de auditoria por patch, mapa e direção; nunca promover pares diretamente nem tratar como fonte atual. |
| [SpenLC Ranked Cheat Sheet — Season 50](https://www.youtube.com/watch?v=z2ylbG5zFVk) | Vídeo de cheat sheet, maio de 2026 | A pesquisa confirma capítulos por mapa, mas a página pública estava indisponível para auditoria do conteúdo. | D no estado atual | Reavaliar quando existir transcrição ou página pública acessível; não usar como evidência. |
| [Noff Brawler Matchup](https://www.noff.gg/brawl-stars/brawler-matchup) | Ferramenta de comparação | Compara atributos base, taxa de vitória e taxa de pick de até três brawlers. Declara que só ajuda a estimar um duelo e não publica relações direcionais de counter. | B estatístico / D para counter | Usar apenas como contexto de atributos e métricas; não é fonte de counter para o resolvedor. |
| [PL Prodigy](https://powerleagueprodigy.com/) | Ferramenta de simulação de Draft | Declara simulações de draft e probabilidades, mas continua explicitamente excluída das fontes de counter do motor por decisão do projeto. | Não permitido | Não reintroduzir no resolvedor nem nos dados de counter. |

> **Conclusão provisória:** os materiais comunitários são bons para encontrar relações a auditar, sobretudo quando explicam a mecânica do matchup. Contudo, a data, o mapa e o patch são demasiado variáveis para os usar como fonte automática.

## Hierarquia operacional recomendada

| Camada | Fontes | Como pode afetar o Draft | Regra de segurança |
|---|---|---|---|
| 1 — Dados canónicos | BrawlScope e Brawl Calculator já integrados | Podem continuar a resolver relações literais, respeitando a prioridade atual. | Guardar fonte, direção e data de auditoria por relação. |
| 2 — Validação por mapa e patch | Deep Draft, BrawlBrawl e métricas públicas por mapa | Podem confirmar ou colocar uma relação em revisão quando o contexto de mapa altera o duelo. | Não sobrepor automaticamente a Camada 1; exigir comparação de patch e mapa. |
| 3 — Fila humana de evidência | Bief, SnakeThug, SpenLC, TrophyCoach, Noff e posts datados | Podem propor pares e explicações de mecânica para revisão. | Exigir dois elementos: par literal e fonte independente ou resultados observados suficientes. |
| 4 — Referência técnica | BrawlAI, BrawlStars-Draft-Helper e artigo académico | Podem inspirar recolha, análise e apresentação de dados. | Não importar modelo, código GPL ou ratings manuais como dados de counter. |
| 5 — Não utilizável | Vídeos indisponíveis, previews de PDF e ferramentas sem método/publicação de pares | Apenas descoberta futura. | Zero efeito no Score, recomendação ou resolvedor. |

> **Regra sazonal:** depois de cada balanceamento, marcar os brawlers alterados, revalidar somente os pares que os envolvem contra as Camadas 1 e 2, e manter qualquer conclusão de vídeo ou post como hipótese até ser confirmada. Assim, o Draft ganha atualização sem inventar counters nem copiar opiniões descontextualizadas.
