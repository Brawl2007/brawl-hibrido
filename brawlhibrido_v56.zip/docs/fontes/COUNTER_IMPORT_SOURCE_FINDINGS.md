# Descobertas de fontes — Importação de counters por mapa

Consulta realizada em 16 de agosto de 2026 para avaliar a possibilidade de importação automática com contexto de mapa e modo.

| Fonte | Evidência pública encontrada | Papel seguro no importador |
|---|---|---|
| [Brawl Planet](https://www.brawlplanet.com/) | Apresenta os melhores brawlers por mapa, incluindo win rate, pick rate e tier lists atualizados. | Usar para métricas de desempenho por `mapa + modo + brawler`; não inferir automaticamente uma direção de counter se a página não a expuser literalmente. |
| [Brawl Calculator — Maps](https://brawlcalculator.com/maps/) | Disponibiliza seleções fortes e bans por mapa. | Usar como contexto de mapa, prioridade de pick e ban; armazenar counter apenas quando a relação atacante → defensor estiver explicitamente exposta. |
| [Brawl Calculator — Counterpick](https://brawlcalculator.com/) | Disponibiliza calculadora de counterpicks e explicações de matchup. | Usar para relações globais literais de counter e dicas; aplicar como fallback quando não existir uma relação específica de mapa. |
| [Power League Prodigy](https://powerleagueprodigy.com/) | Disponibiliza guias de brawler e ferramenta de draft. | Usar relações literais dos guias como fonte global com proveniência; não atribuir mapa sem evidência literal. |

## Conclusão operacional

O importador deve separar **estatística por mapa** de **relação de counter**. Só cria uma relação de counter específica de mapa quando a fonte fornecer explicitamente o mapa e a direção. Caso contrário, grava a métrica do mapa e usa o counter global marcado como `scope = global`, sem fabricar um counter por mapa.

## URLs consultados

- https://www.brawlplanet.com/
- https://brawlcalculator.com/
- https://brawlcalculator.com/maps/
- https://powerleagueprodigy.com/
