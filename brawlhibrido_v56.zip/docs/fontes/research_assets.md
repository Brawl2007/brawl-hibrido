# Fontes de assets visuais

## Brawlify CDN

Fonte: [Brawlify/CDN no GitHub](https://github.com/Brawlify/CDN)

A CDN pública disponibiliza assets de Brawl Stars em `https://cdn.brawlify.com/`, extraídos do jogo ou do Fan Kit oficial. O repositório indica que os assets podem ser ligados diretamente por URL e que a licença do repositório é MIT, mantendo-se a obrigação de respeitar os Termos e a Fan Content Policy da Supercell.

Padrões relevantes documentados:

- Retratos sem moldura: `https://cdn.brawlify.com/brawlers/borderless/{brawlerId}.png`
- Retratos com moldura: `https://cdn.brawlify.com/brawlers/borders/{brawlerId}.png`
- Modelos de corpo inteiro: `https://cdn.brawlify.com/brawlers/model/{brawlerId}.png`
- Retratos largos: `https://cdn.brawlify.com/brawlers/portraits/{brawlerId}.png`
- Mapas: `https://cdn.brawlify.com/maps/regular/{mapId}.png`
- Modos: `https://cdn.brawlify.com/game-modes/regular/{modeId}.png`

A documentação de exemplo usa `https://cdn.brawlify.com/maps/regular/15000000.png` e `https://cdn.brawlify.com/brawlers/borders/16000000.png`. Os IDs exatos de cada brawler e mapa ainda precisam de ser associados à base local antes de ativar as imagens no código.

Fonte de mapas e rotação consultada: [Brawlify Maps](https://brawlify.com/maps). A página apresenta um atlas de mapas e modos e confirma que a rotação e o arquivo possuem mais mapas do que os 18 registos presentes na base local atual.

## Mapas adicionais verificados no Brawl Planet

As páginas abaixo foram consultadas e apresentam tabelas individuais com todos os brawlers, Win Rate e Pick Rate. Os valores completos devem ser extraídos para a base final; não usar estimativas.

| Mapa | Modo | URL |
|---|---|---|
| Rustic Arcade | Gem Grab / Pique-Gema | https://www.brawlplanet.com/maps/rusticarcade_gemgrab |
| Undermine | Gem Grab / Pique-Gema | https://www.brawlplanet.com/maps/undermine_gemgrab |
| Kaboom Canyon | Heist / Roubo | https://www.brawlplanet.com/maps/kaboomcanyon_heist |
| Safe Zone | Heist / Roubo | https://www.brawlplanet.com/maps/safezone_heist |
| Shooting Star | Bounty / Caça-Estrelas | https://www.brawlplanet.com/maps/shootingstar_bounty |
| Sneaky Fields | Brawl Ball / Fute-Brawl | https://www.brawlplanet.com/maps/sneakyfields_brawlball |
| Triple Dribble | Brawl Ball / Fute-Brawl | https://www.brawlplanet.com/maps/tripledribble_brawlball |
| Ring of Fire | Hot Zone / Zona Estratégica | https://www.brawlplanet.com/maps/ringoffire_hotzone |
| New Horizons | Knockout / Nocaute | https://www.brawlplanet.com/maps/newhorizons_knockout |

Os resumos principais publicados nas páginas confirmam, por exemplo: Rustic Arcade liderado por Glowy com 64,1%; Undermine liderado por Bolt com 66,7%; Kaboom Canyon liderado por Nori com 68,1%; Safe Zone liderado por Bolt com 69,7%; Shooting Star liderado por Bolt com 65,4%; Sneaky Fields liderado por Ash com 63,1%; Triple Dribble liderado por Juju com 61,4%; Ring of Fire liderado por Draco com 64,1%. A página de New Horizons ainda deve ser confirmada e extraída.

| New Horizons | Knockout / Nocaute | https://www.brawlplanet.com/maps/newhorizons_knockout |

New Horizons foi confirmada com 105 entradas, liderada por Bolt com 61,4% de Win Rate e Brock como maior Pick Rate com 44,5%.

## IDs TopBrawl dos mapas adicionais

| Mapa | TopBrawl ID | URL |
|---|---:|---|
| Rustic Arcade | 15000343 | https://topbrawl.com/rankeds/15000343 |
| Undermine | 15000011 | https://topbrawl.com/rankeds/15000011 |
| Triple Dribble | 15000025 | https://topbrawl.com/rankeds/15000025 |
| New Horizons | 15000703 | https://topbrawl.com/rankeds/15000703 |

O formato suportado pela página é `?rows=106`, mas a extração textual pública devolveu apenas os 10 primeiros resultados. A página local do Crystal Arcade confirma o padrão `https://topbrawl.com/rankeds/{id}?rows=106`; a extração completa dos 105 scores deve ser feita por browser/paginação ou por uma fonte local equivalente antes de calcular os novos registos.

## Verificação live da sincronização — 14/08/2026

Fonte testada: https://www.brawlplanet.com/maps/crystalarcade_gemgrab

A resposta HTTP foi 200, com aproximadamente 483 KB. O HTML contém textos de interface como `pickRate`, `starPlayerRate` e `winRate`, mas a inspeção do payload não encontrou ocorrências numéricas de `pickRate` nem campos `brawlerName`/`brawlerId` no formato esperado pelo parser actual. A sincronização end-to-end conseguiu recolher 2.835 linhas e marcar `topBrawl: success`, mas `brawlPlanet: failed`; por isso a última snapshot foi preservada com o estado da fonte explicitamente indicado, sem fabricar valores de Brawl Planet.
