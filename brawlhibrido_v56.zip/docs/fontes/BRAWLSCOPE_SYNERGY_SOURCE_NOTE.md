# Sinergia BrawlScope e quadro de equipas Brawl Planet

Data desta alteração: 11 de setembro de 2026.

## O que passou a existir

1. **Sinergia BrawlScope por brawler (Top 10).** Cada perfil público
   `https://brawlscope.com/counters?brawler=<slug>` publica três listas: `Counter with`
   (punido por), `Punishes` (pune) e `Pair with` (melhores aliados). As duas primeiras já
   alimentavam o Draft; a terceira passou a ser lida na mesma passagem do `counterSync`,
   preservando a ordem publicada e até dez nomes.
2. **Quadro literal de equipas por mapa.** O `rankedSync` já lia as dez composições de três
   brawlers publicadas na tabela *Teams* de cada mapa Ranked do Brawl Planet, mas só a melhor
   correspondência chegava ao Draft. Agora o quadro completo é exposto, ordenado pelo Win Rate
   publicado, com a posição e os Picks aliados que já pertencem a cada composição.

## Onde vive cada peça

| Camada | Ficheiro | Papel |
| --- | --- | --- |
| Tipo partilhado | `shared/counterSyncSnapshot.ts` | `SyncedSynergyRelation`, `getSnapshotSynergies`, `synergyRelationContextKey` |
| Catálogo estático | `shared/brawlScopeSynergyData.ts` | Listas literais `Pair with`, geradas pelo importador |
| Leitura live | `server/counterSync.ts` | Secção `Pair with` (BrawlScope) e `Best Teammates` (Brawl Planet) |
| Adaptador | `shared/counterSourceRelations.ts` | `getBrawlScopeSynergyTeammates`, `bestTeammates` do perfil BrawlScope |
| Draft | `shared/draft.ts` | Bónus de sinergia com prioridade de fonte e `bonusSources.brawlScopeSynergyTop` |
| Equipas do mapa | `shared/brawlPlanetMapTeams.ts` | `getBrawlPlanetMapTeamBoard`, `getBrawlPlanetMapTeamsForBrawler` |
| API | `server/routers.ts` | `rankedSync.mapTeams`, `counterSync.synergy` |
| Interface | `client/src/pages/BrawlerDetail.tsx` | Secção "Sinergia BrawlScope · Pair with", com o modo selecionado |
| Interface | `client/src/pages/Draft.tsx` | Painel "Equipas do mapa" com as 10 composições e os Picks já feitos em destaque |
| Importador | `server/scripts/import-brawlscope-synergies.mjs` | Gera o catálogo estático a partir das páginas públicas |

## A percentagem publicada é o bónus

Cada cartão de `Pair with` traz um valor — por exemplo, `Shade +11,6` na ficha da
Amber. É esse valor que o Draft aplica: +11,6 na fonte vale **+11,6%** no Score
quando Shade já está escolhido. Com dois aliados publicados, as duas percentagens
somam-se. Um aliado sem percentagem legível não recebe um número inventado: usa a
taxa de Sinergia por Pick configurada nas regras, como antes.

### Já funciona com o que está no projeto

A conversão vale para qualquer fonte que publique um valor por par, não só para o
BrawlScope. O catálogo do Brawl Planet já traz os melhores aliados com o delta
publicado, por isso o Draft aplica-o desde já: 8-Bit com Nori (+3,7) soma **+3,70%**;
com Nori e Ollie (+3,7 e +3,1) soma **+6,80%**. Quando a sincronização trouxer as dez
sinergias BrawlScope de cada brawler, elas entram pelo mesmo caminho e ganham
prioridade sobre o Brawl Planet.

## Regras preservadas

- **Nada é inferido.** Um perfil sem lista `Pair with` legível fica sem sinergia; não há
  reciprocidade automática nem preenchimento a partir do Brawl Planet ou do PL Prodigy.
- **Uma só fatia de bónus por candidato.** A composição literal do mapa continua a ser a
  evidência mais específica. Quando ela não existe, o bónus de sinergia usa a fonte mais
  prioritária que publicou o aliado já escolhido: BrawlScope antes de Brawl Planet — a mesma
  ordem aplicada aos counters. As fontes nunca acumulam.
- **Remoção só com duas leituras.** Uma sinergia que desaparece numa leitura completa fica
  marcada com `pendingRemoval`; apenas a segunda ausência a remove. Leituras incompletas nunca
  removem nada.
- **Sem fallback estático em produção.** Com uma snapshot live ativa, um titular sem lista lida
  devolve vazio em vez de recorrer ao catálogo do repositório. Uma fonte silenciosa também
  deixou de ganhar perfil a partir de dados estáticos.
- **Auditoria.** Cada relação de sinergia guarda a URL do perfil que a publicou e a posição
  ocupada na lista.

## Estado dos dados — recolhido

O catálogo tem agora **105 perfis e 1050 relações**: as dez sinergias publicadas de
cada ficha legível, com o valor de cada cartão. Recolhido da vista Overall + Lendário+
(`https://brawlscope.com/counters/<slug>`, sem filtros).

**Como foi verificado.** Cada ficha foi lida duas vezes, de forma independente. A
segunda leitura devolveu a taxa de vitória absoluta do par em vez do ganho; subtraindo
uma da outra, a baseline do titular tem de sair constante nas dez entradas — e sai, com
amplitude de 0,1 (o arredondamento da fonte):

| Brawler | Baseline implícita | Declarada na página |
|---|---|---|
| Rosa | 51,8 – 51,9 | 51,8% |
| Amber | 57,8 – 57,9 | — |
| Bonnie | 48,5 – 48,6 | — |
| Kit | 44,2 | — |

Um valor inventado não produziria dez números que diferem de outra leitura por exatamente
a mesma constante. As duas leituras devolveram ainda a mesma ordem e os mesmos nomes em
todos os perfis da amostra. Cruzando os 132 pares que aparecem nas duas fichas envolvidas,
o resíduo médio é de 0,16 pontos percentuais.

**Wendy fica de fora.** A ficha dela diz, com estas palavras, que nenhum lobby Ranked a
escolheu até agora, por isso não há nada medido para publicar.

## Estado anterior

O catálogo `shared/brawlScopeSynergyData.ts` está **vazio de propósito**. As páginas do
BrawlScope montam as listas completas no cliente, e o ambiente onde esta alteração foi escrita
não tem acesso de rede a `brawlscope.com` nem a `brawlplanet.com`; preencher o ficheiro aqui
significaria inventar relações, o que contraria a regra central do projeto.

Para popular:

```bash
node server/scripts/import-brawlscope-synergies.mjs --dry-run   # mostra a cobertura sem escrever
node server/scripts/import-brawlscope-synergies.mjs             # escreve shared/brawlScopeSynergyData.ts
```

O importador relata quantos perfis publicaram lista, quais ficaram sem lista legível e quais
expõem menos de dez aliados — essas listas parciais são preservadas exatamente como publicadas.

Independentemente do catálogo estático, a sincronização normal (`syncCounterData`) já recolhe a
sinergia em cada passagem: é esse o caminho usado em produção.

## Porque é que a sinergia não aparecia no Draft

Com uma snapshot live ativa mas ainda sem sinergias recolhidas — o estado normal de
produção antes de a recolha apanhar a secção "Pair with" — `getBrawlScopeSynergyTeammates`
devolvia lista vazia e o Draft ficava **sem sinergia nenhuma** do BrawlScope. O Brawl
Planet, esse, continuava a funcionar, porque os melhores aliados dele já recorriam ao
catálogo do repositório. Era uma incoerência: a regra estrita de "nada estático em
produção" existe para os counters, onde uma relação velha inverte direções, não para
uma lista de aliados.

O catálogo recolhido passa a valer como recurso, com a mesma prioridade do Brawl Planet:
lista live primeiro, catálogo depois. Resultado com a Amber:

| Aliado escolhido | Taxa aplicada |
|---|---|
| Shade | +11,50% |
| Gus | +6,50% |
| Finx | +2,30% |

## O que o cartão mostra

O chip de Sinergia identifica a fonte e detalha cada aliado:

> **Sinergia · BrawlScope** +12,60 pts (+18,00%)
> *Shade +11,5% (valor da ficha BrawlScope) · Gus +6,5% (valor da ficha BrawlScope)*

Quando o par não tem percentagem publicada, o texto di-lo: *"Gene · taxa fixa do pick 2"*.
É assim que se distingue de relance um valor vindo da ficha de um valor de regra.
