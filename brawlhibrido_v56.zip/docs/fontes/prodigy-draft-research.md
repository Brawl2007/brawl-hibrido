# Pesquisa pública do draft competitivo

Fonte principal: [PL Prodigy Draft Simulator](https://powerleagueprodigy.com/plprodigy), consultado em 14-08-2026.

Observações verificáveis na interface pública: o simulador tem um controlo `TURN` para avançar o turno e um `RESET`; inclui a opção `Show Enemy's View`; apresenta um seletor de mapa; mantém uma grelha de pesquisa de brawlers; e usa uma área central de confronto Azul vs Vermelho. A lista pública inclui Damian e Griff, entre outros brawlers. A referência útil para o Brawl Híbrido é tornar explícitos o turno ativo, a equipa que escolhe, a perspetiva do inimigo e a escolha direta de brawler, sem assumir que o utilizador está sempre a escolher pela mesma equipa.

A interface pública observada não deve ser tratada como prova de valores específicos de counter ou de probabilidade. Esses valores devem vir de métricas verificáveis do próprio snapshot/API/comunidade e ser apresentados como estimativas, não como factos absolutos.

Fontes adicionais encontradas para investigação posterior: [Brawl Calculator](https://brawlcalculator.com/) apresenta uma ferramenta pública de counters; [PL Prodigy no YouTube](https://www.youtube.com/@powerleagueprodigy) publica explicações sobre drafting; [How to use Prodigy to draft in Brawl Stars](https://www.youtube.com/watch?v=brppTol798E) é um tutorial público sobre o fluxo do Prodigy. O conteúdo de YouTube deve ser usado como princípio tático, não como fonte automática de números.
