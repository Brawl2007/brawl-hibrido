# Referência externa — Power League Prodigy Guides

A pesquisa pública identificou a página de guias do Power League Prodigy como referência estrutural para perfis de brawler:

- https://powerleagueprodigy.com/guides — “Brawler Guides | Best Builds, Gears, and Counters”. A página descreve guias concisos com builds, loadouts, gears, star powers, gadgets, modos e counters.
- https://powerleagueprodigy.com/ — página principal do PL Prodigy, com ferramentas de draft, guias de brawlers e insights de win probability.
- https://powerleagueprodigy.com/plprodigy — simulador de draft do PL Prodigy, usado como referência para recomendações contextuais em tempo real.

Nota de integração: o Brawl Híbrido usa estes guias como referência de estrutura e linguagem de produto. As relações de matchup apresentadas no catálogo são tratadas como leitura tática interna e devem continuar identificadas como contextuais quando não houver uma estatística pública verificável para o confronto exato.
