# Metodologia pública do Power League Prodigy

## Questão

Como o Power League Prodigy calcula recomendações de Draft e como isso difere do Brawl Híbrido?

## Evidência pública consultada

| Fonte | Informação verificável |
|---|---|
| [Página oficial do Draft Simulator](https://powerleagueprodigy.com/plprodigy) | Declara recomendações por mapa e apresenta uma base de jogos analisados no patamar Masters+. A página consultada indicava 1.427.531 jogos e atualização em 21 de agosto de 2026. |
| [Página inicial](https://powerleagueprodigy.com/) | Descreve recomendações "map-aware", meta do mapa, picks em tempo real e filtros de roster. |
| [Draft Practice](https://powerleagueprodigy.com/draftpractice) | Explica que lê mapa, bans e estado do Draft, classificando a escolha perante os picks disponíveis e apresentando os motivos mais relevantes. |
| [Anúncio do criador](https://www.reddit.com/r/BrawlStarsCompetitive/comments/12i4usi/power_league_prodigy_open_beta_now_live/) | Declara que considera mapa, modo de jogo e composições de equipa para recomendações. |

## Conclusão verificável

O Power League Prodigy **não publica uma fórmula numérica completa nem pesos públicos** para cada variável. Portanto, não é possível afirmar que usa uma média fixa de win rate, um valor de counter específico ou percentagens determinadas de sinergia. O que é publicamente declarado é um recomendador contextual que considera mapa, modo, bans, estado do Draft, composição de equipa, meta e disponibilidade do roster.

## Diferença para o Brawl Híbrido

O Brawl Híbrido é auditável: expõe o Score Híbrido, as fontes de counter, as regras de bónus/desbónus e as percentagens configuráveis. O Power League Prodigy comunica uma recomendação e os motivos relevantes, mas mantém os pesos internos do algoritmo como metodologia não publicada.
