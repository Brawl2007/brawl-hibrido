# Wendy — nota de proveniência

Consultado em 17 de agosto de 2026. Esta nota regista somente dados publicados usados para a entrada de catálogo pré-Ranked.

| Campo | Valor usado | Fonte |
|---|---|---|
| Nome | Wendy | [Brawlify — catálogo de 106 brawlers](https://brawlify.com/brawlers) |
| Estado | Fora da rotação Ranked atual no Brawl Híbrido; não criar métricas Ranked até as fontes da rotação a publicarem | Estado da snapshot interna atual |
| Classe | Suporte | [Brawl Stars Wiki — Wendy](https://brawlstars.fandom.com/wiki/Wendy) |
| Raridade | Mítica | [Brawl Stars Wiki — Wendy](https://brawlstars.fandom.com/wiki/Wendy) |
| Papel competitivo | Não atribuído manualmente enquanto não há dados Ranked | Decisão de não inferir dados |

As métricas de Trophy/Showdown encontradas em fontes externas não são usadas como substituto de métricas Ranked por mapa. Quando Brawl Planet e/ou TopBrawl publicarem Wendy na rotação Ranked, o sincronizador deverá incorporá-la como qualquer outro brawler que venha nas linhas de origem.

## Relações pesquisadas

| Tipo | Fonte | Uso previsto |
|---|---|---|
| Counters e melhores aliados | [Brawl Planet — Wendy](https://www.brawlplanet.com/brawlers/wendy) | Usar apenas itens que a página publicar literalmente. |
| Relações de matchup | [Power League Prodigy — Our thoughts on Wendy](https://powerleagueprodigy.com/blog/our-thoughts-on-wendy) | Aplicar apenas conclusões explícitas e preservar a prioridade do Prodigy em conflitos. |
| Dicas de Brawl Calculator | Pesquisa atual não devolveu página verificável de Wendy | Não criar dicas ou relações dessa fonte até haver conteúdo literal. |

As relações de perfil podem ser mostradas no catálogo de Wendy quando houver fonte publicada, mas Wendy continua indisponível no Draft e fora dos cálculos de Ranked até surgirem métricas reais por mapa.

## Relações verificadas em 17 de agosto de 2026

O Brawl Planet publicou Wendy como forte contra Nani, Mico, Gray, Crow e Gus; com dificuldades contra Trunk, Rosa, Ash, Charlie e Ollie; melhores aliados Trunk, Bonnie, Lou, Rico e Eve; e piores aliados Mortis, Mico, Kit, Sirius e Damian. A página também fornece os valores relativos de cada relação.

O artigo do Power League Prodigy descreve Ash como o principal counter de Wendy, com Tara, Nita, Charlie, Carl, Lola e Jessie como escolhas viáveis ou fortes contra ela. As relações de counter importadas devem respeitar a prioridade canónica de Prodigy do projeto; as sinergias e piores aliados permanecem exclusivamente literais do Brawl Planet.
