# Auditoria de referência — Power League Prodigy

Data da observação: 14 de agosto de 2026.

A página pública do Power League Prodigy posiciona o produto em torno de três ideias: recomendações conscientes do mapa, treino de decisões de Ranked com feedback imediato e filtros de roster. A página principal usa as expressões “live map-aware recommendations”, “Live picks”, “Map meta” e “Roster filters”. Também separa o simulador principal de Draft Practice, que é descrito como treino de cenários Ranked com feedback e dicas de coaching.

No simulador `/plprodigy`, a interface observável inclui seleção de mapa, botão de mudança de turno, reset, alternância “Show Enemy's View”, pesquisa de brawlers e ordenação alfabética. Isto sugere um fluxo centrado em contexto de mapa, perspetiva do adversário e controlo rápido do estado, não apenas numa lista estática de tiers.

Decisão de adaptação para Brawl Híbrido: usar a referência apenas para arquitetura de decisão e UX. O ranking local continuará a usar dados próprios e verificáveis. A recomendação principal será composta por Sinergia, Win Rate, Fit ao mapa/modo e Counter, com os pesos apresentados na interface e uma razão dominante por pick. O Score Híbrido ficará como sinal auxiliar de qualidade/consistência, não como fator dominante. Bans serão opcionais: um brawler banido pode continuar elegível para pick se o utilizador escolher esse fluxo de treino Ranked.

Fontes observadas:
- https://powerleagueprodigy.com/
- https://powerleagueprodigy.com/plprodigy
