# Fontes externas consultadas — counters e draft

## Brawl Calculator
URL: https://brawlcalculator.com/

A ferramenta apresenta um calculador de counterpick que aceita até três brawlers adversários e promete mostrar quem os countera, com páginas por brawler e por mapa. A própria página informa que os counterpicks são determinados principalmente por dados de ranking do SpenLC e atualizados em julho de 2026. Também declara que o material é não oficial e não é endossado pela Supercell.

## Power League Prodigy
URLs: https://powerleagueprodigy.com/ e https://powerleagueprodigy.com/guides

A página principal descreve draft map-aware com picks em tempo real, filtros de roster, treino de draft, feedback de coaching e guias de brawlers com builds e matchup strategy. A página `/guides` é dinâmica e não expôs a lista de matchups no extrator de texto; por isso, não foi usada como fonte numérica direta.

## Limites de evidência

As fontes públicas consultadas não fornecem uma tabela acessível e verificável para todos os 105 brawlers com percentagens 1v1. O Draft deve distinguir entre `counterRate` vindo de fonte e matchup heurístico/estruturado, mostrar a origem quando possível e não apresentar uma estimativa heurística como dado oficial. A API oficial também continua sujeita a fallback/403 ou timeouts no ambiente atual.
