# Pesquisa de referência — configuração competitiva do Draft

## Fonte consultada

- TrophyCoach, [Brawl Stars Drafting Guide (2026): Ranked Picks, Bans, Counters, and Team Comps](https://trophycoach.com/brawl-stars/guides/brawl-stars-drafting-guide), atualizado em 15 de julho de 2026.

## Síntese factual útil

O guia descreve três prioridades de Draft: banir o brawler que quebra o mapa, abrir com uma função segura para o mapa e guardar o último Pick para counter. A composição deve manter três funções distintas — controlo de lane, pressão de objetivo e reparação de matchup — em vez de repetir a mesma função. Também recomenda que o ban proteja os dois primeiros Picks da própria equipa e que o mapa/mode e a composição inimiga prevaleçam sobre uma recomendação genérica.

## Limite da evidência

A fonte não publica percentagens para o motor Brawl Híbrido. Qualquer tabela de percentagens é, portanto, uma predefinição interpretativa para treino competitivo, não uma configuração oficial de jogadores profissionais.

## Vídeos prioritários enviados pelo utilizador — metadados confirmados

| Vídeo | Criador e publicação | Escopo declarado ou capítulos confirmados | Limite atual da recolha |
|---|---|---|---|
| [The Best Draft Guide EVER](https://youtu.be/Vn13u4Uggqc) | bobby - brawl stars; 9 de abril de 2026 | Compreender brawlers (2:45), Draft por modo (28:58), meta (40:50), randoms (41:57) e prática (43:47). | A página expõe capítulos; a transcrição pública automatizada foi bloqueada pelo YouTube nesta rede. |
| [Complete Guide on How to Draft the Right Way in Ranked](https://youtu.be/qnlkt04fRg8) | Retalha Brawl; 4 de setembro de 2025 | Guia de Draft para Ranked, com duração de 8:04. | A página confirma o tema e o criador; não expõe texto de transcrição acessível neste ambiente. |
| [GUIA DE DRAFT! Se torne um PRO em DRAFT no BRAWL STARS!](https://youtu.be/Rp6f40I0uI0) | Bala; 28 de junho de 2025 | Counters (0:23), Draft (2:40), Bans (3:04), Picks (7:20), análise (10:26) e prática (12:09). | A página expõe capítulos; a transcrição pública automatizada foi bloqueada pelo YouTube nesta rede. |

> **Limite metodológico:** títulos, autoria, datas e capítulos foram confirmados diretamente nas páginas públicas. O YouTube bloqueou a extração automática das legendas e a análise de vídeo neste ambiente; nenhuma afirmação sobre falas específicas será atribuída aos vídeos sem evidência textual acessível.

## Padrões confirmados nas análises de vídeo

| Tema | Evidência do Retalha | Evidência do Bala | Padrão que pode orientar o Draft |
|---|---|---|---|
| Bans quando se tem first pick | Aos 0:40–1:02, recomenda manter aberto o brawler forte que a própria equipa quer escolher e banir counters do Pick planeado. | Aos 3:07–3:46, recomenda banir a resposta ao próprio first pick ou uma ameaça forte que a equipa não pretende selecionar. | O ban deve ser condicional à ordem de escolha e deve proteger a abertura própria. |
| Bans quando o adversário tem first pick | Aos 0:49 e 1:17, recomenda remover as ameaças mais fortes do mapa e respostas de last pick. | Aos 5:04–6:29, recomenda banir o brawler mais forte do mapa ou proteger o last pick futuro; também cita deixar o ban aberto quando há várias ameaças equivalentes. | O ban é guiado por mapa, ordem de Pick e número de ameaças viáveis, não por uma lista fixa. |
| First pick | Aos 2:01, orienta escolher um brawler forte no mapa com resposta a agressivos. | Aos 7:26, recomenda escolher a opção mais forte do mapa. | O first pick deve priorizar segurança e força no mapa, antes de um counter específico. |
| Escolhas intermédias | Aos 2:24–2:57, orienta responder ao primeiro inimigo sem abrir fraqueza para o last pick adversário. | Aos 10:11, pede diversidade de categorias; aos 13:19, mostra punir duas categorias iguais com respostas complementares. | Picks intermédios equilibram resposta, função e resistência ao last pick. |
| Sinergia | Aos 3:35, recomenda usar as escolhas duplas do meio para combinar com o aliado, por exemplo agressivo + suporte. | Aos 8:41, descreve uma estrutura de lateral agressivo, mid de alcance e lateral recuado/seguro em modos de controlo. | A sinergia é especialmente relevante no meio do Draft, mas deve preservar funções distintas. |
| Last pick | Aos 3:53, descreve-o como o momento de punir a composição inimiga; lançadores, assassinos e tanks ganham valor aqui. | Aos 8:08, diz para usar o Pick 6 especificamente para counterar brechas que o inimigo já não consegue responder. | O último Pick deve receber o maior peso de counter contextual, condicionado a mapa e composição. |

## Fontes de análise

1. [Retalha Brawl — Complete Guide on How to Draft the Right Way in Ranked](https://youtu.be/qnlkt04fRg8), análise de vídeo com marcações de tempo guardada em `research/youtube/retalha_draft_analysis.txt`.
2. [Bala — GUIA DE DRAFT! Se torne um PRO em DRAFT no BRAWL STARS!](https://youtu.be/Rp6f40I0uI0), análise de vídeo com marcações de tempo guardada em `research/youtube/bala_draft_analysis.txt`.
3. [bobby - brawl stars — The Best Draft Guide EVER](https://youtu.be/Vn13u4Uggqc), metadados e capítulos confirmados na página pública; a análise de conteúdo integral não ficou disponível neste ambiente.

## Predefinição recomendada — Competitivo por mapa e composição

Esta é uma **interpretação para o Brawl Híbrido**, e não uma configuração oficial de qualquer pro player. Os dois vídeos analisados concordam que a força no mapa decide a abertura, a sinergia e a diversidade de funções ganham importância no meio do Draft, e o último Pick deve punir a composição adversária.

| Regra configurável | Valor recomendado | Fundamentação observada |
|---|---:|---|
| Counter: Picks 1 e 5 | +7% | Diminui a tentativa de procurar um counter demasiado cedo; a abertura deve ser segura no mapa. |
| Counter: Picks 2, 4 e 6 | +10% | É o melhor compromisso do painel atual para resposta contextual e last pick. |
| Counter: Pick 3 | +6% | Mantém margem para a sinergia e cobertura de função no início do bloco intermédio. |
| Sinergia: Picks 1 a 6 | +5%, +5%, +10%, +7%, +10%, +5% | Valoriza os blocos intermédios, nos quais os vídeos recomendam combinar aliados e preservar funções distintas. |
| Ban: Picks 1 a 5+ | +5%, +4%, +3%, +2%, +1% | Mantém a abertura protegida; a escolha do alvo do ban deve continuar dependente de mapa e ordem de Pick. |
| Fit de posição | +8% | Reforça uma composição com lateral agressivo, mid e lateral seguro, sem substituir o score do mapa. |
| Counter Top | −2% por counter | Evita que counters ainda não escolhidos dominem excessivamente o ranking; o counter decisivo deve ser contextual ao Draft real. |
| Enemy Counter direto | −6% | Dá peso à resposta já revelada pelo inimigo. |
| Pressão de Counter inimigo | −6% / −10% | Aumenta a proteção contra uma equipa que expõe várias escolhas ao mesmo counter. |
| Mesma classe | −6% | Reflete a advertência contra repetir categorias e ficar vulnerável a uma só resposta. |
| Worst Teammate | −5% | Mantém uma penalidade moderada para pares publicados como fracos. |

> **Limite do painel atual:** a regra de Counter agrupa os Picks 2, 4 e 6. Os vídeos dão peso especial ao Pick 6; para reproduzir essa ideia com precisão, o próximo aperfeiçoamento seria criar campos de Counter independentes para cada Pick, tal como já existe para sinergia.

## Vídeos adicionais indicados pelo utilizador — estado de evidência

| Vídeo | Identificação confirmada | Evidência disponível | Limite |
|---|---|---|---|
| [2-JUC52qvu0](https://youtu.be/2-JUC52qvu0) | *Pro Ranked (Teaching Draft and Skill)*, publicado há cerca de três semanas na pesquisa pública | Título e tema | A página direta devolveu apenas um anúncio; não foi possível obter transcrição pública. |
| [sWZjFX03dDs](https://youtu.be/sWZjFX03dDs) | *How I Got PRO Rank with Randoms ONLY…* | Título, enquadramento de Ranked e objetivo declarado pelo resultado de pesquisa | A página direta devolveu apenas um anúncio; não foi possível obter transcrição pública. |
| [96AbcSgK2Iw](https://youtu.be/96AbcSgK2Iw) | *THE BEST DRAFT GUIDE EVER MADE*, de bobby - brawl stars, 25:59 | Título, criador e descrição pública sobre ensinar Draft para chegar a Masters | A análise audiovisual ficou indisponível no ambiente e a transcrição pública não foi exposta pelo YouTube. |

O resultado de pesquisa também confirma, para o guia mais antigo de Bobby, os capítulos **“Understanding Your Brawlers”**, **“How to Draft in Each Mode”**, **“Understand the Meta”** e **“How to Deal with Bad Randoms”**. Estes metadados sustentam a prioridade de conhecer brawlers, adaptar ao modo e considerar meta; não sustentam percentagens numéricas nem falas específicas.
