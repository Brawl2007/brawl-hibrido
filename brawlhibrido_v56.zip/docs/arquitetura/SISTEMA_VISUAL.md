# Sistema visual

## O diagnóstico

A sensação de desarrumação não vinha da quantidade de informação. Vinha de três
coisas medíveis:

| Medida | Antes | Depois |
|---|---|---|
| Cores hexadecimais distintas no CSS | **537** | **18 tokens** |
| Altura do hero antes do primeiro conteúdo útil | 280–310px | 0 (barra de 60px) |
| Blocos sempre abertos na página do Draft | 9 | 5 (4 colapsados) |
| Colunas em ecrã de 1440px | 1 | 1 (a grelha foi retirada — ver abaixo) |

A primeira linha é a mais importante. 537 cores para 35 variáveis não é uma
paleta — são 537 decisões avulsas. Roxo, âmbar, ciano, rosa e verde apareciam
todos saturados ao mesmo tempo, e **quando tudo brilha, nada se destaca**.

## Os tokens

Definidos em `client/src/index.css`, prefixados `--bh-` para não colidirem com o
tema dos componentes shadcn (que não pode ser tocado).

A regra é dar um **papel** a cada cor:

| Papel | Token | Quando aparece |
|---|---|---|
| Energia | `--bh-gold` | o número que mais importa, a ação principal. Nada mais. |
| Marca | `--bh-violet` | superfícies e bordas. Deixou de ser acento. |
| Sinal | `--bh-positive` / `--bh-negative` | exclusivamente a favor / contra |
| Dados vivos | `--bh-info` | recolha em direto, estado de ligação |
| Atenção | `--bh-warning` | fonte indisponível, dados por confirmar |
| Terreno | `--bh-ground` … `--bh-surface-3` | fundos, do mais escuro ao mais claro |
| Texto | `--bh-text` / `-muted` / `-dim` | hierarquia de leitura |

## O verificador (`pnpm check:css`)

Tokens criam um risco novo: **um token mal escrito não dá erro**. O CSS ignora a
declaração em silêncio e o elemento fica com a cor herdada — texto invisível,
borda que desaparece. Nada na consola, nada nos testes.

`scripts/check-css-tokens.mjs` falha quando um `var(--x)` não está definido em
lado nenhum. Encontrou logo um problema que já existia: `--ease-out` era usado em
três transições e nunca tinha sido declarado — essas transições simplesmente não
existiam.

## Carácter de jogo

Três coisas, todas baratas:

1. **Tipografia de display nos números** (Lilita One, com contorno escuro). Num
   sítio onde o que interessa é um Score, o número tem de ser a coisa mais
   presente do ecrã — não mais uma linha de texto.
2. **Peças com aresta inferior sólida**, aplicadas diretamente a `.draft-slot`,
   `.draft-recommendation` e `.refresh-button`. É o que separa "retângulo
   desenhado" de "botão que se carrega"; ao clicar, a peça afunda até à aresta.
3. **Âmbar usado com avareza.** Se estivesse em tudo, não valeria nada.

## Movimento com significado

Nunca movimento por enfeite. Cada animação responde a uma ação e explica uma
mudança:

- `CountUp` — o Score **percorre** a distância até ao novo valor. O que interessa
  não é o número final, é o salto: subiu ou desceu, e quanto. Um número que troca
  instantaneamente esconde essa informação.
- A lista de recomendações **reordena-se** com animação de posição, para se ver
  quem subiu depois de um pick.
- O slot **pisca uma vez** ao receber a escolha.

Tudo respeita `prefers-reduced-motion`. Sem isso, o movimento deixa de ser
detalhe e passa a problema de acessibilidade.

## Arrumação da página

A ordem passou a ser **trabalho primeiro, configuração depois**. Antes, o painel
de regras e os avisos ficavam acima do tabuleiro: o que se usa em cada draft
estava debaixo do que se configura uma vez.

Os painéis de consulta (`FoldPanel`) ficam fechados com uma **linha de resumo** —
nada é escondido, está tudo a um clique, mas deixou de estar tudo a pedir atenção
ao mesmo tempo.

A página mantém-se numa coluna. Houve uma tentativa de duas colunas acima de
1200px que partiu o Draft; está explicada a seguir.

## Dois erros que custaram uma publicação

Vale a pena ficarem registados, porque são fáceis de repetir.

**1. Sistema de design sem nenhum elemento a usá-lo.** A primeira versão definia
`.bh-piece` e `.bh-action` com todo o tratamento de peça física — e não os ligava
a nenhum componente. Zero usos no JSX. O site publicado ficou exatamente igual ao
anterior, e CSS morto não dá erro nenhum. Hoje o tratamento é aplicado
diretamente às classes que os componentes já usam (`.draft-slot`,
`.draft-recommendation`, `.refresh-button`), e o `pnpm check:css` avisa quando
uma classe `.bh-` não é usada por ninguém.

**2. Grelha de duas colunas sobre um layout que usava `order`.** `.draft-main`
era um flex em coluna cujos filhos se reordenavam com `order: -3 / -2 / -1`, e
`.draft-content > :not(.draft-arena)` dava-lhes margens de 7,2%. `order`
**continua a valer numa grelha**: ao trocar flex por grid, essas ordens antigas
passaram a lutar com as colunas atribuídas e as margens passaram a ser aplicadas
dentro de cada coluna. A página do Draft ficou desarrumada.

A grelha foi retirada. Para voltar, é preciso neutralizar primeiro o `order` e as
margens percentuais — e fazê-lo com o site à frente.

## Limite honesto

Nada disto foi visto renderizado: o ambiente de desenvolvimento não abre o site.
O que está garantido é que compila, que os tokens existem todos, que os testes
passam e que a estrutura é a descrita. **O julgamento de "está bonito" tem de ser
feito por uma pessoa em frente ao ecrã.**

Se algo ficar estranho, o primeiro sítio a olhar é o bloco de tokens no topo de
`index.css`; o segundo é o bloco "O tema aplicado aos elementos reais", no fim.
