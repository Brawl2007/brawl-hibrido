# Coleta de Partidas Observadas

## Objetivo

Esta coleta cria evidência para **matchups por mapa e modo** a partir de partidas públicas observadas. Ela não estima duelos, não completa lacunas e não altera relações de counter sem amostra suficiente.

## Fonte e cobertura

A fonte é a API oficial do Brawl Stars. A documentação informa que o acesso usa uma chave associada a endereços IP e está sujeito a limites de tráfego; portanto, a coleta é limitada e feita no servidor. [1]

| Item | Regra aplicada |
|---|---|
| Universo de amostragem | Jogadores do ranking global devolvidos pela API oficial. |
| Cadência | Uma execução por hora, em UTC, através de um Heartbeat do projeto. |
| Tamanho inicial | No máximo 12 jogadores e 25 registos recentes por jogador a cada execução. |
| Elegibilidade | Apenas batalhas cujo tipo indica Ranked, com duas equipas e mapa/modo identificados. |
| Identificação | Hash determinístico de hora, mapa, modo, equipas e equipa vencedora; duplicados são ignorados. |
| Agregação | Cada brawler da equipa vencedora recebe uma vitória contra cada brawler adversário; a equipa perdedora recebe a perda inversa. |
| Interpretação | É um resultado de equipa observado, não uma garantia de duelo de lane 1v1. |
| Limiar | Uma direção por mapa só poderá ser promovida a evidência de counter após pelo menos 30 observações. |

> Uma execução falhada não cria dados substitutos. Os registos já confirmados permanecem e a próxima execução volta a tentar apenas a coleta.

## Proteções operacionais

O coletor limita a concorrência das chamadas de battle log, usa timeout e grava primeiro a partida bruta. As agregações pendentes são processadas de forma idempotente: se houver falha entre a gravação da partida e a atualização do agregado, uma execução futura conclui a agregação sem duplicar a partida.

## Referências

[1]: https://developer.brawlstars.com/#/getting-started "Brawl Stars API — Getting Started"
