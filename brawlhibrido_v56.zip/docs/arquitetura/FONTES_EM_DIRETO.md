# Que fontes atualizam sozinhas

| Fonte | O que publica | Atualiza sozinha? |
|---|---|---|
| **BrawlScope** | matchups completos + sinergia "Pair with", em 7 vistas (geral + 6 modos) | ✅ uma vista por ciclo de 15 min |
| **Brawl Planet** | counters, counterados, melhores e piores parceiros | ✅ a cada ciclo |
| **PL Prodigy** | counters e counterados por guia | ✅ **desde agora** |
| **Brawl Calculator** | — | desativada; não participa em cálculos |

## Sinergias por modo: já funcionavam

Uma dúvida frequente: "as sinergias por modo (106×6) também atualizam?"

**Sim, e já antes desta ronda.** A recolha do BrawlScope percorre as sete vistas
e, em cada uma, lê a lista "Pair with" de cada ficha. As sinergias são gravadas
com o `modeId` da vista, e o Draft pede-as pelo modo do mapa ativo
(`getCounterSourceProfiles(row.brawler, context.mapModeId)`).

A seleção foi verificada de ponta a ponta:

```
sem modo   → Shade 11.6%
knockout   → Pam 22.2%          (a ficha de Nocaute manda)
heist      → Gus 5.5%
gemGrab    → Shade 11.6%        (sem dados do modo, cai para o geral)
```

Nunca se inventa um valor de modo: um par que o modo não publica usa o geral. O
que falta é apenas cobertura no catálogo de arranque a frio — o mesmo assunto
descrito em [`COUNTERS_POR_MODO.md`](COUNTERS_POR_MODO.md).

## PL Prodigy passou a ser lida em direto

Era a única das três que nunca atualizava: existia só como catálogo no
repositório, escrito por `server/scripts/import-prodigy-counters.mjs` corrido à
mão. O catálogo era uma fotografia do dia em que alguém se lembrou do comando.

O parser mudou-se para `shared/plProdigyParser.ts` (funções puras, testáveis) e
a sincronização passou a chamá-lo em cada ciclo, com concorrência 6.

### A disciplina, igual à das outras fontes

- **Menos de 60 guias lidas → não conta.** Parser partido, site em manutenção ou
  bloqueio não podem passar por "a fonte deixou de publicar": devolve-se o
  catálogo do projeto e diz-se porquê na nota da fonte.
- **`complete` só com o roster inteiro.** É `complete` que autoriza remover uma
  relação por ausência; uma leitura parcial informa sobre o que existe, nunca
  sobre o que deixou de existir.
- **Fonte bloqueada → nem se tenta.** Respeita-se o `blockedUntil` partilhado.

### Um defeito antigo, corrigido

O parser original procurava cada nome do roster na secção, do mais longo para o
mais curto. Faltava-lhe consumir o texto já lido: **"Larry & Lawrie" fazia
aparecer também "Larry"**, e "Bonnie" fazia aparecer "Bo". Brawlers que a página
nunca mencionou entravam nas listas e alimentavam o Draft.

Agora cada nome encontrado é mascarado no texto antes da procura seguinte. Há um
teste dedicado a este caso, porque é invisível a olho: a lista fica com um item a
mais e continua plausível.

## Limite honesto

A recolha nunca foi corrida contra as páginas reais a partir deste ambiente — não
há acesso a `powerleagueprodigy.com` daqui. O que está testado é o parser, contra
fixtures com a estrutura das guias, e a correspondência dos endereços gerados com
os 105 já auditados no catálogo. Se a estrutura do site tiver mudado, o efeito é
cair para o catálogo do projeto e dizê-lo — o comportamento de hoje, sem
regressão.
