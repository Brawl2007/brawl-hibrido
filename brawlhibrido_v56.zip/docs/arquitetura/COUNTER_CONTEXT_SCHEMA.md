# Modelo de Dados — Counters por Mapa e Modo

## Objetivo

O confronto não deve ser globalmente classificado como “Bea countera Bibi” ou “Bibi countera Bea”. A direção pode mudar conforme o **mapa** e o **modo de jogo**. Por isso, a relação armazenada deve representar sempre:

> **atacante → defensor, dentro de um contexto de mapa/modo, numa fonte específica.**

Com este modelo, `Bibi → Bea` pode ser válido em um mapa fechado de Fute-Brawl e `Bea → Bibi` pode ser válido em um mapa aberto de Caça-Estrelas, sem conflito.

| Entidade | Responsabilidade |
|---|---|
| `brawlers` | Catálogo canónico de brawlers, com `id` estável e nome de apresentação. |
| `game_modes` | Modalidades canónicas: Fute-Brawl, Pique-Gema, Nocaute, etc. |
| `ranked_maps` | Mapa e respetivo modo oficial. |
| `counter_sources` | Fonte literal da relação: Power League Prodigy, Brawl Calculator ou Brawl Planet. |
| `counter_relations` | Relação direcional de counter e o contexto onde é válida. |

## Esquema recomendado

```sql
CREATE TABLE counter_sources (
  id              BIGINT PRIMARY KEY AUTO_INCREMENT,
  code            VARCHAR(48) NOT NULL UNIQUE,
  display_name    VARCHAR(120) NOT NULL,
  priority         TINYINT NOT NULL DEFAULT 100,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE counter_relations (
  id                BIGINT PRIMARY KEY AUTO_INCREMENT,
  attacker_brawler_id BIGINT NOT NULL,
  defender_brawler_id BIGINT NOT NULL,
  mode_id           BIGINT NULL,
  map_id            BIGINT NULL,
  source_id         BIGINT NOT NULL,
  relation_type     ENUM('counter') NOT NULL DEFAULT 'counter',
  confidence        DECIMAL(5,4) NULL,
  sample_size       INT NULL,
  source_url        VARCHAR(1024) NULL,
  source_note       TEXT NULL,
  observed_at       DATETIME NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT chk_different_brawlers
    CHECK (attacker_brawler_id <> defender_brawler_id),
  CONSTRAINT fk_counter_attacker
    FOREIGN KEY (attacker_brawler_id) REFERENCES brawlers(id),
  CONSTRAINT fk_counter_defender
    FOREIGN KEY (defender_brawler_id) REFERENCES brawlers(id),
  CONSTRAINT fk_counter_mode
    FOREIGN KEY (mode_id) REFERENCES game_modes(id),
  CONSTRAINT fk_counter_map
    FOREIGN KEY (map_id) REFERENCES ranked_maps(id),
  CONSTRAINT fk_counter_source
    FOREIGN KEY (source_id) REFERENCES counter_sources(id)
);

CREATE UNIQUE INDEX uq_counter_relation_context
  ON counter_relations (
    attacker_brawler_id,
    defender_brawler_id,
    source_id,
    map_id,
    mode_id,
    relation_type
  );

CREATE INDEX ix_counter_lookup
  ON counter_relations (
    map_id,
    mode_id,
    attacker_brawler_id,
    defender_brawler_id,
    source_id
  );
```

`map_id` e `mode_id` são intencionalmente anuláveis. Eles representam três níveis de contexto, sem duplicar a tabela:

| Contexto | `map_id` | `mode_id` | Exemplo |
|---|---:|---:|---|
| Específico do mapa | preenchido | preenchido | Bea → Bibi em *New Horizons*, Nocaute. |
| Específico do modo | `NULL` | preenchido | Bea → Bibi em Caça-Estrelas, quando não há estatística por mapa. |
| Global | `NULL` | `NULL` | Relação editorial geral da fonte. |

## Regra de resolução usada pelo Draft

Ao recomendar o brawler **A** contra o brawler inimigo **B**, o Draft procura somente a direção `A → B`. Depois procura a direção contrária `B → A`, para saber se A é counterado por B. A seleção deve respeitar esta ordem:

1. Relação do **mapa e modo selecionados**.
2. Relação do **modo selecionado**, se não existir relação do mapa.
3. Relação **global**, apenas se os dois níveis anteriores não existirem.
4. Se a fonte escolhida publicar os dois sentidos **no mesmo contexto**, marcar como conflito e não aplicar ambos. A resolução pode usar `confidence`, `sample_size` e `counter_sources.priority`; se continuar empatada, aplicar efeito neutro e mostrar “dados conflitantes”.

O contexto mais específico vence sempre. Portanto, uma relação global `Bea → Bibi` não pode sobrepor uma relação específica de mapa `Bibi → Bea`.

## Consulta de resolução

Esta consulta devolve uma única relação aplicável entre dois brawlers, privilegiando mapa, depois modo, depois global. `:attacker`, `:defender`, `:mapId` e `:modeId` são parâmetros do Draft.

```sql
SELECT
  cr.*,
  cs.display_name AS source_name,
  CASE
    WHEN cr.map_id = :mapId THEN 3
    WHEN cr.map_id IS NULL AND cr.mode_id = :modeId THEN 2
    WHEN cr.map_id IS NULL AND cr.mode_id IS NULL THEN 1
    ELSE 0
  END AS context_rank
FROM counter_relations cr
JOIN counter_sources cs ON cs.id = cr.source_id
WHERE cr.attacker_brawler_id = :attacker
  AND cr.defender_brawler_id = :defender
  AND cs.is_active = TRUE
  AND (
    (cr.map_id = :mapId AND cr.mode_id = :modeId)
    OR (cr.map_id IS NULL AND cr.mode_id = :modeId)
    OR (cr.map_id IS NULL AND cr.mode_id IS NULL)
  )
ORDER BY
  context_rank DESC,
  COALESCE(cr.confidence, 0) DESC,
  COALESCE(cr.sample_size, 0) DESC,
  cs.priority ASC
LIMIT 1;
```

O motor deve executar a consulta para `A → B` e para `B → A`, **no mesmo contexto resolvido**. Se apenas `A → B` existir, A recebe o bónus de counter. Se apenas `B → A` existir, A recebe o desbónus de enemy counter. Se ambos existirem no mesmo nível e não for possível resolver pela qualidade da evidência, não se aplica bónus nem desbónus a esse par.

## Exemplo Bea–Bibi

| Mapa | Modo | Atacante | Defensor | Efeito no Draft |
|---|---|---|---|---|
| New Horizons | Nocaute | Bibi | Bea | Bibi recebe bónus; Bea recebe desbónus se Bibi for inimiga. |
| Shooting Star | Caça-Estrelas | Bea | Bibi | Bea recebe bónus; Bibi recebe desbónus se Bea for inimiga. |
| Global | — | Bea | Bibi | Só é usado quando não existe dado do mapa nem do modo. |

## Integração recomendada no Brawl Híbrido

O adaptador atual em `shared/counterSourceRelations.ts` pode continuar a preservar relações literais por fonte. A evolução deve acrescentar `mapId`, `modeId`, `sourceId`, `confidence` e `sampleSize` ao registo normalizado. O motor em `shared/draft.ts` deixa de comparar listas globais diretamente e passa a chamar um resolvedor com `{ mapId, modeId, attackerId, defenderId }`.

As páginas de brawler devem continuar a mostrar a proveniência. Quando uma relação for específica de mapa, a UI deve mostrar uma etiqueta como **“Nocaute · New Horizons · Brawl Calculator”**. Desta forma, o utilizador entende por que a direção muda entre mapas.

## Regras de integridade

1. Nunca armazenar um brawler como counter de si mesmo.
2. Nunca misturar relações de mapas diferentes no mesmo cálculo.
3. Não usar fallback global quando existir um dado específico para o mapa, mesmo que o global tenha maior prioridade editorial.
4. Não somar bónus e desbónus para o mesmo par no mesmo contexto.
5. Preservar `source_url`, data de recolha e tamanho de amostra para auditoria; não inventar relações quando a fonte não as fornece.
