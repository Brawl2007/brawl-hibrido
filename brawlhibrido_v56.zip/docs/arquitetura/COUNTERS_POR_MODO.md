# Counters por modo

## Porque é que isto importa

O BrawlScope publica a tabela de confrontos numa vista geral e em seis vistas por
modo. É tentador tratar a diferença como um detalhe. Não é.

Comparando as fichas de Nocaute recolhidas com a tabela geral, sobre 368 pares:

| Medida | Valor |
|---|---|
| Diferença média | **3,54 pontos percentuais** |
| Pares com diferença acima de 3 pp | 174 (47,3%) |
| **Pares que trocam de sinal** | **80 (21,7%)** |
| Maior diferença | 25,8 pp — Alli vs Kaze (Nocaute −22, geral +3,8) |

A linha que interessa é a terceira. Em **mais de um em cada cinco confrontos**, a
tabela geral diz "tu counteras" e a tabela do modo diz exatamente o contrário.
Usar a leitura geral num mapa de Nocaute não é uma aproximação — é estar errado
em 20% das recomendações de counter.

## Como funciona

### Recolha

`collectBrawlScopeModes` (`server/counterSync.ts`) percorre sete vistas: Overall
mais os seis modos, sempre na patente Lendário+. Para cada vista lê o índice,
recolhe as ~105 fichas com concorrência 8, e valida cada linha pelo checksum que
a própria página imprime (taxa do par − delta = média habitual do adversário).

A recolha é deliberadamente lenta: **uma vista por ciclo**, ciclos de 15 minutos
(`BRAWLSCOPE_VIEWS_PER_CYCLE`, `BRAWLSCOPE_MODE_SYNC_INTERVAL_MS`). São ~735
páginas por volta completa; ir mais depressa é pedir para ser bloqueado. O botão
"Atualizar agora" força as sete de uma vez.

### Leitura

`publishedDelta` (`shared/counterMatchupValue.ts`) escolhe por esta ordem:

1. matriz **em direto** do modo ativo;
2. tabela do modo no catálogo do repositório;
3. matriz em direto geral;
4. catálogo geral.

Nunca se inventa um valor de modo: um par que o modo não publica cai para o
geral, e é por isso que a leitura "Por modo" funciona mesmo com cobertura
parcial.

### Persistência — o que faltava

As matrizes viviam **só em memória**. Com uma vista por ciclo de 15 minutos,
reconstruir as sete do zero demora **1h45m**. Cada reinicialização do servidor
devolvia a leitura "Por modo" ao catálogo geral durante quase duas horas, sem
avisar ninguém — ou seja, na prática a funcionalidade estava desligada boa parte
do tempo e parecia ligada.

Agora são gravadas com a snapshot e recarregadas no arranque
(`restoreBrawlScopeMatchupMatrices`). Uma reinicialização deixou de custar nada.

#### O formato compacto

Sete vistas × ~105 fichas × ~100 adversários ≈ 77 mil números. Em JSON literal,
com o nome do adversário repetido em cada entrada, são **924 KB**.

`shared/matchupMatrixCodec.ts` guarda-os em **256 KB (28%)**, com duas ideias:

- **dicionário de nomes** — cada nome aparece uma vez, tudo o resto usa a posição;
- **uma linha por ficha, por posição** — `"45,-12,,3"` é o quarto nome com 0,3 e
  o terceiro ausente, sem gastar nada a repetir índices.

Os deltas guardam-se multiplicados por dez, como inteiros: uma casa decimal sem
perda e sem `0.30000000000000004`.

#### O que **não** viaja para os clientes

As matrizes estão na cópia gravada e são retiradas antes de a snapshot seguir
para o browser (`toPublicCounterSnapshotPayload`). Enviá-las no evento SSE seria
mandar centenas de milhares de números para cada separador aberto, a cada
sincronização — sem erro nenhum, só um site lento. Quem precisa de uma vista
pede-a por `counterSync.matchups`, uma de cada vez.

Há um teste dedicado a esta fronteira
(`server/matchupMatrixPersistence.test.ts`), porque uma regressão aqui não
apareceria como avaria.

## Estado

| Peça | Estado |
|---|---|
| Recolha das sete vistas | pronta, corre sozinha |
| Prioridade de leitura por modo | pronta |
| Persistência entre reinícios | pronta |
| Alternar geral / por modo na interface | pronto |
| Catálogo de arranque a frio no repositório | **4 fichas de Nocaute** (368 pares) |

O catálogo do repositório continua parcial de propósito: só serve para o primeiro
arranque de uma base de dados vazia. A partir da primeira sincronização completa,
quem manda é a recolha em direto — e agora ela sobrevive a reinícios.

Para encher o catálogo do repositório a partir de uma máquina com acesso à fonte:

```bash
node server/scripts/import-brawlscope-matchups.mjs            # os seis modos
node server/scripts/import-brawlscope-matchups.mjs --mode=knockout
```

## Limites honestos

- O ambiente de desenvolvimento não alcança `brawlscope.com`, por isso a recolha
  em direto nunca foi corrida aqui de ponta a ponta. O que está testado são os
  parsers, o formato compacto, a prioridade de leitura e a fronteira do que é
  gravado — tudo sobre dados reais já recolhidos.
- Um arranque a frio com base de dados vazia continua a demorar 1h45m a ter as
  seis vistas. Encher o catálogo do repositório com o importador é o que resolve
  isso de vez.
