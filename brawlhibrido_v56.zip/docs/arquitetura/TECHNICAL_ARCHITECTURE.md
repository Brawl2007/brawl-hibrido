# Documentação Técnica de Arquitetura — Brawl Híbrido

*Autor*: **Manus AI** [1]  
*Projeto*: Brawl Híbrido (Plataforma Esports-Grade de Dashboard e Draft para Brawl Stars) [2]  
*Versão de Referência*: Checkpoint `32346dc0` [3]

---

## 1. Visão Geral da Arquitetura

O **Brawl Híbrido** é uma aplicação web full-stack de alto desempenho concebida para jogadores competitivos de Brawl Stars. A aplicação combina análise estatística da rotação Ranked (27 mapas ativos), um motor de simulação de Draft em tempo real (com cálculo de win rate, bónus contextuais, penalidades e probabilidade bilateral) e uma matriz interativa de confrontos 1v1 baseada em logs oficiais de partidas.

### 1.1 Stack Tecnológica
- **Frontend**: React 19, Tailwind CSS v4, Lucide React, Wouter (routing), TanStack React Query [4].
- **Backend**: Node.js, Express v4, tRPC v11 (contratos e procedimentos tipados ponta a ponta) [5].
- **Base de Dados & ORM**: MySQL / TiDB geridos via Drizzle ORM e Drizzle Kit [6].
- **Testes**: Vitest (suite com 76 testes unitários e de regressão 100% aprovados) [7].
- **Infraestrutura**: Node 22, pnpm, suporte a build estático e backend serverless/autoscale em ambiente Manus [8].

---

## 2. Estrutura de Diretórios e Ficheiros Principais

```text
/home/ubuntu/brawl-hibrido/
├── client/
│   ├── src/
│   │   ├── App.tsx                    # Roteamento e layout shell (DashboardLayout)
│   │   ├── index.css                  # Estilos globais e tema Championship Arena
│   │   ├── pages/
│   │   │   ├── Home.tsx               # Dashboard principal e indicador de rotação Ranked
│   │   │   ├── Draft.tsx              # Simulador de Draft (equipas, bans, recomendações, Duelo Central)
│   │   │   ├── MatchupMatrix.tsx      # Matriz 1v1 filtrada por modo e mapa
│   │   │   ├── BrawlerDetail.tsx      # Ficha individual de brawler (Sinergias, Counters, Dicas)
│   │   │   └── ...
│   ├── index.html
├── server/
│   ├── routers.ts                     # Procedimentos tRPC (auth, dados, rankings, sync)
│   ├── db.ts                          # Procedimentos de consulta e Drizzle helpers
│   ├── draftEngine.test.ts            # Testes unitários do motor de Draft (62+ testes)
│   ├── brawlerCatalog.test.ts         # Testes de catálogo dos 105 brawlers
│   ├── counterSourceRelations.test.ts # Testes de proveniência multifuente
│   └── scripts/                       # Extratores reprodutíveis (Brawl Planet, Brawl Calculator)
├── shared/
│   ├── draft.ts                       # Motor central de Draft, classes, bónus e penalidades
│   ├── counterSourceRelations.ts      # Adaptador multifuente (Prodigy, Brawl Planet, Brawl Calculator)
│   ├── brawlPlanetRelationData.ts     # Dados de Best/Worst Teammates e Matchups
│   ├── brawlCalculatorCounterData.ts  # Dados táticos e razões (tips)
│   ├── prodigyCounterData.ts          # Counters literais do Power League Prodigy
│   └── observedMatchups.ts            # Matriz de partidas observadas da API oficial
├── drizzle/                           # Esquema Drizzle e migrações SQL
├── MIGRATION_GUIDE.md                 # Guia de transição e deploy
├── CONVERSATION_HISTORY_MEMORY.md     # Memória histórica completa de desenvolvimento
└── TECHNICAL_ARCHITECTURE.md          # Este documento técnico
```

---

## 3. Motores de Regras e Lógica de Negócio

### 3.1 O Score Híbrido
O score que avalia o desempenho dos brawlers nos mapas Ranked é calculado através da fórmula ponderada [9]:
$$\text{Score Híbrido} = (\text{Win Rate Brawl Planet} \times 0.80) + \left(\left(\frac{\text{Score TopBrawl}}{13}\right) \times 100 \times 0.20\right)$$

### 3.2 O Motor de Draft (`shared/draft.ts`)
O pontuador de brawlers livres calcula o `draftScore` agregando a pontuação base com bónus contextuais e penalidades acumulativas [10]:

$$\text{Draft Score} = \text{Hybrid Score} + \text{Counter} + \text{Missing Mid} + \text{Missing Side} + \text{Ban} + \text{Opening} + \text{Synergy} - \text{Enemy Counter Penalty} - \text{Same Class Penalty} - \text{Worst Teammate Penalty}$$

#### Ponderações Atuais dos Sinais:
- **Counter (Power League Prodigy)**: $+10\%$ por counter literal face a inimigos visíveis (com rácio duplicado se houver 2+ counters) [11].
- **Fit / Posicionamento (Mid / Side)**: $+7\%$ se a brawler encaixar na lane necessária [12].
- **Ban Rate**: $+3\%$ a $+7\%$ por counter direto banido [13].
- **Opening / Long Range**: $+4\%$ para brawlers com ataque principal $>4$ ou $>8$ blocos nas primeiras escolhas [14].
- **Sinergia (Best Teammates - Brawl Planet)**: $+4\%$ por aliado sinérgico na equipa [15].
- **Desbônus de Enemy Counter**: $-5\%$ por brawler inimigo que seja counter literal do candidato [16].
- **Desbônus de Mesma Classe**: $-5\%$ por aliado já escolhido na mesma classe (ex: Tanks, Lançadores, Snipers) [17].
- **Desbônus de Worst Teammate**: $-5\%$ acumulativo por cada aliado presente na lista de sinergia negativa (*Worst Teammates*) do Brawl Planet [18].

### 3.3 Integração Multifuente de Relações
As relações dos 105 brawlers estão unificadas em `shared/counterSourceRelations.ts`, que consome [19]:
1. **Power League Prodigy**: Autoridade primária para recomendação tática de Draft e counters literais.
2. **Brawl Planet**: Fornece *Best Teammates* (sinergias positivas) e *Worst Teammates* (sinergias negativas com deltas), além de *Matchups strong against* e *Struggles against*.
3. **Brawl Calculator**: Fornece razões táticas textuais (*tips/reasons*) exibidas no resumo final do Draft e nas duas perspetivas da Matriz 1v1.
4. **TopBrawl**: Fonte exclusiva de estatísticas de meta, builds e win rates (não publica listas diretas de counters).

---

## 4. Testes e Qualidade de Código

A aplicação possui uma suite de **76 testes unitários em Vitest** que cobrem integralmente [20]:
- A consistência do catálogo dos 105 brawlers e respetivas classes.
- A correção matemática do motor de Draft, aplicação de bónus e desbônus.
- A validade estrutural e ausência de duplicações nas listas multifuente.
- A integridade das amostras na Matriz 1v1 (limiar obrigatório de $\ge 30$ partidas por modo).

Para executar os testes no novo ambiente:
```bash
pnpm test
```

---

## 5. Procedimento de Transição e Reinstalação Noutro Ambiente

Para migrar a aplicação para um novo servidor, conta ou repositório:
1. **Descarregar o pacote de exportação** (`brawl-hibrido-export.zip`).
2. **Extrair os ficheiros** na nova raiz do projeto.
3. **Configurar as Variáveis Secretas** (via painel de segredos da plataforma ou ficheiro `.env` seguro):
   - `BRAWL_STARS_API_KEY`: Chave oficial da API da Supercell para consultas ao vivo [21].
   - Configurações de base de dados (`DATABASE_URL`, `JWT_SECRET`, etc.) fornecidas pelo runtime Manus.
4. **Instalar dependências e compilar**:
   ```bash
   pnpm install
   pnpm test
   pnpm build
   ```
5. **Publicar**: Guardar um checkpoint para acionar o deploy automático no novo domínio `manus.space`.

---

## Referências

- [1] Manus AI. *Especificação de Autoria e IA*. 2026.
- [2] Brawl Híbrido. *Repositório Oficial do Projeto*. Versão `32346dc0`.
- [3] Manus WebDev Runtime. *Checkpoint de Referência 32346dc0*. Agosto de 2026.
- [4] React Team. *React 19 Documentation*. https://react.dev
- [5] tRPC. *End-to-end typesafe APIs for TypeScript*. https://trpc.io
- [6] Drizzle Team. *Drizzle ORM Documentation*. https://orm.drizzle.team
- [7] Vitest Dev Team. *Fast Unit Testing Framework*. https://vitest.dev
- [8] Manus Platform. *Fullstack WebDev Template Guidelines*. 2026.
- [9] Brawl Híbrido. *Modelo Matemático do Score Híbrido*. Secção 1, 2026.
- [10] Brawl Híbrido. *shared/draft.ts*: Motor de Simulação de Draft.
- [11] Power League Prodigy. *Guide Resources & Counter Matrix*.
- [12] Brawl Híbrido. *Mapeamento de Lanes (Mid / Side)*.
- [13] Brawl Híbrido. *Regras de Banimento Dinâmico*.
- [14] Brawl Híbrido. *Parâmetros de Abertura e Long Range*.
- [15] Brawl Planet. *Meta Teammates Catalog*.
- [16] Brawl Híbrido. *Desbônus de Enemy Counter (-5%)*.
- [17] Brawl Híbrido. *Desbônus de Mesma Classe (-5%)*.
- [18] Brawl Planet. *Worst Teammates Negative Synergy Matrix*.
- [19] Brawl Híbrido. *shared/counterSourceRelations.ts*: Adaptador Multifuente.
- [20] Vitest Test Suite. *server/draftEngine.test.ts*, *server/brawlerCatalog.test.ts*, *server/counterSourceRelations.test.ts*.
- [21] Supercell Developer Portal. *Brawl Stars Official API Docs*. https://developer.brawlstars.com
