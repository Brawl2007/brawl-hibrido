# Guia de Migração e Reconstrução da Memória — Brawl Híbrido

Este documento serve como **memória operacional, técnica e de arquitetura** do projeto **Brawl Híbrido** para permitir a sua reinstalação, continuação e evolução numa nova conta ou ambiente Manus.

---

## 1. Visão Geral do Projeto
- **Nome do Projeto**: `brawl-hibrido`
- **Stack Tecnológica**: React 19, Tailwind CSS 4, Express 4, tRPC 11, Drizzle ORM (MySQL), Vitest.
- **Domínio Publicado**: `brawlhub-hv3h5xuy.manus.space`
- **Versão do Checkpoint**: `d3468f24`

---

## 2. Arquitetura de Dados e Fontes Oficiais Auditadas
O projeto baseia-se em dados reais e verificáveis, divididos em três fontes públicas principais:
1. **Power League Prodigy**: Fonte primária para o motor de Draft, recomendação de counters literais, bónus e penalidades.
2. **Brawl Planet**: Fonte para o ranking Ranked (27 mapas ativos, win rates e scores), além de Best Teammates (sinergias positivas) e Worst Teammates (sinergias negativas que ativam o desbônus de -5% no Draft).
3. **Brawl Calculator**: Fonte de dicas táticas textuais e direcionais (`reason`) apresentadas no resumo final do Draft e nas perspetivas da Matriz 1v1.
4. **TopBrawl**: Fonte exclusiva de estatísticas agregadas, modos e builds (sem listas públicas de counters).

---

## 3. Fórmulas e Regras de Negócio Implementadas
- **Score Híbrido**: `(Win Rate Brawl Planet * 0.80) + ((Score TopBrawl / 13) * 100 * 0.20)`
- **Penalidades no Draft**:
  - `-5%` por cada brawler inimigo pickado que seja counter literal (Prodigy) do brawler aliado.
  - `-5%` por cada aliado da mesma classe já escolhido na equipa (ex: múltiplos tanques).
  - `-5%` acumulativo por cada aliado na lista de Worst Teammate (Brawl Planet) do candidato.
- **Bónus no Draft**: Counter (+10%), Ban (+3%), Fit (+7%), Opening (+4%), Synergy (+4%).

---

## 4. Instruções para Importar na Nova Conta
1. **Exportação de Código**: Na conta original, descarregue o código fonte (através do painel de código ou ZIP).
2. **Criação do Projeto**: Na nova conta, crie um novo projeto web e importe/envie o código fonte.
3. **Variáveis Secretas (Secrets)**: Configure obrigatoriamente as chaves necessárias no painel de Segredos (Settings → Secrets), com destaque para:
   - `BRAWL_STARS_API_KEY`: Chave da API oficial do Brawl Stars.
4. **Instalação e Validação**:
   - Execute a instalação de dependências e os testes unitários para garantir que tudo compila sem erros:
     ```bash
     pnpm install
     pnpm test
     pnpm build
     ```
5. **Publicação**: Guarde um checkpoint na nova conta para publicar o site automaticamente no novo domínio Manus.

---
*Documento gerado automaticamente para suporte à migração de conta e preservação do contexto técnico.*
