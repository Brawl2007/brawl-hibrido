# Atualização live de counters e brawlers

O projeto agora mantém uma sincronização contínua no servidor. O processo consulta as fontes públicas de métricas e relações, grava o último snapshot válido e transmite cada snapshot novo para os navegadores conectados por **Server-Sent Events (SSE)**.

## O que atualiza

- **Ranked e brawlers:** TopBrawl e Brawl Planet, com IDs e nomes oficiais quando `BRAWL_STARS_API_KEY` estiver disponível.
- **Counters:** Brawl Calculator, Brawl Planet e BrawlScope por modo são lidos no snapshot atual; PL Prodigy e catálogos antigos ficam apenas para auditoria offline e não alimentam Draft ou perfil quando não há snapshot live.
- **BrawlScope por modo:** `Geral`, `Pique-Gema`, `Fute-Brawl`, `Nocaute`, `Roubo`, `Zona Estratégica` e `Caça-Estrelas` são armazenados separadamente por brawler. O seletor usa apenas a lista literal do modo escolhido.
- **Filtro do snapshot:** um brawler que não aparece no roster atual das fontes não é exibido como counter. A relação fica fora do perfil até voltar a ser publicada pela fonte.
- **Interface:** Dashboard, Draft, Brawlers e perfis individuais recebem o novo snapshot sem refresh manual da página.

## Intervalo padrão

O intervalo padrão é de **15 minutos**. A atualização em tempo real significa que, assim que o servidor conclui uma nova leitura, o navegador recebe o resultado imediatamente; as fontes públicas não oferecem um webhook para cada alteração editorial, portanto não é possível garantir atualização instantânea no segundo em que uma fonte muda.

As páginas por modo do BrawlScope são lidas, por padrão, no máximo uma vez por hora, porque o próprio BrawlScope informa que reconstrói os dados de hora em hora. O resultado fica em cache no servidor e não é buscado novamente a cada ciclo de 15 minutos.

Para alterar o intervalo, defina:

```env
BRAWL_LIVE_SYNC_ENABLED=true
BRAW_LIVE_SYNC_INTERVAL_MS=900000
BRAWLSCOPE_MODE_SYNC_INTERVAL_MS=3600000
```

O valor mínimo aceito é 60.000 ms (1 minuto). Para desligar o ciclo contínuo, use `BRAWL_LIVE_SYNC_ENABLED=false`. A API oficial do Brawl Stars é opcional:

```env
BRAWL_STARS_API_KEY=...
```

Sem essa chave, o servidor continua usando as fontes web configuradas. No cliente, se ainda não houver snapshot live, o perfil do brawler continua acessível, mas as listas de counters ficam vazias em vez de mostrar dados antigos.

## Créditos

Os **167 créditos** não são consumidos a cada atualização normal do site. O fluxo live é código do servidor e usa as fontes configuradas; créditos só seriam relevantes para uma execução adicional do agente ou para algum serviço externo que cobre por chamada. O custo operacional real depende do ambiente de hospedagem, limites das fontes e eventual uso da API oficial.

## Endpoint de diagnóstico

O servidor expõe `GET /api/realtime/status`, que retorna se o ciclo está habilitado, o intervalo em milissegundos e se existe uma sincronização em andamento.
