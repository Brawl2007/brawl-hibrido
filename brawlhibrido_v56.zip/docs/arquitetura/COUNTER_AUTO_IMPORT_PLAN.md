# Plano de importação automática de counters por mapa

## Princípio

O sistema deve importar **estatísticas por mapa** e **relações de counter** como dados diferentes. Uma relação `Bea → Bibi` só recebe contexto de mapa quando a fonte indicar de forma literal aquele mapa e aquela direção. Quando não houver essa evidência, mantém-se a relação global com proveniência explícita; não se deduz um counter a partir do win rate.

> Brawl Planet declara oferecer melhores brawlers por mapa com win rate, pick rate e tier lists, enquanto Brawl Calculator disponibiliza páginas de mapa e uma calculadora de counterpick. Isto permite enriquecer o contexto do Draft, mas não autoriza criar uma relação de counter específica de mapa quando a relação não for publicada literalmente. [1] [2] [3]

## Duas opções viáveis

| Opção | Fluxo | Vantagem | Limitação |
|---|---|---|---|
| **A. Coletor automático com dados literais** | Um job diário/lote percorre as páginas públicas autorizadas, extrai `modo`, `mapa`, `brawler`, métricas e relações explicitamente publicadas, normaliza os nomes e faz *upsert* no banco. | Escala sem introdução manual e preserva a fonte/origem. | Só cria counters por mapa quando a fonte realmente os expõe. |
| **B. Importação híbrida com revisão** | O coletor enche as métricas por mapa; relações de counter de mapa ficam numa fila de revisão até uma pessoa aprovar a fonte e direção. | Maior fidelidade em pares ambíguos e em fontes com conteúdo editorial. | Exige uma etapa manual para relações sem estrutura clara. |

## Recomendação

Usar a **opção B** inicialmente. Ela atualiza automaticamente win rate, pick rate, bans e score por `modo + mapa`, mas só publica um `counter por mapa` se houver evidência literal ou aprovação. Assim, não se troca automaticamente `Bibi → Bea` por `Bea → Bibi` apenas porque o desempenho mudou.

## Fluxo automatizado

1. Um agendamento diário, ou de hora em hora para métricas que comprovadamente atualizem nesse ritmo, obtém a rotação e as páginas de mapa.
2. O normalizador converte nomes de mapa, modo e brawler para IDs canónicos do banco.
3. O importador grava métricas em `map_brawler_metrics` com a origem, URL, data de coleta e valor bruto.
4. Se a página expuser literalmente um matchup, grava `counter_relations` com `mode_id`, `map_id`, `attacker_brawler_id`, `defender_brawler_id`, `source` e `source_url`.
5. Relações sem mapa são gravadas com `map_id = NULL` e `scope = global`; elas são fallback, não dado de mapa.
6. Antes da publicação, uma validação rejeita auto-counter, nomes desconhecidos, direções duplicadas na mesma fonte/contexto e relações sem URL de origem.
7. O Draft consulta na ordem: `mapa + modo` → `modo` → `global`; usa somente uma relação vencedora por confronto.

## Regra para Bea e Bibi

Se houver fonte literal para **Mapa A** indicando `Bibi → Bea` e outra para **Mapa B** indicando `Bea → Bibi`, as duas linhas coexistem porque têm `map_id` diferente. No Draft do Mapa A, somente a primeira é usada; no Draft do Mapa B, somente a segunda é usada. Um counter global entra apenas se faltar a linha do mapa escolhido.

## Proteções obrigatórias

| Validação | Regra |
|---|---|
| Proveniência | Toda linha precisa de `source` e `source_url`. |
| Direção | `attacker_brawler_id` e `defender_brawler_id` não podem ser iguais. |
| Duplicação | A mesma fonte não pode gravar duas direções do mesmo par no mesmo `mapa + modo`. |
| Fallback | Relação global não substitui relação específica do mapa. |
| Bans | O importador não muda a regra do Draft: bans não contam como Pick de mesma classe. |

## Implementação posterior

Para ligar isso ao site, o próximo passo é criar a migração das tabelas do documento `COUNTER_CONTEXT_SCHEMA.md`, implementar um importador idempotente e registrar um job agendado. A periodicidade deve respeitar a atualização real de cada fonte e os respetivos termos de utilização.

## Referências

[1] [Brawl Planet — Brawl Stars Stats & Tracker](https://www.brawlplanet.com/)

[2] [Brawl Calculator — Counterpick Calculator](https://brawlcalculator.com/)

[3] [Brawl Calculator — Best Brawlers by Map](https://brawlcalculator.com/maps/)
