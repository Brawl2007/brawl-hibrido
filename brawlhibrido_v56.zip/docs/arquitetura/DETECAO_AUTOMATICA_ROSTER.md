# Deteção automática de mapas e brawlers

## O problema

A Supercell troca os mapas da rotação Ranked a cada temporada e lança brawlers
novos de vez em quando. Até aqui, cada uma dessas mudanças era uma edição à mão
em `RANKED_MAP_SOURCES` (`server/rankedSync.ts`), no catálogo de classes e na
lista de alcances.

Enquanto ninguém editasse, o site continuava a mostrar a rotação da temporada
passada — **com toda a confiança**. É esse o ponto: não aparecia um erro, não
havia um aviso. Simplesmente estava errado e parecia certo.

## Como funciona agora

```
índice público  →  junção com a lista    →  quarentena  →  ativo
/rankeds           do projeto (fallback)     (recolhe)     (pontua)
```

### 1. Descoberta — `shared/rankedRotationSource.ts`

O índice do TopBrawl agrupa os mapas por modo e liga cada um a `/rankeds/<id>`,
onde `<id>` é o identificador oficial do mapa — o mesmo que a recolha por mapa
já usa. Uma leitura dá nome, modo e id de toda a rotação.

O slug do Brawl Planet é derivado do nome e do modo (`bellesrock_knockout`). A
regra foi validada contra os 26 slugs verificados à mão: dá exatamente os
mesmos. Ainda assim, quando o mapa já é conhecido, o slug do projeto ganha ao
derivado — um valor verificado vale mais que um inferido.

### 2. A rede de segurança

Um parser contra HTML de terceiros parte um dia. Mudam uma classe, e de repente
lêem-se zero mapas. Se esse resultado fosse aceite, o site concluía que a
rotação inteira acabou.

Por isso a leitura devolve sempre `complete`, e só é completa com pelo menos
**12 mapas** (`MIN_PLAUSIBLE_MAPS`). Abaixo disso cai-se para a lista do projeto
e a leitura é marcada como incompleta: serve para confirmar o que existe, nunca
para concluir que algo saiu.

### 3. Quarentena — `shared/rosterDiscovery.ts`

Funções puras, sem rede e sem escrita. Duas regras fazem o trabalho todo:

**Nada entra no Score sem dados.** Um mapa que entrou hoje ainda não tem
estatísticas publicadas em lado nenhum. Entra em quarentena: fica visível e
identificado como novo, continua a ser recolhido — é assim que ganha os dados —
mas não alimenta recomendações até ter pelo menos 20 linhas
(`MAP_PROMOTION_MIN_ROWS`). A promoção é automática, na primeira sincronização
em que os dados aparecerem.

**Nada sai sem duas provas.** A ausência só conta quando a leitura foi
**completa** — índice plausível *e* recolha por mapa sem falhas — e são precisas
duas leituras completas seguidas (`ROSTER_REMOVAL_STREAK`). Entre a primeira e a
segunda, o mapa fica marcado como "a sair" mas continua a contar normalmente. Se
reaparecer, a contagem reinicia.

É a mesma disciplina que o projeto já usava para remover relações de counter.

### 4. Brawlers

A API oficial (`/brawlers`) é a autoridade sobre quem existe. Um brawler novo
entra em quarentena com a lista do que lhe falta:

| Falta | Onde é usado |
|---|---|
| `classe oficial` | desbónus de classe repetida no mesmo time |
| `alcance de ataque` | bónus de abertura (alcance ≥ 6) |
| `dados por mapa` | Score Híbrido |

Sai da quarentena sozinho quando as três chegarem. Sem chave de API configurada
**não há leitura de brawlers** — e não ter leitura é muito diferente de ler uma
lista vazia: nesse caso a secção fica intocada.

### 5. Persistência

O estado vive no payload JSON da snapshot, não numa tabela nova. Foi uma escolha
deliberada: **não há migração de base de dados para correr na publicação**, e
uma migração falhada num deploy é exatamente o tipo de problema que este projeto
não pode ter. Snapshots antigas não têm o campo; a ausência é lida como "ainda
não avaliado".

## O que o utilizador vê

Um painel no Draft, que só aparece quando há alguma coisa a dizer: o que entrou
e o que ainda lhe falta, o que está a sair. Na maior parte dos dias não aparece
de todo.

## Limites honestos

- **O parser não foi corrido contra a página real.** A estrutura foi confirmada
  (nomes, ids e agrupamento por modo conferem com os 26 mapas atuais), mas o
  HTML exato não pôde ser lido no ambiente de desenvolvimento. Se o parser
  falhar em produção, o efeito é cair para a lista do projeto e assinalar a
  leitura como incompleta — o comportamento de hoje, sem regressão.
- **Um mapa novo não aparece no seletor até ser promovido.** Sem linhas
  publicadas não há nada para mostrar; o painel é que explica que ele existe e
  está a recolher dados.
- **A classe e o alcance de um brawler novo continuam a precisar de alguém.**
  O sistema deteta e diz o que falta, mas não inventa os valores. O que mudou é
  que agora se sabe, em vez de descobrir por acaso semanas depois.

## Testes

| Ficheiro | O que cobre |
|---|---|
| `server/rosterDiscovery.test.ts` | quarentena, promoção, remoção, falhas de rede |
| `server/rankedRotationSource.test.ts` | parser do índice, slugs, leitura incompleta |
| `server/rosterIntegration.test.ts` | uma mudança de temporada do princípio ao fim |
