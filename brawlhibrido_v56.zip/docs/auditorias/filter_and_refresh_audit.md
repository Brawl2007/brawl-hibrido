# Auditoria de Filtros, Tabela e Refresh Manual (Correção de Cobertura)

- **Data da Verificação**: 14/08/2026
- **Escopo**: Validação da tabela completa (DataTable), filtros por Tier, pesquisa de brawlers, ordenação por Score Híbrido/Win Rate/Uso e disparo de refresh manual autenticado.

## 1. Teste de Filtros da DataTable
- **Pesquisa por texto ("Piper")**: Retorna corretamente a brawler em todos os mapas filtrados.
- **Filtro por Tier ("S")**: Isolou apenas os registos com Score Híbrido >= 75, ocultando corretamente os demais sem alterar o total de 105 linhas do mapa.
- **Ordenação por Score Híbrido**: Alinha corretamente do maior para o menor valor, mantendo os 105 brawlers disponíveis.

## 2. Refresh Manual e Cobertura de Campos
- O endpoint `/api/trpc/rankedSync.refresh` foi auditado e exige autenticação (`UNAUTHORIZED` sem sessão válida), protegendo a sincronização contra triggers anónimos não autorizados.
- O snapshot live verificado via tRPC confirma **2.835 registos totais** (27 mapas × 105 brawlers), com cobertura completa de `brawlPlanetPickRate`, `brawlPlanetStarPlayer`, `brawlPlanetWinRate`, `topBrawlUseRate`, `topBrawlWinRate` e `topBrawlScore`.
