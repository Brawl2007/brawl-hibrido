# Validação do painel de regras percentuais

- A rota `/draft` respondeu e devolveu o conteúdo do Draft após a compilação de produção.
- O conteúdo confirmou textos que usam regras configuráveis nas sugestões e no rodapé do modelo.
- A captura visual dedicada e a inspeção seguinte ficaram indisponíveis porque o processo Chromium tinha sido encerrado para libertar memória antes da compilação.
- A suíte `server/draftEngine.test.ts` passou com 85 testes e a compilação de produção terminou sem erros de TypeScript.
