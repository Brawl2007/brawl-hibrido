# Verificação live da sincronização

Data da verificação: 2026-08-14 12:51:29 UTC.

O refresh manual devolveu `ok: true`, versão `live-20260814125129` e `rowCount: 2835`. A snapshot persistida recebeu a mesma versão, a mesma contagem e `capturedAt: 2026-08-14T12:51:29.000Z`. O estado global devolveu `lastStatus: success`, `snapshotVersion: live-20260814125129`, `rowCount: 2835` e `runCount: 4`.

O TopBrawl foi recolhido com estado `success`. O Brawl Planet foi registado como `failed` porque a resposta recebida não expôs linhas numéricas que o parser pudesse utilizar. O site não inventa esses valores: mantém a última snapshot válida e apresenta a limitação em `sourceNotes`.

```json
{
  "refresh": { "ok": true, "version": "live-20260814125129", "rowCount": 2835 },
  "snapshot": {
    "version": "live-20260814125129",
    "rowCount": 2835,
    "capturedAt": "2026-08-14T12:51:29.000Z",
    "sourceStatus": { "topBrawl": "success", "brawlPlanet": "failed" },
    "sourceNotes": "As respostas foram recebidas, mas o parser não encontrou linhas numéricas publicadas."
  },
  "status": {
    "lastStatus": "success",
    "snapshotVersion": "live-20260814125129",
    "rowCount": 2835,
    "runCount": 4
  }
}
```

## Verificação do dashboard

O dashboard foi aberto em viewport desktop após a integração live. A interface mostrou o selo `Sync 6h`, `27 mapas catalogados` e a indicação de última sincronização. A chamada tRPC do snapshot devolveu 2.835 linhas com `error: null`; os logs recentes do navegador e da rede não mostraram erros de snapshot, estado ou tRPC.

A validação de rota sem credenciais também devolveu HTTP 403 com `{ "error": "cron-only" }`, conforme esperado para o endpoint agendado.
