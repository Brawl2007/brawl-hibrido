# Validação visual local

## `/brawlers`

A rota renderizou corretamente após o carregamento da SPA, preservando a interface existente: sidebar, topbar, hero, filtros, tabela de alcance e catálogo de brawlers. O banner de estado mostra `FALLBACK ATIVO · bundled-static` quando não há snapshot live, sem erro visual. O endpoint SSE Ranked está montado no servidor e o cliente mantém a navegação disponível com fallback estático.

Ainda falta validar `/brawlers/Bibi` e `/draft` neste ciclo.

## `/brawlers/Bibi`

O perfil individual renderizou com imagem, Hybrid Score, Win Rate, Use Rate, listas Strong Against/Struggles Against, sinergias e fontes auditadas. A interface manteve o layout existente e o conteúdo é compatível com atualização reativa do catálogo; o perfil usa agora o estado Ranked global em vez de polling próprio.

## `/draft`

O Draft renderizou com a arena existente, 26 mapas ativos, seleção Beach Ball, sequência competitiva, equipas, recomendações, matriz de matchups e contexto de pick/ban. O estado de fallback aparece no topbar quando a base live ainda não está disponível. A lógica de recomputação é derivada de `rankedSync.snapshot`, enquanto os arrays de choices/skipped permanecem estado local e não são reinicializados por um novo snapshot.

## Validação desta recriação

A rota `/brawlers` carregou o catálogo completo com navegação lateral, identidade Brawl Híbrido, estado LIVE, 106 brawlers visíveis, ordenação por score e ligação para fontes auditadas.

A rota `/brawlers/Bibi` carregou o perfil individual com imagem, Hybrid Score 93.73, Win Rate 52.8%, Use Rate 32.4%, listas Strong Against e Struggles Against, cinco Best Teammates, cinco Worst Teammates e referências BrawlScope, Brawl Calculator, Brawl Planet e TopBrawl.

A rota `/draft` carregou o Draft competitivo com mapa Beach Ball, 26 mapas ativos, turnos de ban/pick para Azul e Vermelha, slots preservados, pesquisa, recomendações contextuais, posições, score híbrido, regras competitivas, matriz 1v1, counter top e estado Ranked.

A primeira captura instantânea mostrou a mensagem de carregamento enquanto a SPA iniciava; após a conclusão do carregamento, as três páginas renderizaram integralmente e responderam com conteúdo funcional no navegador.

## Validação em produção

O domínio permanente `https://brawlhbnd-4j4mbbym.manus.space` respondeu em `/brawlers`, `/brawlers/Bibi` e `/draft`. A primeira resposta de cada rota pode mostrar temporariamente “A carregar arena…” durante o cold start; após aguardar, a SPA renderiza integralmente.

Em `/brawlers`, o catálogo mostra 106 brawlers, navegação e estado de fallback Ranked. Em `/brawlers/Bibi`, o perfil mostra score 93.73, win rate 52.8%, use rate 32.4%, sinergias, counters e fontes auditadas. Em `/draft`, o workspace mostra Beach Ball, 26 mapas ativos, slots de ban/pick, recomendações contextuais, ordem de pick e matriz 1v1.

## Publicação permanente e Heartbeat

Domínio de produção: https://brawlhbnd-4j4mbbym.manus.space

O Heartbeat de produção está ativo com o nome `ranked-snapshot-sync`, task UID `LuXHMD2Y8Ruqub5QseZFeN`, expressão UTC `0 0 */6 * * *`, método `POST` e callback `/api/scheduled/rankedSync`. O job aparece como enabled na listagem de produção. O smoke test sem credenciais devolveu HTTP 403, confirmando a proteção cron-only do handler.
