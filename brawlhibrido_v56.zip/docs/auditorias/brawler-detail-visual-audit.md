# Auditoria visual — Brawler Detail

Data: 2026-08-14

## Desktop

- `/brawlers` mostra o catálogo com imagens, pesquisa, filtros e cartão de detalhe existente.
- `/brawlers/Bolt` abre uma página individual dedicada com imagem do brawler, Hybrid Score, Win Rate, Use Rate e contadores 8/8.
- A secção `BOLT COUNTERA` mostra oito cartões com imagem e nome: Grom, Mr. P, Buster, Frank, Squeak, Lumi, Leon e Carl.
- A secção `COUNTERAM BOLT` mostra oito cartões com imagem e nome: Charlie, Clancy, Damian, Nori, Starr Nova, Sprout, Gray e Ash.
- Cada cartão apresenta vantagem/ameaça estimada, posição e indicação de counter direto ou inferência por Win Rate.
- O CTA `Guides Prodigy` e o callout `Resources → Guides` estão visíveis como referência externa.
- O bloco de build e o CTA `Usar no Draft` aparecem no final do perfil.

## Observação

A página ficou legível e coerente com o Championship Arena. Os matchups não devem ser interpretados como garantias universais: continuam contextuais ao mapa, modo, composição e execução.

## Mobile

No viewport de 390px, `/brawlers/Bolt` mantém o cabeçalho, a imagem, os quatro indicadores, o callout de Guides, os oito counters e os oito counterados em colunas empilhadas. As imagens continuam legíveis e o CTA `Usar no Draft` permanece acessível. O catálogo também mantém os cartões e a barra de filtros em formato vertical; o perfil individual é a vista recomendada para consultar todas as relações.
