# Auditoria Final — Draft Ranked Reformulado

## 1. Categorias de Decisão (Coach Desk)
- **Pick Seguro**: Identificado em brawlers de estrutura estável (ex: Pearl, Brock no início).
- **Resposta**: Ativado quando há pressão de counter adversário (CTR >= 62).
- **Win Condition**: Ativado para brawlers com alto Fit de modo e Win Rate (FIT >= 78, WR >= 56).
- **Call Prioritária**: O Coach Desk destaca agora o brawler #1 da lista com a sua categoria prática.

## 2. Motor Contextual (SYN · WR · FIT · CTR)
- **Sinergia (30%)**: Pondera a cobertura de funções e picks aliados.
- **Win Rate (25%)**: Baseado no desempenho real no mapa.
- **Fit (25%)**: Ajuste ao objetivo específico do modo.
- **Counter (20%)**: Pressão dinâmica contra os picks inimigos.
- **Visual**: Cada cartão de recomendação mostra agora a linha de decisão (ex: "SEGURO · leitura prática do pick").

## 3. Fluxo de Ranked (Bans Opcionais)
- **Bans**: Podem ser ignorados usando o botão "Ignorar ban".
- **Elegibilidade**: Brawlers banidos continuam a aparecer nas recomendações de pick com a nota "BAN · PICK LIVRE", permitindo escolhas de segurança mesmo após o ban.
- **Bloqueio**: Apenas picks confirmados bloqueiam a seleção posterior.

## 4. Scrim Lab & Responsividade
- **Scrim Lab**: Preservado e funcional, permitindo configurar lado e sequência.
- **Mobile**: Layout adaptado com `coach-decision-strip` em 2 colunas e cartões densos legíveis.

## 5. Validação Técnica
- **Testes**: 29 testes Vitest aprovados (incluindo bans opcionais e ranking contextual).
- **Build**: Produção concluída com sucesso.
- **Browser**: Verificado em `https://3000-iyzy3beb2ifbpz5nljcv4-4012656b.us3.manus.computer/draft`.
