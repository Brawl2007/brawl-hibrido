# Notas de validação

## Bónus de banimento progressivo por pick

Em 16 de agosto de 2026, a suíte Vitest foi executada com êxito: **15 ficheiros e 101 testes aprovados**. As regressões cobrem a escala por counter banido de 5%, 4%, 3%, 2% e 1% para os picks 1 a 5; o sexto pick e posteriores mantêm o mínimo de 1%.

A pré-visualização do servidor de desenvolvimento foi reiniciada sem erros de TypeScript. Duas tentativas de captura automática da rota `/draft` falharam no mecanismo de captura, embora o servidor permaneça em execução; por isso, esta nota não trata a captura como evidência visual da interface.
