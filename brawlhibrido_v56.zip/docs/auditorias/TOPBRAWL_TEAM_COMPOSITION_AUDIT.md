# Auditoria de composições de equipa no TopBrawl

**Data de verificação:** 17 de agosto de 2026.

Foram consultadas a página geral Ranked e duas páginas individuais de mapas ativos: Flaring Phoenix (Knockout) e Crystal Arcade (Pique-Gema). Em todos os casos, o TopBrawl publica uma tabela **individual** por brawler, com `Wins %`, `Use %` e `Score`, bem como o total de jogos do mapa. Não foi encontrada uma tabela, cartão, endpoint público ou lista que apresente equipas de três brawlers, nem dez composições por mapa.

| Página verificada | Dados publicados | Evidência de equipa 3v3 literal |
| --- | --- | --- |
| [Ranked geral](https://topbrawl.com/rankeds) | Estatísticas agregadas por brawler e lista de mapas | Não encontrada |
| [Flaring Phoenix](https://topbrawl.com/rankeds/15000440) | Top brawlers, vitórias, uso, score e número de jogos | Não encontrada |
| [Crystal Arcade](https://topbrawl.com/rankeds/15000008) | Top brawlers, vitórias, uso, score e número de jogos | Não encontrada |

> **Decisão:** o Draft não deve inferir equipas a partir dos três brawlers individuais com maior Score, Win Rate ou Use Rate. Isso fabricaria uma sinergia que o TopBrawl não publica. As sinergias de equipa continuam exclusivamente fundamentadas nas composições literais do Brawl Planet já persistidas no snapshot Ranked.

Esta decisão preserva a separação de fontes: o TopBrawl permanece fornecedor de métricas individuais por mapa; o Brawl Planet é a origem das composições de equipa literais usadas no bónus de mapa.
