# Auditoria da exportação TSV

Data: 2026-08-14

- O Dashboard mostra os botões `Copiar TSV` e `Descarregar` na secção `Escolhe o teu mapa`.
- O seletor e os cartões continuam a apresentar 27 mapas.
- O cartão `Deathcap Trap` aparece como `Pique-Gema`.
- O cartão `Open Business` aparece como `Zona Estratégica`.
- O clique em `Copiar TSV` mostrou o feedback `27 mapas e modos copiados em TSV.`.
- O clique em `Descarregar` mostrou o feedback `TSV dos 27 mapas descarregado.`.
- A lista exportada usa o catálogo canónico, com cabeçalho `Mapa<TAB>Modo` e 27 linhas de dados.
