# Auditoria de revalidação do Draft publicada

Data: 2026-08-14.

A rota publicada `/draft` já apresenta no conteúdo extraído o painel **Lane & Mid 1v1 / MATCHUP MATRIX**, com a mensagem de espera quando ainda não existem picks dos dois lados. O cabeçalho do modelo expõe os pesos Uso 4%, Fit 13%, Win Rate 20%, Sinergia 10%, Counter 40% e Ban Rate 20%. O Draft publicado mostra cinco opções no Quick Pick Rail e 25 cartões na primeira página da lista principal, com paginação de cinco páginas para o roster de 105 brawlers.

A auditoria também indica que a lista completa está renderizada no DOM e o botão `VER LISTA COMPLETA DE RECOMENDAÇÕES` está presente. Falta concluir a validação interativa do salto do botão e confirmar que a ordenação varia por função em situações com contexto aliado/inimigo; não se deve marcar esses itens como concluídos antes dessa confirmação.

A matriz 1v1 utiliza os picks aliados e adversários atuais, cruza counters explícitos e, quando não existe relação catalogada, calcula uma percentagem de confronto baseada na diferença de Win Rate. O estado observado estava 0 vs 0, portanto ainda não permitia validar o caso real de lane/mid.
