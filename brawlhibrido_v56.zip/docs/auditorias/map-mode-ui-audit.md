# Auditoria UI dos modos dos mapas — 2026-08-14

## Dashboard `/`

A verificação no preview ativo confirmou que o Dashboard mostra **27 mapas únicos** nos cartões e que o filtro de modo contém exatamente: Todos, Nocaute, Roubo, Fute-Brawl, Pique-Gema, Caça-Estrelas e Zona Estratégica.

Lista observada no texto acessível dos cartões:

| # | Mapa | Modo mostrado |
|---:|---|---|
| 01 | Belle's Rock | Nocaute |
| 02 | Bridge Too Far | Roubo |
| 03 | Center Stage | Fute-Brawl |
| 04 | Crystal Arcade | Pique-Gema |
| 05 | Deathcap Trap | Pique-Gema |
| 06 | Double Swoosh | Pique-Gema |
| 07 | Dry Season | Caça-Estrelas |
| 08 | Dueling Beetles | Zona Estratégica |
| 09 | Flaring Phoenix | Nocaute |
| 10 | Gem Fort | Pique-Gema |
| 11 | Hard Rock Mine | Pique-Gema |
| 12 | Hideout | Caça-Estrelas |
| 13 | Hot Potato | Roubo |
| 14 | Layer Cake | Caça-Estrelas |
| 15 | Open Business | Zona Estratégica |
| 16 | Out in the Open | Nocaute |
| 17 | Parallel Plays | Zona Estratégica |
| 18 | Pinball Dreams | Fute-Brawl |
| 19 | Rustic Arcade | Pique-Gema |
| 20 | Undermine | Pique-Gema |
| 21 | Kaboom Canyon | Roubo |
| 22 | Safe Zone | Roubo |
| 23 | Shooting Star | Caça-Estrelas |
| 24 | Sneaky Fields | Fute-Brawl |
| 25 | Triple Dribble | Fute-Brawl |
| 26 | Ring of Fire | Zona Estratégica |
| 27 | New Horizons | Nocaute |

## Draft `/draft`

O seletor acessível do Draft apresentou os mesmos rótulos canónicos no contexto do mapa, incluindo:

- `Belle's Rock · Nocaute`
- `Bridge Too Far · Roubo`
- `Center Stage · Fute-Brawl`
- `Crystal Arcade · Pique-Gema`
- `Deathcap Trap · Pique-Gema`

A área de contexto visível confirmou `Crystal Arcade · Pique-Gema`, e o cartão do mapa também mostrou `Pique-Gema`.

## Conclusão

A UI servida após a normalização da snapshot apresenta os 27 nomes uma única vez, sem a associação incorreta anterior de `Deathcap Trap` a Fute-Brawl ou de `Open Business` a Roubo. A mesma fonte normalizada é aplicada pelo servidor ao payload persistido, pelo Dashboard ao estado live e pelo Draft ao seletor e ao contexto do mapa.
