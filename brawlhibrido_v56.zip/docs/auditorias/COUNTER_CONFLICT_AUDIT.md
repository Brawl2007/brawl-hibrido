# Auditoria de Counters Contraditórios

> **Data da auditoria:** 2026-08-16  
> **Âmbito:** relações literais carregadas no Draft a partir de Power League Prodigy, Brawl Calculator e Brawl Planet. Esta auditoria não inventa dados nem altera relações publicadas pelas fontes.

## Resultado dos testes

A suíte Vitest foi executada em modo sequencial com limite de memória. O resultado foi **14 ficheiros aprovados e 90/90 testes aprovados**. O aviso HTTP 403 exibido no teste da API oficial é um cenário de fallback esperado e coberto pelo respetivo teste.

## O que mudou no cálculo

As listas literais das fontes foram preservadas. A alteração está exclusivamente no **motor de decisão do Draft**: para um mesmo par, ele escolhe uma única direção pela prioridade **Power League Prodigy → Brawl Calculator → Brawl Planet**. Se a fonte prioritária publicar os dois sentidos com força equivalente, o par fica **neutro**; não aplica simultaneamente bónus de counter e desbónus de enemy counter.

| Indicador | Resultado |
|---|---:|
| Perfis de fonte auditados | 316 |
| Pares direcionais auditados | 2336 |
| Pares com direções opostas | 132 |
| Contradições dentro da mesma fonte | 28 |
| Pares resolvidos para uma única direção | 107 |
| Pares neutralizados pela fonte prioritária ambígua | 25 |
| Brawlers envolvidos em pelo menos um par | 93 |

## Brawlers afetados

Cada linha indica os brawlers que estavam em pares com direções opostas. **Pares** é a quantidade de pares contraditórios ligados ao brawler; **Neutralizados** é a quantidade desses pares que o Draft deixou sem efeito por ambiguidade na fonte prioritária.

| Brawler | Pares | Neutralizados | Pares contraditórios associados |
|---|---:|---:|---|
| 8-Bit | 1 | 0 | 8-Bit × Ash |
| Angelo | 1 | 0 | Angelo × Chuck |
| Ash | 7 | 2 | 8-Bit × Ash; Ash × Barley; Ash × Juju; Ash × Larry & Lawrie; Ash × Nita; Ash × Otis; Ash × Surge |
| Barley | 4 | 1 | Ash × Barley; Barley × Carl; Barley × Najia; Barley × Ollie |
| Bea | 10 | 1 | Bea × Belle; Bea × Bibi; Bea × Edgar; Bea × Gene; Bea × Gray; Bea × Jae-yong; Bea × Lola; Bea × Meeple; Bea × Ruffs; Bea × Sprout |
| Belle | 2 | 0 | Bea × Belle; Belle × Chuck |
| Berry | 3 | 2 | Berry × Mandy; Berry × Piper; Berry × Squeak |
| Bibi | 3 | 0 | Bea × Bibi; Bibi × Bolt; Bibi × Maisie |
| Bo | 1 | 0 | Bo × Hank |
| Bolt | 8 | 0 | Bibi × Bolt; Bolt × Buster; Bolt × Colette; Bolt × Glowy; Bolt × Maisie; Bolt × Mandy; Bolt × Otis; Bolt × Willow |
| Bonnie | 3 | 0 | Bonnie × Chuck; Bonnie × Piper; Bonnie × R-T |
| Brock | 2 | 0 | Brock × Crow; Brock × Mandy |
| Bull | 1 | 0 | Bull × Leon |
| Buster | 1 | 0 | Bolt × Buster |
| Buzz | 1 | 1 | Buzz × Griff |
| Byron | 2 | 0 | Byron × Clancy; Byron × Crow |
| Carl | 3 | 0 | Barley × Carl; Carl × Jacky; Carl × Surge |
| Charlie | 2 | 0 | Charlie × Chuck; Charlie × Jae-yong |
| Chester | 1 | 0 | Chester × Gale |
| Chuck | 12 | 1 | Angelo × Chuck; Belle × Chuck; Bonnie × Chuck; Charlie × Chuck; Chuck × Clancy; Chuck × Colt; Chuck × Gale; Chuck × Jae-yong; Chuck × Ollie; Chuck × Otis; Chuck × Squeak; Chuck × Tara |
| Clancy | 2 | 0 | Byron × Clancy; Chuck × Clancy |
| Colette | 7 | 2 | Bolt × Colette; Colette × Jae-yong; Colette × Mandy; Colette × Meeple; Colette × Meg; Colette × Mico; Colette × Sprout |
| Colt | 3 | 0 | Chuck × Colt; Colt × Rosa; Colt × Sprout |
| Cordelius | 1 | 0 | Cordelius × Ruffs |
| Crow | 3 | 0 | Brock × Crow; Byron × Crow; Crow × Rosa |
| Damian | 3 | 0 | Damian × Gale; Damian × Rosa; Damian × Stu |
| Darryl | 1 | 0 | Darryl × Jessie |
| Draco | 1 | 0 | Draco × Trunk |
| Dynamike | 1 | 1 | Dynamike × Grom |
| Edgar | 1 | 0 | Bea × Edgar |
| Emz | 2 | 1 | Emz × Gus; Emz × Piper |
| Eve | 2 | 1 | Eve × Pearl; Eve × Piper |
| Fang | 1 | 0 | Fang × Griff |
| Finx | 2 | 1 | Finx × Grom; Finx × Mandy |
| Frank | 4 | 2 | Frank × Janet; Frank × Jessie; Frank × Penny; Frank × Rico |
| Gale | 4 | 0 | Chester × Gale; Chuck × Gale; Damian × Gale; Gale × Janet |
| Gene | 5 | 1 | Bea × Gene; Gene × Glowy; Gene × Mr. P; Gene × Piper; Gene × Squeak |
| Gigi | 1 | 0 | Gigi × Sirius |
| Glowy | 2 | 0 | Bolt × Glowy; Gene × Glowy |
| Gray | 1 | 0 | Bea × Gray |
| Griff | 3 | 2 | Buzz × Griff; Fang × Griff; Griff × Ruffs |
| Grom | 3 | 1 | Dynamike × Grom; Finx × Grom; Grom × Lumi |
| Gus | 4 | 1 | Emz × Gus; Gus × Mandy; Gus × Piper; Gus × R-T |
| Hank | 1 | 0 | Bo × Hank |
| Jacky | 4 | 1 | Carl × Jacky; Jacky × Kenji; Jacky × Otis; Jacky × Surge |
| Jae-yong | 7 | 2 | Bea × Jae-yong; Charlie × Jae-yong; Chuck × Jae-yong; Colette × Jae-yong; Jae-yong × Pierce; Jae-yong × Ziggy; Jae-yong × Sirius |
| Janet | 2 | 1 | Frank × Janet; Gale × Janet |
| Jessie | 3 | 0 | Darryl × Jessie; Frank × Jessie; Jessie × Piper |
| Juju | 1 | 0 | Ash × Juju |
| Kenji | 2 | 0 | Jacky × Kenji; Kenji × Nita |
| Larry & Lawrie | 1 | 0 | Ash × Larry & Lawrie |
| Leon | 2 | 0 | Bull × Leon; Leon × Rosa |
| Lola | 2 | 0 | Bea × Lola; Lola × Sprout |
| Lou | 2 | 1 | Lou × Poco; Lou × Sirius |
| Lumi | 2 | 0 | Grom × Lumi; Lumi × Mandy |
| Maisie | 3 | 0 | Bibi × Maisie; Bolt × Maisie; Maisie × Mandy |
| Mandy | 13 | 4 | Berry × Mandy; Bolt × Mandy; Brock × Mandy; Colette × Mandy; Finx × Mandy; Gus × Mandy; Lumi × Mandy; Maisie × Mandy; Mandy × Nita; Mandy × Pam; Mandy × Pearl; Mandy × Sandy; Mandy × Trunk |
| Max | 1 | 0 | Max × Poco |
| Meeple | 3 | 0 | Bea × Meeple; Colette × Meeple; Meeple × Ollie |
| Meg | 1 | 0 | Colette × Meg |
| Mico | 2 | 0 | Colette × Mico; Mico × Penny |
| Mina | 1 | 0 | Mina × Trunk |
| Mortis | 1 | 0 | Mortis × Nita |
| Mr. P | 3 | 1 | Gene × Mr. P; Mr. P × Penny; Mr. P × Tick |
| Najia | 1 | 0 | Barley × Najia |
| Nani | 1 | 1 | Nani × Pearl |
| Nita | 5 | 0 | Ash × Nita; Kenji × Nita; Mandy × Nita; Mortis × Nita; Nita × Poco |
| Nori | 1 | 0 | Nori × Sirius |
| Ollie | 5 | 0 | Barley × Ollie; Chuck × Ollie; Meeple × Ollie; Ollie × Penny; Ollie × Surge |
| Otis | 4 | 2 | Ash × Otis; Bolt × Otis; Chuck × Otis; Jacky × Otis |
| Pam | 1 | 0 | Mandy × Pam |
| Pearl | 3 | 3 | Eve × Pearl; Mandy × Pearl; Nani × Pearl |
| Penny | 4 | 1 | Frank × Penny; Mico × Penny; Mr. P × Penny; Ollie × Penny |
| Pierce | 1 | 0 | Jae-yong × Pierce |
| Piper | 8 | 0 | Berry × Piper; Bonnie × Piper; Emz × Piper; Eve × Piper; Gene × Piper; Gus × Piper; Jessie × Piper; Piper × R-T |
| Poco | 3 | 1 | Lou × Poco; Max × Poco; Nita × Poco |
| R-T | 3 | 0 | Bonnie × R-T; Gus × R-T; Piper × R-T |
| Rico | 2 | 1 | Frank × Rico; Rico × Shelly |
| Rosa | 6 | 0 | Colt × Rosa; Crow × Rosa; Damian × Rosa; Leon × Rosa; Rosa × Spike; Rosa × Sprout |
| Ruffs | 4 | 2 | Bea × Ruffs; Cordelius × Ruffs; Griff × Ruffs; Ruffs × Surge |
| Sandy | 1 | 0 | Mandy × Sandy |
| Shelly | 1 | 0 | Rico × Shelly |
| Sirius | 4 | 0 | Gigi × Sirius; Jae-yong × Sirius; Lou × Sirius; Nori × Sirius |
| Spike | 1 | 0 | Rosa × Spike |
| Sprout | 6 | 2 | Bea × Sprout; Colette × Sprout; Colt × Sprout; Lola × Sprout; Rosa × Sprout; Sprout × Tara |
| Squeak | 3 | 3 | Berry × Squeak; Chuck × Squeak; Gene × Squeak |
| Stu | 1 | 0 | Damian × Stu |
| Surge | 5 | 1 | Ash × Surge; Carl × Surge; Jacky × Surge; Ollie × Surge; Ruffs × Surge |
| Tara | 2 | 1 | Chuck × Tara; Sprout × Tara |
| Tick | 1 | 0 | Mr. P × Tick |
| Trunk | 3 | 0 | Draco × Trunk; Mandy × Trunk; Mina × Trunk |
| Willow | 1 | 0 | Bolt × Willow |
| Ziggy | 1 | 1 | Jae-yong × Ziggy |

## Todos os pares contraditórios e o resultado atual no Draft

Uma “direção canónica” significa que apenas o efeito indicado pode alterar o score. “Neutralizado” significa que nenhum dos dois sentidos altera o score até existir evidência contextual mais específica por mapa/modo.

| Par | Tipo detetado | Direções literais publicadas | Regra atual no Draft | Resultado |
|---|---|---|---|---|
| 8-Bit × Ash | Divergência entre fontes | Brawl Planet: 8-Bit → ash<br>Power League Prodigy: ash → 8-Bit | Ash → 8bit (Power League Prodigy) | Direção canónica |
| Angelo × Chuck | Divergência entre fontes | Brawl Calculator: angelo → chuck<br>Brawl Planet: chuck → angelo | Angelo → Chuck (Brawl Calculator) | Direção canónica |
| Ash × Barley | Contradição na mesma fonte | Brawl Planet: barley → ash<br>Power League Prodigy: ash → barley / barley → ash | Neutro — sem bónus nem desbónus | Neutralizado |
| Ash × Juju | Divergência entre fontes | Brawl Planet: juju → ash<br>Power League Prodigy: ash → juju | Ash → Juju (Power League Prodigy) | Direção canónica |
| Ash × Larry & Lawrie | Divergência entre fontes | Brawl Planet: Larry & Lawrie → ash<br>Power League Prodigy: ash → Larry & Lawrie | Ash → Larry & Lawrie (Power League Prodigy) | Direção canónica |
| Ash × Nita | Divergência entre fontes | Brawl Planet: nita → ash<br>Power League Prodigy: ash → nita | Ash → Nita (Power League Prodigy) | Direção canónica |
| Ash × Otis | Contradição na mesma fonte | Power League Prodigy: ash → otis / otis → ash | Neutro — sem bónus nem desbónus | Neutralizado |
| Ash × Surge | Divergência entre fontes | Brawl Calculator: surge → ash<br>Brawl Planet: ash → surge | Surge → Ash (Brawl Calculator) | Direção canónica |
| Barley × Carl | Divergência entre fontes | Brawl Planet: barley → carl<br>Power League Prodigy: carl → barley | Carl → Barley (Power League Prodigy) | Direção canónica |
| Barley × Najia | Divergência entre fontes | Brawl Calculator: barley → najia<br>Power League Prodigy: najia → barley | Najia → Barley (Power League Prodigy) | Direção canónica |
| Barley × Ollie | Divergência entre fontes | Brawl Planet: barley → ollie<br>Power League Prodigy: ollie → barley | Ollie → Barley (Power League Prodigy) | Direção canónica |
| Bea × Belle | Divergência entre fontes | Brawl Planet: belle → bea<br>Power League Prodigy: bea → belle | Bea → Belle (Power League Prodigy) | Direção canónica |
| Bea × Bibi | Divergência entre fontes | Brawl Planet: bea → bibi<br>Power League Prodigy: bibi → bea | Bibi → Bea (Power League Prodigy) | Direção canónica |
| Bea × Edgar | Divergência entre fontes | Brawl Planet: bea → edgar<br>Power League Prodigy: edgar → bea | Edgar → Bea (Power League Prodigy) | Direção canónica |
| Bea × Gene | Divergência entre fontes | Brawl Planet: gene → bea<br>Power League Prodigy: bea → gene | Bea → Gene (Power League Prodigy) | Direção canónica |
| Bea × Gray | Divergência entre fontes | Brawl Calculator: bea → gray<br>Brawl Planet: gray → bea | Bea → Gray (Brawl Calculator) | Direção canónica |
| Bea × Jae-yong | Divergência entre fontes | Brawl Calculator: bea → Jae-yong<br>Brawl Planet: Jae-yong → bea<br>Power League Prodigy: bea → Jae-yong | Bea → Jae-Yong (Power League Prodigy) | Direção canónica |
| Bea × Lola | Divergência entre fontes | Brawl Calculator: bea → lola<br>Power League Prodigy: lola → bea | Lola → Bea (Power League Prodigy) | Direção canónica |
| Bea × Meeple | Divergência entre fontes | Brawl Calculator: bea → meeple<br>Brawl Planet: meeple → bea | Bea → Meeple (Brawl Calculator) | Direção canónica |
| Bea × Ruffs | Divergência entre fontes | Brawl Planet: ruffs → bea<br>Power League Prodigy: bea → ruffs | Bea → Ruffs (Power League Prodigy) | Direção canónica |
| Bea × Sprout | Contradição na mesma fonte | Brawl Calculator: sprout → bea<br>Brawl Planet: sprout → bea<br>Power League Prodigy: bea → sprout / sprout → bea | Neutro — sem bónus nem desbónus | Neutralizado |
| Belle × Chuck | Divergência entre fontes | Brawl Planet: chuck → belle<br>Power League Prodigy: belle → chuck | Belle → Chuck (Power League Prodigy) | Direção canónica |
| Berry × Mandy | Contradição na mesma fonte | Power League Prodigy: berry → mandy / mandy → berry | Neutro — sem bónus nem desbónus | Neutralizado |
| Berry × Piper | Divergência entre fontes | Brawl Planet: piper → berry<br>Power League Prodigy: berry → piper | Berry → Piper (Power League Prodigy) | Direção canónica |
| Berry × Squeak | Contradição na mesma fonte | Power League Prodigy: berry → squeak / squeak → berry | Neutro — sem bónus nem desbónus | Neutralizado |
| Bibi × Bolt | Divergência entre fontes | Brawl Planet: bibi → bolt<br>Power League Prodigy: bolt → bibi | Bolt → Bibi (Power League Prodigy) | Direção canónica |
| Bibi × Maisie | Divergência entre fontes | Brawl Planet: maisie → bibi<br>Power League Prodigy: bibi → maisie | Bibi → Maisie (Power League Prodigy) | Direção canónica |
| Bo × Hank | Divergência entre fontes | Brawl Planet: bo → hank<br>Power League Prodigy: hank → bo | Hank → Bo (Power League Prodigy) | Direção canónica |
| Bolt × Buster | Divergência entre fontes | Brawl Planet: buster → bolt<br>Power League Prodigy: bolt → buster | Bolt → Buster (Power League Prodigy) | Direção canónica |
| Bolt × Colette | Divergência entre fontes | Brawl Calculator: colette → bolt<br>Brawl Planet: colette → bolt<br>Power League Prodigy: bolt → colette | Bolt → Colette (Power League Prodigy) | Direção canónica |
| Bolt × Glowy | Divergência entre fontes | Brawl Planet: glowy → bolt<br>Power League Prodigy: bolt → glowy | Bolt → Glowy (Power League Prodigy) | Direção canónica |
| Bolt × Maisie | Divergência entre fontes | Brawl Planet: maisie → bolt<br>Power League Prodigy: bolt → maisie | Bolt → Maisie (Power League Prodigy) | Direção canónica |
| Bolt × Mandy | Divergência entre fontes | Brawl Calculator: mandy → bolt<br>Brawl Planet: bolt → mandy<br>Power League Prodigy: bolt → mandy | Bolt → Mandy (Power League Prodigy) | Direção canónica |
| Bolt × Otis | Divergência entre fontes | Brawl Planet: otis → bolt<br>Power League Prodigy: bolt → otis | Bolt → Otis (Power League Prodigy) | Direção canónica |
| Bolt × Willow | Divergência entre fontes | Brawl Calculator: willow → bolt<br>Brawl Planet: bolt → willow<br>Power League Prodigy: willow → bolt | Willow → Bolt (Power League Prodigy) | Direção canónica |
| Bonnie × Chuck | Divergência entre fontes | Brawl Planet: chuck → bonnie<br>Power League Prodigy: bonnie → chuck | Bonnie → Chuck (Power League Prodigy) | Direção canónica |
| Bonnie × Piper | Divergência entre fontes | Brawl Calculator: piper → bonnie<br>Brawl Planet: bonnie → piper<br>Power League Prodigy: piper → bonnie | Piper → Bonnie (Power League Prodigy) | Direção canónica |
| Bonnie × R-T | Divergência entre fontes | Brawl Calculator: R-T → bonnie<br>Brawl Planet: bonnie → R-T | R-t → Bonnie (Brawl Calculator) | Direção canónica |
| Brock × Crow | Divergência entre fontes | Brawl Planet: brock → crow<br>Power League Prodigy: crow → brock | Crow → Brock (Power League Prodigy) | Direção canónica |
| Brock × Mandy | Divergência entre fontes | Brawl Calculator: mandy → brock<br>Power League Prodigy: brock → mandy | Brock → Mandy (Power League Prodigy) | Direção canónica |
| Bull × Leon | Divergência entre fontes | Brawl Calculator: bull → leon<br>Brawl Planet: leon → bull<br>Power League Prodigy: bull → leon | Bull → Leon (Power League Prodigy) | Direção canónica |
| Buzz × Griff | Contradição na mesma fonte | Power League Prodigy: buzz → griff / griff → buzz | Neutro — sem bónus nem desbónus | Neutralizado |
| Byron × Clancy | Divergência entre fontes | Brawl Calculator: clancy → byron<br>Brawl Planet: byron → clancy | Clancy → Byron (Brawl Calculator) | Direção canónica |
| Byron × Crow | Divergência entre fontes | Brawl Calculator: byron → crow<br>Power League Prodigy: crow → byron | Crow → Byron (Power League Prodigy) | Direção canónica |
| Carl × Jacky | Contradição na mesma fonte | Brawl Calculator: carl → jacky / jacky → carl<br>Power League Prodigy: jacky → carl | Jacky → Carl (Power League Prodigy) | Direção canónica |
| Carl × Surge | Divergência entre fontes | Brawl Calculator: surge → carl<br>Brawl Planet: carl → surge | Surge → Carl (Brawl Calculator) | Direção canónica |
| Charlie × Chuck | Divergência entre fontes | Brawl Planet: chuck → charlie<br>Power League Prodigy: charlie → chuck | Charlie → Chuck (Power League Prodigy) | Direção canónica |
| Charlie × Jae-yong | Divergência entre fontes | Brawl Planet: Jae-yong → charlie<br>Power League Prodigy: charlie → Jae-yong | Charlie → Jae-Yong (Power League Prodigy) | Direção canónica |
| Chester × Gale | Divergência entre fontes | Brawl Calculator: gale → chester<br>Power League Prodigy: chester → gale | Chester → Gale (Power League Prodigy) | Direção canónica |
| Chuck × Clancy | Divergência entre fontes | Brawl Calculator: clancy → chuck<br>Brawl Planet: chuck → clancy | Clancy → Chuck (Brawl Calculator) | Direção canónica |
| Chuck × Colt | Divergência entre fontes | Brawl Calculator: colt → chuck<br>Brawl Planet: colt → chuck<br>Power League Prodigy: chuck → colt | Chuck → Colt (Power League Prodigy) | Direção canónica |
| Chuck × Gale | Divergência entre fontes | Brawl Planet: chuck → gale<br>Power League Prodigy: gale → chuck | Gale → Chuck (Power League Prodigy) | Direção canónica |
| Chuck × Jae-yong | Divergência entre fontes | Brawl Planet: chuck → Jae-yong<br>Power League Prodigy: Jae-yong → chuck | Jae-Yong → Chuck (Power League Prodigy) | Direção canónica |
| Chuck × Ollie | Divergência entre fontes | Brawl Planet: chuck → ollie<br>Power League Prodigy: ollie → chuck | Ollie → Chuck (Power League Prodigy) | Direção canónica |
| Chuck × Otis | Divergência entre fontes | Brawl Planet: chuck → otis<br>Power League Prodigy: otis → chuck | Otis → Chuck (Power League Prodigy) | Direção canónica |
| Chuck × Squeak | Contradição na mesma fonte | Brawl Planet: chuck → squeak<br>Power League Prodigy: chuck → squeak / squeak → chuck | Neutro — sem bónus nem desbónus | Neutralizado |
| Chuck × Tara | Divergência entre fontes | Brawl Planet: chuck → tara<br>Power League Prodigy: tara → chuck | Tara → Chuck (Power League Prodigy) | Direção canónica |
| Colette × Jae-yong | Contradição na mesma fonte | Power League Prodigy: colette → Jae-yong / Jae-yong → colette | Neutro — sem bónus nem desbónus | Neutralizado |
| Colette × Mandy | Contradição na mesma fonte | Brawl Planet: mandy → colette<br>Power League Prodigy: colette → mandy / mandy → colette | Neutro — sem bónus nem desbónus | Neutralizado |
| Colette × Meeple | Contradição na mesma fonte | Brawl Calculator: colette → meeple / meeple → colette<br>Power League Prodigy: meeple → colette | Meeple → Colette (Power League Prodigy) | Direção canónica |
| Colette × Meg | Divergência entre fontes | Brawl Calculator: colette → meg<br>Power League Prodigy: meg → colette | Meg → Colette (Power League Prodigy) | Direção canónica |
| Colette × Mico | Divergência entre fontes | Brawl Planet: mico → colette<br>Power League Prodigy: colette → mico | Colette → Mico (Power League Prodigy) | Direção canónica |
| Colette × Sprout | Divergência entre fontes | Brawl Planet: sprout → colette<br>Power League Prodigy: colette → sprout | Colette → Sprout (Power League Prodigy) | Direção canónica |
| Colt × Rosa | Divergência entre fontes | Brawl Planet: colt → rosa<br>Power League Prodigy: rosa → colt | Rosa → Colt (Power League Prodigy) | Direção canónica |
| Colt × Sprout | Divergência entre fontes | Brawl Planet: sprout → colt<br>Power League Prodigy: colt → sprout | Colt → Sprout (Power League Prodigy) | Direção canónica |
| Cordelius × Ruffs | Divergência entre fontes | Brawl Calculator: cordelius → ruffs<br>Power League Prodigy: ruffs → cordelius | Ruffs → Cordelius (Power League Prodigy) | Direção canónica |
| Crow × Rosa | Divergência entre fontes | Brawl Calculator: rosa → crow<br>Brawl Planet: crow → rosa | Rosa → Crow (Brawl Calculator) | Direção canónica |
| Damian × Gale | Divergência entre fontes | Brawl Calculator: gale → damian<br>Power League Prodigy: damian → gale | Damian → Gale (Power League Prodigy) | Direção canónica |
| Damian × Rosa | Divergência entre fontes | Brawl Planet: rosa → damian<br>Power League Prodigy: damian → rosa | Damian → Rosa (Power League Prodigy) | Direção canónica |
| Damian × Stu | Divergência entre fontes | Brawl Calculator: stu → damian<br>Brawl Planet: damian → stu<br>Power League Prodigy: damian → stu | Damian → Stu (Power League Prodigy) | Direção canónica |
| Darryl × Jessie | Divergência entre fontes | Brawl Planet: jessie → darryl<br>Power League Prodigy: darryl → jessie | Darryl → Jessie (Power League Prodigy) | Direção canónica |
| Draco × Trunk | Divergência entre fontes | Brawl Calculator: draco → trunk<br>Brawl Planet: trunk → draco | Draco → Trunk (Brawl Calculator) | Direção canónica |
| Dynamike × Grom | Contradição na mesma fonte | Power League Prodigy: dynamike → grom / grom → dynamike | Neutro — sem bónus nem desbónus | Neutralizado |
| Emz × Gus | Contradição na mesma fonte | Power League Prodigy: emz → gus / gus → emz | Neutro — sem bónus nem desbónus | Neutralizado |
| Emz × Piper | Divergência entre fontes | Brawl Calculator: emz → piper<br>Brawl Planet: piper → emz | Emz → Piper (Brawl Calculator) | Direção canónica |
| Eve × Pearl | Contradição na mesma fonte | Power League Prodigy: eve → pearl / pearl → eve | Neutro — sem bónus nem desbónus | Neutralizado |
| Eve × Piper | Divergência entre fontes | Brawl Calculator: piper → eve<br>Power League Prodigy: eve → piper | Eve → Piper (Power League Prodigy) | Direção canónica |
| Fang × Griff | Divergência entre fontes | Brawl Calculator: griff → fang<br>Power League Prodigy: fang → griff | Fang → Griff (Power League Prodigy) | Direção canónica |
| Finx × Grom | Divergência entre fontes | Brawl Planet: grom → finx<br>Power League Prodigy: finx → grom | Finx → Grom (Power League Prodigy) | Direção canónica |
| Finx × Mandy | Contradição na mesma fonte | Brawl Planet: mandy → finx<br>Power League Prodigy: finx → mandy / mandy → finx | Neutro — sem bónus nem desbónus | Neutralizado |
| Frank × Janet | Contradição na mesma fonte | Brawl Calculator: frank → janet / janet → frank | Neutro — sem bónus nem desbónus | Neutralizado |
| Frank × Jessie | Divergência entre fontes | Brawl Calculator: frank → jessie<br>Brawl Planet: jessie → frank | Frank → Jessie (Brawl Calculator) | Direção canónica |
| Frank × Penny | Divergência entre fontes | Brawl Calculator: penny → frank<br>Power League Prodigy: frank → penny | Frank → Penny (Power League Prodigy) | Direção canónica |
| Frank × Rico | Contradição na mesma fonte | Brawl Calculator: frank → rico / rico → frank | Neutro — sem bónus nem desbónus | Neutralizado |
| Gale × Janet | Divergência entre fontes | Brawl Calculator: janet → gale<br>Power League Prodigy: gale → janet | Gale → Janet (Power League Prodigy) | Direção canónica |
| Gene × Glowy | Divergência entre fontes | Brawl Calculator: gene → glowy<br>Power League Prodigy: glowy → gene | Glowy → Gene (Power League Prodigy) | Direção canónica |
| Gene × Mr. P | Contradição na mesma fonte | Brawl Calculator: gene → Mr. P / Mr. P → gene<br>Power League Prodigy: Mr. P → gene | Mr P → Gene (Power League Prodigy) | Direção canónica |
| Gene × Piper | Divergência entre fontes | Brawl Calculator: gene → piper<br>Brawl Planet: gene → piper<br>Power League Prodigy: piper → gene | Piper → Gene (Power League Prodigy) | Direção canónica |
| Gene × Squeak | Contradição na mesma fonte | Power League Prodigy: gene → squeak / squeak → gene | Neutro — sem bónus nem desbónus | Neutralizado |
| Gigi × Sirius | Divergência entre fontes | Brawl Calculator: sirius → gigi<br>Power League Prodigy: gigi → sirius | Gigi → Sirius (Power League Prodigy) | Direção canónica |
| Griff × Ruffs | Contradição na mesma fonte | Brawl Calculator: griff → ruffs / ruffs → griff | Neutro — sem bónus nem desbónus | Neutralizado |
| Grom × Lumi | Divergência entre fontes | Brawl Calculator: grom → lumi<br>Brawl Planet: grom → lumi<br>Power League Prodigy: lumi → grom | Lumi → Grom (Power League Prodigy) | Direção canónica |
| Gus × Mandy | Divergência entre fontes | Brawl Calculator: gus → mandy<br>Power League Prodigy: mandy → gus | Mandy → Gus (Power League Prodigy) | Direção canónica |
| Gus × Piper | Divergência entre fontes | Brawl Calculator: piper → gus<br>Brawl Planet: gus → piper | Piper → Gus (Brawl Calculator) | Direção canónica |
| Gus × R-T | Divergência entre fontes | Brawl Calculator: gus → R-T<br>Power League Prodigy: R-T → gus | R-t → Gus (Power League Prodigy) | Direção canónica |
| Jacky × Kenji | Divergência entre fontes | Brawl Calculator: kenji → jacky<br>Brawl Planet: jacky → kenji<br>Power League Prodigy: jacky → kenji | Jacky → Kenji (Power League Prodigy) | Direção canónica |
| Jacky × Otis | Contradição na mesma fonte | Power League Prodigy: jacky → otis / otis → jacky | Neutro — sem bónus nem desbónus | Neutralizado |
| Jacky × Surge | Divergência entre fontes | Brawl Planet: jacky → surge<br>Power League Prodigy: surge → jacky | Surge → Jacky (Power League Prodigy) | Direção canónica |
| Jae-yong × Pierce | Divergência entre fontes | Brawl Calculator: Jae-yong → pierce<br>Power League Prodigy: pierce → Jae-yong | Pierce → Jae-yong (Power League Prodigy) | Direção canónica |
| Jae-yong × Ziggy | Contradição na mesma fonte | Power League Prodigy: Jae-yong → ziggy / ziggy → Jae-yong | Neutro — sem bónus nem desbónus | Neutralizado |
| Jae-yong × Sirius | Divergência entre fontes | Brawl Planet: sirius → Jae-yong<br>Power League Prodigy: Jae-yong → sirius | Jae-Yong → Sirius (Power League Prodigy) | Direção canónica |
| Jessie × Piper | Divergência entre fontes | Brawl Calculator: jessie → piper<br>Brawl Planet: piper → jessie<br>Power League Prodigy: jessie → piper | Jessie → Piper (Power League Prodigy) | Direção canónica |
| Kenji × Nita | Divergência entre fontes | Brawl Calculator: kenji → nita<br>Power League Prodigy: nita → kenji | Nita → Kenji (Power League Prodigy) | Direção canónica |
| Leon × Rosa | Divergência entre fontes | Brawl Planet: leon → rosa<br>Power League Prodigy: rosa → leon | Rosa → Leon (Power League Prodigy) | Direção canónica |
| Lola × Sprout | Divergência entre fontes | Brawl Planet: sprout → lola<br>Power League Prodigy: lola → sprout | Lola → Sprout (Power League Prodigy) | Direção canónica |
| Lou × Poco | Contradição na mesma fonte | Power League Prodigy: lou → poco / poco → lou | Neutro — sem bónus nem desbónus | Neutralizado |
| Lou × Sirius | Divergência entre fontes | Brawl Calculator: lou → sirius<br>Brawl Planet: sirius → lou | Lou → Sirius (Brawl Calculator) | Direção canónica |
| Lumi × Mandy | Divergência entre fontes | Brawl Planet: mandy → lumi<br>Power League Prodigy: lumi → mandy | Lumi → Mandy (Power League Prodigy) | Direção canónica |
| Maisie × Mandy | Divergência entre fontes | Brawl Planet: mandy → maisie<br>Power League Prodigy: maisie → mandy | Maisie → Mandy (Power League Prodigy) | Direção canónica |
| Mandy × Nita | Divergência entre fontes | Brawl Planet: mandy → nita<br>Power League Prodigy: nita → mandy | Nita → Mandy (Power League Prodigy) | Direção canónica |
| Mandy × Pam | Divergência entre fontes | Brawl Calculator: pam → mandy<br>Brawl Planet: mandy → pam<br>Power League Prodigy: pam → mandy | Pam → Mandy (Power League Prodigy) | Direção canónica |
| Mandy × Pearl | Contradição na mesma fonte | Power League Prodigy: mandy → pearl / pearl → mandy | Neutro — sem bónus nem desbónus | Neutralizado |
| Mandy × Sandy | Divergência entre fontes | Brawl Planet: mandy → sandy<br>Power League Prodigy: sandy → mandy | Sandy → Mandy (Power League Prodigy) | Direção canónica |
| Mandy × Trunk | Divergência entre fontes | Brawl Planet: mandy → trunk<br>Power League Prodigy: trunk → mandy | Trunk → Mandy (Power League Prodigy) | Direção canónica |
| Max × Poco | Divergência entre fontes | Brawl Calculator: max → poco<br>Brawl Planet: poco → max<br>Power League Prodigy: poco → max | Poco → Max (Power League Prodigy) | Direção canónica |
| Meeple × Ollie | Divergência entre fontes | Brawl Planet: ollie → meeple<br>Power League Prodigy: meeple → ollie | Meeple → Ollie (Power League Prodigy) | Direção canónica |
| Mico × Penny | Divergência entre fontes | Brawl Calculator: penny → mico<br>Brawl Planet: mico → penny | Penny → Mico (Brawl Calculator) | Direção canónica |
| Mina × Trunk | Divergência entre fontes | Brawl Calculator: mina → trunk<br>Brawl Planet: trunk → mina<br>Power League Prodigy: trunk → mina | Trunk → Mina (Power League Prodigy) | Direção canónica |
| Mortis × Nita | Divergência entre fontes | Brawl Calculator: mortis → nita<br>Power League Prodigy: nita → mortis | Nita → Mortis (Power League Prodigy) | Direção canónica |
| Mr. P × Penny | Contradição na mesma fonte | Power League Prodigy: Mr. P → penny / penny → Mr. P | Neutro — sem bónus nem desbónus | Neutralizado |
| Mr. P × Tick | Divergência entre fontes | Brawl Calculator: tick → Mr. P<br>Brawl Planet: Mr. P → tick | Tick → Mr. P (Brawl Calculator) | Direção canónica |
| Nani × Pearl | Contradição na mesma fonte | Brawl Planet: pearl → nani<br>Power League Prodigy: nani → pearl / pearl → nani | Neutro — sem bónus nem desbónus | Neutralizado |
| Nita × Poco | Divergência entre fontes | Brawl Calculator: poco → nita<br>Power League Prodigy: nita → poco | Nita → Poco (Power League Prodigy) | Direção canónica |
| Nori × Sirius | Divergência entre fontes | Brawl Planet: sirius → nori<br>Power League Prodigy: nori → sirius | Nori → Sirius (Power League Prodigy) | Direção canónica |
| Ollie × Penny | Divergência entre fontes | Brawl Planet: penny → ollie<br>Power League Prodigy: ollie → penny | Ollie → Penny (Power League Prodigy) | Direção canónica |
| Ollie × Surge | Divergência entre fontes | Brawl Calculator: surge → ollie<br>Brawl Planet: ollie → surge | Surge → Ollie (Brawl Calculator) | Direção canónica |
| Piper × R-T | Divergência entre fontes | Brawl Calculator: piper → R-T<br>Power League Prodigy: R-T → piper | R-t → Piper (Power League Prodigy) | Direção canónica |
| Rico × Shelly | Divergência entre fontes | Brawl Calculator: shelly → rico<br>Power League Prodigy: rico → shelly | Rico → Shelly (Power League Prodigy) | Direção canónica |
| Rosa × Spike | Divergência entre fontes | Brawl Planet: spike → rosa<br>Power League Prodigy: rosa → spike | Rosa → Spike (Power League Prodigy) | Direção canónica |
| Rosa × Sprout | Divergência entre fontes | Brawl Calculator: sprout → rosa<br>Power League Prodigy: rosa → sprout | Rosa → Sprout (Power League Prodigy) | Direção canónica |
| Ruffs × Surge | Contradição na mesma fonte | Brawl Calculator: ruffs → surge / surge → ruffs<br>Brawl Planet: ruffs → surge | Neutro — sem bónus nem desbónus | Neutralizado |
| Sprout × Tara | Contradição na mesma fonte | Power League Prodigy: sprout → tara / tara → sprout | Neutro — sem bónus nem desbónus | Neutralizado |

## Exemplo: Bea × Bibi

O caso reportado foi confirmado como uma **divergência entre fontes**, não como uma modificação manual dos brawlers. No contexto global atual, a prioridade do Power League Prodigy decide o par como **Bibi → Bea**. Portanto, ao avaliar Bea contra Bibi, o Draft aplica somente o desbónus correspondente a Bibi counterar Bea; não concede simultaneamente um bónus a Bea por counterar Bibi. Quando forem importadas relações por mapa, uma relação específica de mapa terá precedência sobre esta regra global.
