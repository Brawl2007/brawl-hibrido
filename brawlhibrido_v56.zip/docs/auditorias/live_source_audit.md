# Auditoria da fonte Brawl Planet

Data da verificação: 2026-08-14.

Fonte consultada: https://www.brawlplanet.com/maps/crystalarcade_gemgrab

A página renderizada do Brawl Planet apresenta uma tabela Individual com colunas `Win (%)`, `Pick (%)` e `Starplayer (%)`, além dos blocos Top win rate, Most picked e Most Star Player. A leitura visual mostrou, por exemplo, Bolt 63.8 / 1.8 / 31.5, Ash 57.9 / 3.9 / 26.2 e Ollie 57.5 / 2.9 / 17.0. O conteúdo extraído inclui a tabela completa além das primeiras linhas, confirmando que os valores existem no DOM renderizado.

O HTML inicial obtido por HTTP contém principalmente dados serializados e rótulos traduzidos; não expõe diretamente as chaves numéricas `pickRate` e `starPlayer` no formato esperado pelo regex atual. Portanto, a falha é de estratégia de parsing: o sincronizador precisa extrair a tabela renderizada/estruturada do HTML, não depender apenas de campos JSON nomeados `pickRate` e `starPlayer`.

A auditoria do snapshot local mostrou 2.835 linhas (27 mapas × 105 brawlers), mas no estado anterior havia `brawlPlanetPickRate` em apenas 924 linhas, `brawlPlanetStarPlayer` em zero linhas e `topBrawl*` em 2.790 linhas. A UI também mostrava apenas seis cards na SourceComparison, embora a tabela híbrida preservasse as 105 linhas.

Fonte visual e textual: página Brawl Planet acima. Os valores são dados da fonte externa e não foram inventados pelo dashboard.

## Confirmação da aba Ranked

A interação com a página e a extração do DOM renderizado confirmaram que a aba `RANKED` contém uma tabela Individual completa com `Win (%)`, `Pick (%)` e `Starplayer (%)`. Para Crystal Arcade, a aba Ranked mostrou Bolt 66.1 / 7.6 / 26.0, Clancy 59.5 / 3.2 / 31.2 e Ash 58.2 / 1.6 / 24.3, entre 105 brawlers. A página é inicialmente carregada em Trophy Ladder e alterna para Ranked no cliente; o sincronizador atual usa apenas o HTML inicial sem ativar essa visão.

Conclusão operacional: o parser deve selecionar a tabela HTML que contém os cabeçalhos Brawler, Win, Pick e Starplayer, e a coleta deve solicitar/ativar uma rota ou estado Ranked suportado; caso o site não ofereça query parameter, a coleta precisa usar o payload serializado correspondente à aba ou uma estratégia DOM compatível, nunca substituir os valores por dados inventados.
