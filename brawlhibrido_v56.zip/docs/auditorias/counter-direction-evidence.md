# Evidência visual — orientação BrawlScope

As duas capturas fornecidas pelo utilizador foram lidas diretamente em 19 de agosto de 2026 para impedir uma nova inversão de direção.

| Captura | Rótulo visível | Relação verificável | Interpretação canónica |
|---|---|---|---|
| Ruffs | `RUFFS PUNEM` | R-T aparece na lista | **Ruffs → R-T** |
| Bolt | `BOLT PUNE` | Trovão, Najla, Broto, Bela, Marcação, Ziggy e Senhor P aparecem na lista | **Bolt → cada brawler listado** |

> Regra literal: **“[Brawler] pune”** lista os brawlers que ele countera. A lista que diz **“eles neutralizam [Brawler]”** lista os brawlers que counteram esse brawler.

No export técnico atual, a lista visível `RUFFS PUNEM` está armazenada no campo bruto `counteredBy`; portanto, o adaptador canónico deve continuar a expor esse campo como `targets`. Os nomes técnicos do export não devem ser usados para inferir a semântica sem os rótulos da interface.

## URLs verificadas

- https://brawlscope.com/counters?brawler=ruffs
- https://brawlscope.com/counters?brawler=r-t
- https://brawlscope.com/counters?brawler=bolt
