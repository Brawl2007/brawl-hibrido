# Correção de counters — Draft, perfis e matriz

## Regra aplicada

A função compartilhada `shared/counterMatchupValue.ts` calcula o delta BrawlScope na perspectiva do brawler escolhido e soma 2 pontos percentuais por confirmação concordante de PL Prodigy e Brawl Planet. Uma confirmação negativa soma −2 pontos. Fontes discordantes ou ambíguas não dão confirmação; duplicações contam uma vez. Sem delta BrawlScope não se inventa uma percentagem.

O percentual contextual publicado tem prioridade sobre o catálogo completo incluído. A direção explícita do BrawlScope determina o sinal quando disponível; na ausência dessa direção usa-se o sinal do delta do catálogo. Relações qualitativas das fontes continuam disponíveis nos perfis. Os dados anexados não foram substituídos por valores do exemplo: +4,9% e −4,9% são fixtures de teste.

Counter Pick usa o resultado diretamente, sem inversão e sem o multiplicador antigo de 2x. As demais regras de score e limites contextuais já existentes permanecem. O ban exige simultaneamente um dos 10 matchups de maior valor final positivo do brawler e presença no Top 25 base do mapa; as taxas por pick são preservadas.

## Onde conferir

- Draft: detalhes de Counter / Desbônus Counter e nota do duelo exibem valor e composição por fonte.
- Perfil: cards das relações e a seção “Matchup contra todos os brawlers” usam a mesma fórmula e o modo selecionado. A grade completa permanece, inclusive pares sem delta, sinalizados com “—”.
- Matriz: confronto selecionado e cada célula mostram a composição e o valor final; estatísticas observadas da API continuam identificadas separadamente.
- Controles antigos de multiplicação e taxa fixa de Counter Pick foram retirados da interface.
- Cards, dicas e links do Calculator foram retirados das telas alteradas. A sincronização deixa de consultá-lo e ignora suas relações e seu status nas validações. Arquivos históricos da fonte foram preservados para não destruir o arquivo de origem, mas não alimentam esses cálculos.

## Arquivos alterados

- `shared/counterMatchupValue.ts` — novo resolvedor, formatação e seleção Top 10.
- `shared/draft.ts` — recomendações, Counter Pick, sinais dos duelos, perfis, regra de ban e explicações.
- `shared/counterSourceRelations.ts` — exclusão explícita do Calculator, prioridade do contexto de modo e correção de tipagem das fontes autorizadas.
- `shared/coachPlan.ts` — relatório do plano usa delta assinado e composição, com contexto de modo.
- `server/counterSync.ts` — desativa coleta do Calculator e sua participação na validação.
- `client/src/pages/Draft.tsx` — composição visível e retirada dos controles/dicas antigos.
- `client/src/pages/BrawlerDetail.tsx` — matriz completa, composição, sinal coerente e fontes autorizadas.
- `client/src/pages/MatchupMatrix.tsx` — mesma fórmula em pares e células, sem dicas do Calculator.
- `client/src/pages/Brawlers.tsx` — texto atualizado das fontes.
- `server/counterMatchupValue.test.ts` — 15 testes de regressão da regra solicitada.
- `dist/` — build atualizado do servidor e frontend.

## Validação

- `vitest run server/counterMatchupValue.test.ts`: **15 testes passaram**. Inclui positivo sem confirmação, uma confirmação de cada fonte, duas confirmações, discordância, negativo, ausência de delta, zero, Calculator ignorado, duplicatas, filtros de modo, integração com Draft/duelo e ban dentro/fora dos limites Top 10 e Top 25.
- `npm run build`: **passou**, gerando frontend e servidor. O build avisa sobre variáveis opcionais de analytics ausentes, uma imagem de fundo não incluída e tamanho de chunks.
- `npm run check`: **não passou**, com 14 diagnósticos em arquivos antigos. Faltam no ZIP original `useAuth`, `useMobile`, `useComposition`, `ui/accordion` e `shared/_core/errors`; há também parâmetros sem tipo nos inputs dependentes desses hooks. A ausência desses arquivos foi conferida diretamente no ZIP original. Nenhum diagnóstico restante está nos arquivos desta correção.
- Comparação byte a byte confirmou que os catálogos BrawlScope (inclusive a matriz completa), Brawl Planet, PL Prodigy e o relatório de importação Prodigy permanecem intactos.
- Não foi executada a suíte histórica inteira nem uma auditoria visual em navegador. Não houve coleta nova dos sites externos ou publicação nesta entrega.

## Executar localmente

Usar a versão de pnpm declarada no projeto (10.4.1):

```sh
npx pnpm@10.4.1 install --frozen-lockfile
npx pnpm@10.4.1 exec vitest run server/counterMatchupValue.test.ts
npm run build
```

O ZIP contém o código-fonte, o build e este relatório, sem `node_modules` ou arquivos temporários.
