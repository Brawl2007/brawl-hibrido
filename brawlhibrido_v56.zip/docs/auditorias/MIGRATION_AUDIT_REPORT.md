# Relatório de Auditoria e Cobertura do Pacote de Migração — Brawl Híbrido

Este relatório apresenta de forma rigorosa e transparente o que está 100% incluído no pacote exportado (`brawl-hibrido-export.zip`) e o que, por limitações de plataforma ou segurança, requer configuração manual na nova conta.

---

## 1. O que está 100% Incluído no Pacote (`brawl-hibrido-export.zip`)
- **Código Fonte Completo**: Toda a aplicação React 19, componentes, páginas (`Draft.tsx`, `MatchupMatrix.tsx`, `BrawlerDetail.tsx`, etc.), tRPC routers e servidor Express.
- **Motores de Cálculo e Relações Multifuente**: Todos os algoritmos de Draft, penalidades (`-5%` por enemy counter, `-5%` por mesma classe, `-5%` acumulativo por Worst Teammate), probabilidade bilateral e proporções.
- **Bases de Dados Estáticas e Extratores**: Ficheiros de dados gerados e validados (`brawlPlanetRelationData.ts`, `brawlCalculatorCounterData.ts`, `prodigyCounterData.ts`, `brawlerAttackRanges.ts`, `observedMatchups.ts`) e scripts em `server/scripts/`.
- **Suite de Testes Unitários**: 76 testes Vitest completos e a passar (`pnpm test`).
- **Memória e Documentação**: `MIGRATION_GUIDE.md`, `CONVERSATION_HISTORY_MEMORY.md` e todo o histórico de auditorias e changelogs.

---

## 2. O que NÃO está incluído no ZIP (e exige ação manual na nova conta)
Por razões de segurança, isolamento e arquitetura da plataforma Manus, os seguintes elementos não viajam no ficheiro ZIP e devem ser reconfigurados:
1. **Chaves Secretas (Secrets)**:
   - A chave oficial `BRAWL_STARS_API_KEY` não é exportada por razões de privacidade. Deve ser reintroduzida no painel de segredos da nova conta (Settings → Secrets).
2. **Base de Dados em Execução (MySQL Runtime DB)**:
   - As tabelas e registos transacionais criados na base de dados da conta anterior (como histórico de sincronizações ou utilizadores autenticados) não são migrados num ficheiro SQL estático, pois a nova conta inicializa uma base de dados limpa. O código reconstrói o esquema automaticamente no primeiro arranque (`drizzle-kit push` / migrações).
3. **Sessão e Cookies de Utilizador**:
   - Os tokens de sessão de OAuth da conta anterior não são transportados; será necessário iniciar sessão novamente na nova conta.

---
*Relatório emitido para assegurar total transparência e fiabilidade na transição de contas.*
