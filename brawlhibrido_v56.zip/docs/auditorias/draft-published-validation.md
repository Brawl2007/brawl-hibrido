# Validação interativa do Draft publicado

Data: 2026-08-14

Domínio validado: `https://brawlhub-hv3h5xuy.manus.space/draft`

## Quick pick

O Draft publicado abriu com o primeiro passo `Ban · Azul`. A seleção do primeiro botão da dock `PICK AGORA` preencheu o slot Azul com `Bo`, atualizou o contador para `1/12` e avançou o estado ativo para `Ban · Vermelha`. A lista rápida também deixou de apresentar `Bo`, confirmando o bloqueio do brawler escolhido.

## Regra de ban atual

A implementação atual segue a regra competitiva definida posteriormente no projeto: um brawler banido fica permanentemente bloqueado para picks subsequentes. Por isso, a antiga validação histórica que esperava a etiqueta `BAN · LIVRE` foi substituída pela regra `BAN · EXCLUÍDO`; o estado publicado após banir `Bo` confirma esta exclusão.

## Estado publicado observado

O domínio publicado carregou a sequência padrão de 12 passos, 6 bans, 6 picks, escolha de lado inicial e alternância de perspetiva. A API oficial apareceu como `FALLBACK ATIVO` com 403/allowlist, sem impedir o Draft nem os dados locais/snapshot.
