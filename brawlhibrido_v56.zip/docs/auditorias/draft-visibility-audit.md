# Auditoria de visibilidade do Draft publicada

Data da verificação: 2026-08-14.

A rota `/draft` publicada carrega corretamente os novos elementos no HTML acessível: botão `Passar ban`, seis slots de bans e seis slots de picks, texto de contexto que diz que bans podem ser ignorados sem bloquear picks, modelo `30·25·25·20 Sin · WR · Fit · Ctr`, categorias `PICK SEGURO`, `RESPOSTA` e `WIN CONDITION`, além das razões de coach nas cartas de recomendação.

Problema de visibilidade: no primeiro viewport, o tabuleiro de equipas e a lista de recomendações não ficam próximos; a sequência de Scrim Lab ocupa uma secção longa antes do tabuleiro. A lista de recomendações aparece depois do Coach Desk, obrigando a descer bastante. A mudança de Passar ban aparece na barra da sequência, mas não existe ainda uma dock fixa/adjacente ao tabuleiro para a seleção ativa.

Conclusão: a lógica está publicada, mas a experiência não torna as mudanças suficientemente óbvias. A correção necessária é refatorar o layout em desktop para um grid com tabuleiro/ação atual e recomendações lado a lado, e em mobile para colocar a ação atual e os botões de seleção imediatamente antes da lista de brawlers. Também é necessário validar visualmente o fluxo após a alteração.
