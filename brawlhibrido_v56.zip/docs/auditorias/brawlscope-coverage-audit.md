# Auditoria de cobertura BrawlScope — Nori

## Pedido reportado

O utilizador reportou que a relação **Nori → Mr. P** deveria existir no catálogo BrawlScope e solicitou a reconciliação completa das listas de brawlers que cada perfil pune e dos que o punem.

## Fonte externa consultada

| Fonte | URL | Resultado atual |
|---|---|---|
| Página pública Counters do BrawlScope | https://brawlscope.com/counters | A página identifica-se como ferramenta de ajuda ao Draft e lista Nori e Mr. P entre os brawlers disponíveis. A extração textual inicial não expôs as listas de um perfil individual. |

## Estado de evidência

As relações abaixo foram confirmadas exclusivamente a partir das listas renderizadas pelo BrawlScope. Não foi inferida qualquer direção com base em discussão comunitária, Brawl Calculator ou Brawl Planet.

## Evidência literal obtida — perfil Nori

Foi obtido o HTML renderizado de `https://brawlscope.com/counters?brawler=nori`. As duas secções do perfil apresentam atualmente:

| Secção literal BrawlScope | Relações publicadas |
|---|---|
| `Counters Nori` | Sirius, Surge, Edgar, Chester, Griff, Bull, Shelly, Damian, Rosa, Alli |
| `Nori punishes` | Chuck, Larry & Lawrie, Sprout, Juju, Barley, Pam, Mr. P, Jessie, Grom, Lola |

A extração inicial leu apenas os quatro primeiros cartões de cada direção. A extração completa confirma que **Nori → Mr. P** é uma relação literal publicada, na sétima posição de `Nori punishes`; por isso, ela é integrada. `Chester → Nori` também permanece confirmado em `Counters Nori`.

## Cobertura integral extraída

Em 2026-08-20 foi recolhido o HTML renderizado de todos os 105 URLs locais do padrão `https://brawlscope.com/counters?brawler=<slug>`. Foram lidos **104 perfis** com as duas listas literais; Wendy não possui ainda listas BrawlScope legíveis e permanece sem relações inferidas, conforme a regra já existente no projeto.

| Resultado de comparação | Quantidade |
|---|---:|
| Perfis BrawlScope legíveis | 104 |
| Relações atuais presentes no BrawlScope e ausentes no catálogo local antes da integração | 84 |
| Relações históricas locais que não aparecem na lista atual do BrawlScope antes da integração | 1 208 |
| Relações Nori atuais ausentes no catálogo local antes da integração | Relações além dos quatro primeiros cartões de cada direção, incluindo Nori → Mr. P |

## Reconciliação aplicada

O catálogo canónico foi regenerado a partir das **listas literais completas hoje publicadas** para os 104 perfis legíveis. Assim, cada direção contém a ordem e a quantidade que o BrawlScope efetivamente expõe no momento da consulta; não mantém relações históricas que a fonte já não lista como se fossem atuais.

| Salvaguarda | Resultado aplicado |
|---|---|
| Nori | As duas listas completas de 10 relações foram integradas, incluindo `Chester → Nori`, `Nori → Larry & Lawrie` e `Nori → Mr. P`. |
| Ruffs | Mantém-se a única troca estrutural no adaptador: os dois arrays brutos são invertidos apenas para este perfil, preservando `Ruffs → R-T`. |
| Wendy | O perfil sem listas legíveis foi removido da fonte BrawlScope; não há fallback nem relações fabricadas. |
| Draft | O adaptador continua a dar prioridade ao BrawlScope, seguido por Brawl Calculator e Brawl Planet apenas quando a fonte superior é silenciosa. |

As regressões confirmam as duas listas completas de Nori, incluindo `Nori → Mr. P`, a orientação de Ruffs e a ausência de perfil BrawlScope para Wendy.

## Segunda verificação Top 10 — execução parcial aprovada

Foi executada uma auditoria independente dos 104 perfis locais, com extração separada de `Counters <brawler>` e `<brawler> punishes`. A validação aceitou somente perfis com confiança alta, duas listas não vazias e no máximo 10 itens em cada direção. O utilizador autorizou explicitamente saltar perfis inacabados, em vez de preencher lacunas por inferência.

| Resultado da validação | Perfis |
|---|---:|
| Aceites para reconciliação literal nesta execução | 96 |
| Isolados por falha de leitura ou lista vazia | 8 |

Os perfis isolados são `8-Bit`, `Clancy`, `Damian`, `Edgar`, `Mortis`, `Mr. P`, `Nita` e `Starr Nova`. A lista de Clancy publicada declarou explicitamente que nenhum pick cai abaixo da taxa habitual contra ele; os restantes foram isolados por leitura dinâmica incompleta. Nenhum deles será modificado nesta execução parcial sem listas literais completas.

## Conclusão posterior — perfil Nita

Uma extração direta posterior do HTML de `https://brawlscope.com/counters?brawler=nita` separou corretamente as duas listas de Nita. A página publica sete relações literais no total, não dez por direção; por isso, a integração conserva exatamente as relações visíveis e não completa a lista com suposições.

| Secção literal BrawlScope | Relações publicadas |
|---|---|
| `Counters Nita` | Juju, Pierce, Gene, Bolt |
| `Nita punishes` | Chuck, Jessie, 8-Bit |

Nita deixa de estar isolada para esta atualização. A lista parcial deve ser preservada como publicada: quatro brawlers counteram Nita e Nita countera três brawlers.
