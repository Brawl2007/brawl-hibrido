# Auditoria da rotação Ranked — nova temporada

## Evidência recolhida em 20 de agosto de 2026

| Fonte | URL | Constatação verificável |
|---|---|---|
| Brawl Planet, página inicial | https://www.brawlplanet.com | Declara que as estatísticas por mapa são atualizadas de hora a hora e disponibiliza as áreas públicas **Maps** e **Ranked**. |
| Brawl Planet, Ranked | https://www.brawlplanet.com/powerleague | A vista Ranked publica os seis modos competitivos: Gem Grab, Brawl Ball, Bounty, Heist, Hot Zone e Knockout; a extração textual ainda não apresenta os nomes dos mapas. |
| Brawl Planet, dados estruturados da vista Ranked | https://www.brawlplanet.com/powerleague | O `ItemList` público da página enumera **46** cartões de mapas Ranked, distribuídos entre Bounty (8), Brawl Ball (9), Gem Grab (10), Heist (6), Hot Zone (7) e Knockout (6). É uma cobertura estatística mais ampla do que a rotação de seleção do Draft. |
| TopBrawl, Rankeds | https://topbrawl.com/rankeds | A página publica uma seleção de **27** mapas, com Gem Grab (7), Heist (4), Bounty (4), Brawl Ball (4), Hot Zone (4) e Knockout (4), além da tabela de Scores do modo Ranked. |

## Próxima verificação

As duas fontes foram confirmadas e apresentam coberturas diferentes: o Brawl Planet disponibiliza um conjunto analítico mais amplo de 46 cartões, enquanto o TopBrawl publica 27 mapas para o Rankeds. A próxima fase irá confrontar o conjunto de 27 mapas do TopBrawl e a interseção publicada pelo Brawl Planet com o catálogo local, sem presumir que uma entrada analítica adicional seja automaticamente uma mudança de temporada.

Nenhum dado competitivo foi alterado nesta fase.

## Comparação com o catálogo do Brawl Híbrido

O catálogo local contém 27 mapas e os respetivos 27 IDs canónicos do TopBrawl. A comparação automática com os links atualmente publicados em `https://topbrawl.com/rankeds` devolveu os quatro conjuntos vazios: não há mapas apenas locais, mapas apenas na fonte, IDs locais ausentes na fonte nem IDs da fonte ausentes localmente.

> **Conclusão:** a alteração aparenta ser uma atualização das estatísticas disponibilizadas pelas fontes, e não a entrada de um mapa Ranked novo. Por isso, adicionar qualquer um dos 19 cartões extra da página analítica do Brawl Planet seria uma alteração não confirmada da rotação competitiva e não foi feita.

## Atualização posterior de rotação — confirmação TopBrawl

Uma nova leitura de `https://topbrawl.com/rankeds` devolveu 28 IDs de mapas atuais. Comparada com os 27 IDs locais da rotação anterior, confirma as entradas e saídas seguintes.

| Estado | ID TopBrawl | Mapa | Modo |
|---|---:|---|---|
| Adicionado | 15000137 | Pit Stop | Roubo |
| Adicionado | 15000886 | Safe(r) Zone | Roubo |
| Adicionado | 15001021 | Spiraling Out | Fute-Brawl |
| Removido | 15000008 | Crystal Arcade | Pique-Gema |
| Removido | 15000009 | Deathcap Trap | Zona Recôndita |

Os títulos públicos individuais do TopBrawl confirmam os nomes oficiais: “Best Brawlers for Heist on Pit Stop”, “Best Brawlers for Heist on Safe(r) Zone” e “Best Brawlers for Brawl Ball on Spiraling Out”. O nome relatado como “Espiralda” corresponde a **Spiraling Out**.

O `ItemList` estruturado e o link de detalhe do Brawl Planet confirmam os três slugs usados pela sincronização: `pitstop_heist`, `safe(r)zone_heist` e `spiralingout_brawlball`. O mapa **Safe(r) Zone** é distinto de **Safe Zone**, cujo slug continua a ser `safezone_heist`.
