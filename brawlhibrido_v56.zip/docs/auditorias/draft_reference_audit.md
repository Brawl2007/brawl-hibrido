# Auditoria de Referência — Power League Prodigy

Fonte consultada: [https://powerleagueprodigy.com](https://powerleagueprodigy.com)

A página inicial apresenta uma navegação com uma área dedicada **PL Prodigy / Ranked Drafting**, descrita como draft com recomendações em tempo real orientadas ao mapa, picks live, meta do mapa e filtros de roster. Também apresenta uma área separada de **Draft Practice**, com cenários ranked e feedback imediato.

O fluxo de referência sugere três princípios para o Brawl Híbrido: selecionar o mapa antes de iniciar o draft; manter o estado de picks e bans visível por equipa; e recalcular recomendações conforme o estado do draft muda. A adaptação deste projeto será própria e baseada no Score Híbrido e nas métricas de TopBrawl/Brawl Planet, sem copiar o design, código ou identidade do site de referência.

A nova página deve conter: cabeçalho de Draft Híbrido, seleção dos 27 mapas, sequência de bans e picks para as equipas Azul e Vermelha, lista de recomendações ordenada por Score Híbrido, filtros de tier e pesquisa de brawler, além de indicadores de Win Rate, Use/Pick Rate, Score e Star Player quando disponíveis.
