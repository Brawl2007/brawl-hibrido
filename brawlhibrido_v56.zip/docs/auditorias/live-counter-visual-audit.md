# Auditoria visual — Live Counter Engine

Data da validação: 2026-08-14.

## Desktop

A página `/draft` foi capturada em viewport 1280x720 com página completa. O painel `LIVE COUNTER ENGINE` aparece entre o tabuleiro e a matriz de lanes, com cabeçalho, estado vazio inicial, botão `Simular melhor resposta` e estrutura preparada para até cinco cartões de matchup. O painel mantém o tema escuro Championship Arena, o acento cyan e a hierarquia de leitura do Draft.

## Mobile

A página `/draft` foi capturada em viewport 390x844 com página completa. O painel adapta o cabeçalho para coluna, expande o botão de simulação para a largura disponível e converte as recomendações em uma coluna legível nos ecrãs estreitos. Os estados vazios e o aviso sobre o turno de pick permanecem acessíveis.

## Nota funcional

O motor é recalculado a cada alteração de `opponentPicks`, `currentRows` ou `lockedNames`. A interação real escolhe um brawler inimigo no tabuleiro; quando o turno seguinte é um pick da equipa do utilizador, os cards mostram counter, posição e justificação, e o botão simula a primeira resposta disponível. A API oficial continua com fallback transparente quando a allowlist/IP devolve 403.
