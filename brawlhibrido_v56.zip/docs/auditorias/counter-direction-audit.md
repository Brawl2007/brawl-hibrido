# Auditoria de direção de counters

## Ruffs versus R-T — correção confirmada pela interface publicada

As imagens fornecidas pelo utilizador mostram `R-T` sob a coluna **“RUFFS PUNEM”**. Logo, a relação literal publicada é **Ruffs → R-T**, e não R-T → Ruffs.

O ficheiro estático histórico `shared/brawlScopeCounterData.ts` preservou os dois grupos com nomes técnicos trocados: os valores da coluna **PUNEM** chegam no campo `counteredBy`, enquanto os valores da coluna **PUNIDO POR** chegam no campo `targets`. O adaptador `shared/counterSourceRelations.ts` passa agora a inverter esses nomes técnicos somente na fronteira de leitura: `counteredBy` bruto é exposto como `targets` canónico, e `targets` bruto como `counteredBy` canónico.

As regressões validam Ruffs → R-T, a separação entre o que um brawler pune e quem o pune, e a manutenção dessa direção no Draft, nos duelos e na probabilidade de equipa. Nenhuma relação de Brawl Calculator ou Brawl Planet foi alterada.
