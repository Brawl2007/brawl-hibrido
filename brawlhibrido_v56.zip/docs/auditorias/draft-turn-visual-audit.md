# Auditoria visual — Draft competitivo

Data: 2026-08-14

## Desktop

A página `/draft` renderizou sem erros visíveis no preview. O tabuleiro Azul/Vermelha aparece no topo do fluxo, com o bloco `TURN` no centro e a barra `PICK AGORA` imediatamente ao lado. Os slots vazios são visualmente distinguíveis e o painel de recomendações mostra os sinais SYN, WR, FIT e CTR, a posição sugerida e a explicação contextual.

## Mobile

A página `/draft` renderizou no viewport estreito sem overflow horizontal aparente. O conteúdo permanece legível em coluna única, com o tabuleiro, a barra rápida e as recomendações empilhados. A faixa final de probabilidade fica preparada para duas colunas no desktop e uma coluna no mobile.

## Observação de dados

O preview registou `403 Forbidden` na consulta de eventos da API oficial. A interface mantém o estado de fallback/local de forma transparente; isto é consistente com a limitação atual de allowlist/IP e não é tratado como dados oficiais live.

## Próxima validação

Ainda é necessário executar ações interativas no browser para confirmar: clicar num slot Azul, clicar num slot Vermelho, alternar a perspetiva, preencher o draft e observar a estimativa final; depois disso o TODO pode ser fechado e o checkpoint guardado.
