# Correção dos counters — Brawl Híbrido

Implementado em `/home/ubuntu/brawl-hibrido`, extraído do ZIP fornecido porque o diretório não existia neste ambiente.

## Arquivos de código e testes modificados (lista exata)

| Arquivo | Alteração |
|---|---|
| `client/src/contexts/CounterSyncContext.tsx` | Aplica SSE e query mais recentes ao mesmo resolvedor e publica snapshot/versão juntas, sem polling. |
| `client/src/data/counterPush.test.ts` | Regressões de SSE/query, rejeição de versões antigas, mudança efetiva do score e dependências React de counterSnapshotVersion. |
| `client/src/pages/BrawlerDetail.tsx` | Catálogo parcial, aliases nas rotas, ausência de métricas/build e apresentação da evidência global; prioridade PL Prodigy explícita. |
| `client/src/pages/Brawlers.tsx` | Inclui roster de counters, identifica Fora do Ranked, oculta score/tier técnicos e atualiza textos. |
| `client/src/pages/Draft.tsx` | Invalida também coaching e sugestões live quando counterSnapshotVersion muda; cadeia principal já dependia da versão. |
| `server/brawlScopeDraftSource.test.ts` | Ativa explicitamente catálogo offline apenas no teste; preserva as verificações de direção e Ruffs. |
| `server/brawlerCatalog.test.ts` | Prepara e limpa o fallback offline dos testes de catálogo. |
| `server/counterSourceRelations.test.ts` | Testa cobertura externa, aliases, perfis parciais, globais em cada modo e isolamento entre modos; preserva proveniência e exclusões. |
| `server/counterSync.test.ts` | Testa união de todos os rosters e deduplicação com nomes editoriais. |
| `server/counterSync.ts` | Une activeBrawlers e state.brawlers de todas as fontes; inclui relações literais PL Prodigy com status static. |
| `server/draftEngine.test.ts` | Prepara e limpa catálogo offline para os testes existentes de pontuação, sem alterar suas asserções. |
| `server/draftPresentation.test.ts` | Prepara e limpa catálogo offline para os testes existentes de chips, sem alterar suas asserções. |
| `shared/brawlerCatalog.ts` | Deduplica aliases, preserva identidade editorial, inclui linhas unavailable, prioriza Ranked real e não produz build para linhas parciais; perfis gerais. |
| `shared/counterSourceRelations.ts` | Filtro usa união compatível com snapshots antigos; normaliza aliases e mantém pendingRemoval e exclusão Glowy → Bolt. |
| `shared/counterSyncClient.ts` | Aceita query mais recente após SSE e impede regressão para snapshot antiga. |
| `shared/counterSyncSnapshot.ts` | Helpers comuns de normalização e união dos rosters. |
| `shared/draft.ts` | Tipa counterSnapshotVersion, compartilha identidade de aliases e preserva relações publicadas fora da lista de candidatos, sem mudar fórmulas. |

## Validação

Executados no diretório do projeto, com `node_modules/.bin` à frente do PATH para usar pnpm 10 compatível com o projeto:

- `pnpm run check`: sucesso, exit 0.
- `pnpm test`: sucesso, exit 0, 235 testes em 24 arquivos.
- `pnpm run build`: sucesso, exit 0, Vite e esbuild.

Os logs finais estão em `validation/check.log`, `validation/test.log` e `validation/build.log` neste pacote.

O ZIP original foi testado separadamente: 49 falhas em 230 testes. Quatro suítes auditavam dados estáticos sem ativar o fallback offline exigido pelo código. Sua preparação foi corrigida explicitamente, preservando as asserções existentes. O teste de proveniência passou a comparar aliases com a normalização comum. Produção continua sem fallback offline automático.

Cobertura nova: alvos Calculator/Planet fora do roster BrawlScope; união de todas as fontes; globais disponíveis em modo específico; exclusão de BrawlScope de outro modo; perfil geral e catálogo parcial de brawler exclusivo; aliases editoriais; pendingRemoval e Glowy/Bolt; aplicação de query após SSE; score Draft diferente após nova snapshot e dependências de counterSnapshotVersion.

## Limitações e comportamento das fontes

- PL Prodigy entra como catálogo publicado estático auditado, sem alegação de coleta dinâmica.
- BrawlScope mantém evidência específica de cada um dos seis modos. Calculator/Planet/Prodigy sem modeId permanecem globais, com rótulo “Global da fonte”. Nenhuma relação global é convertida em relação por modo.
- Não foi executada uma coleta de produção nem alterada a snapshot persistida no banco. As contagens reais dependem da próxima sincronização normal das fontes; os testes usam fixtures isoladas.
- O build avisa sobre variáveis de analytics ausentes, imagem de fundo a resolver em runtime e chunks acima de 500 kB. Credenciais e assets existentes não foram alterados para resolver esses avisos.
- O pnpm 11 do ambiente precisou de uma configuração temporária para instalar o lockfile existente; ela foi removida. Alguns scripts de instalação foram bloqueados, mas os três comandos finais passaram com as dependências instaladas. Package.json e lockfile permanecem byte a byte iguais aos originais.

## Preservação e entrega

Não foram apagados dados, executados DROP TABLE, alterados OAuth, autenticação, credenciais ou regras de acesso. Não foram criadas relações por inferência ou reciprocidade. SSE e refresh manual paralelo foram preservados. A invalidação de counterSync.snapshot/status continua no onSuccess do refresh de counters. Nenhuma fórmula de pontuação foi alterada.

Nenhuma alteração manual posterior de código ou lógica é necessária. A publicação não foi executada. A atualização persistida usará a sincronização normal já existente.

## Saída gerada pelo build

Arquivo existente regenerado: `dist/index.js`.

Arquivos novos gerados/copiados pelo build (lista exata):

- `dist/public/.gitkeep`
- `dist/public/__manus__/debug-collector.js`
- `dist/public/__manus__/version.json`
- `dist/public/assets/BrawlerDetail-Cg2_3r_j.js`
- `dist/public/assets/Brawlers-DfC061MH.js`
- `dist/public/assets/Draft-DdWXAdlo.css`
- `dist/public/assets/Draft-kJkXv5M9.js`
- `dist/public/assets/Home-BTsThP-K.js`
- `dist/public/assets/MatchupMatrix-DI5NzPOd.js`
- `dist/public/assets/brawlerCatalog-Dure2bOG.js`
- `dist/public/assets/chevron-right-Jb8xJlKk.js`
- `dist/public/assets/database-DAhHdOSb.js`
- `dist/public/assets/draft-BAJsCafK.js`
- `dist/public/assets/draftRules-BcTtmArA.js`
- `dist/public/assets/hybridWeights-BR8V0YVg.js`
- `dist/public/assets/index-Bou9iRp_.js`
- `dist/public/assets/index-DLHDP0VY.css`
- `dist/public/assets/rankedData-DR86j-RW.js`
- `dist/public/assets/search-Csa4KCDU.js`
- `dist/public/assets/shield-Bh719yoA.js`
- `dist/public/assets/sliders-horizontal-MOscUySz.js`
- `dist/public/assets/star-S5v1lcEC.js`
- `dist/public/assets/x-B7piXCOh.js`
- `dist/public/index.html`

## Arquivos adicionais de entrega

- `COUNTER_FIX_REPORT.md` (este relatório)
- `COUNTER_FIX.patch` (diff exato dos 17 arquivos de código/testes, contra o ZIP recebido)
- `validation/check.log`
- `validation/test.log`
- `validation/build.log`

Não há exclusões de arquivos do ZIP original. node_modules, caches e a cópia temporária de comparação não fazem parte da entrega.
