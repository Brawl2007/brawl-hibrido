# Validação visual — correção dos ativadores

As capturas automáticas de `/draft` e `/matchup-matrix` falharam duas vezes, embora o servidor de desenvolvimento esteja em execução e o último reinício reporte `typescript: No errors`. O build de produção e os testes Vitest foram concluídos com sucesso. A validação visual deve continuar pelo preview/browser ou ser repetida após a publicação.

## Reprodução no site publicado — 2026-08-16

O site publicado em `https://brawlhub-hv3h5xuy.manus.space/draft` carregou corretamente. O Draft começa no turno `Ban · Azul`; os avisos de fatores ficam dentro de cada cartão da lista completa de recomendações. A próxima etapa é avançar os bans e selecionar dois Picks aliados de uma classe comum para verificar se o chip de desbónus é realmente renderizado.

Uma tentativa automática de avançar os seis bans não alterou o turno visível; o Draft permaneceu em `Ban · Azul`. A reprodução continuará com interações diretas, um turno de cada vez.

O primeiro clique direto em `PASSAR BAN` funcionou: o slot Azul passou a `Ban ignorado · passo livre` e o turno ativo avançou para `Ban · Vermelha` (1/12). Isto confirma que o fluxo de simulação funciona por interação direta.

Os dois bans seguintes também avançaram corretamente. O estado publicado chegou a `Ban · Vermelha`, com 3/12 passos concluídos e os slots de ban ignorado atribuídos às equipas conforme a sequência.

Os três bans restantes foram passados. O site publicado agora está no `Pick · Azul` (turno 7/12), com os seis bans marcados como `passo livre`. A lista de recomendações apresenta fatores ativos como Fit e Abertura; a próxima reprodução selecionará Pearl e, depois dos picks adversários necessários, Carl para testar o desbónus de mesma classe com um caso concreto.

Reprodução concluída no site publicado: Pearl foi escolhida pelo Azul, Bolt e Bo foram escolhidos pela Vermelha, e Carl foi pesquisado no turno Pick Azul. O conteúdo renderizado contém `Mesma Classe −3.31 pts (−5%) — ativado por: Pearl · classe Dano`. Portanto, o cálculo e o detalhe já chegam ao cartão de Carl, mas o aviso está enterrado na lista longa de fatores e não está suficientemente visível para orientar o utilizador. A correção necessária é uma faixa persistente de alerta de composição junto ao comando de Pick, antes das recomendações.

Validação da nova interface no preview atualizado: foram passados os seis bans, Pearl foi escolhido pelo Azul e Bolt/Bo pela Vermelha. No turno `Pick · Azul`, antes da lista de recomendações, a página mostrou a faixa `ALERTA DE COMPOSIÇÃO · DESBÓNUS ATIVO` com o texto `DANO — −5% ativado por: Pearl — 14 candidatos serão afetados nesta lista`. A nova faixa torna a razão da penalização visível sem abrir ou procurar o cartão de Carl.

## Resumo de penalizações por cartão — 2026-08-16

O servidor local respondeu `HTTP 200` para `/draft` após o reinício. A sessão visual automatizada desta iteração redirecionou para `about:blank`, tendo sido encerrada para evitar pressão de memória. A mudança foi validada por Vitest (84/84) e build de produção: cada cartão calcula a soma a partir de `enemyCounterPenaltyPoints`, `sameClassPenaltyPoints` e `worstTeammatePenaltyPoints`, usando os ativadores estruturados já disponibilizados pelo motor.
