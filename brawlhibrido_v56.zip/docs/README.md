# Documentação do Brawl Híbrido

Havia 58 ficheiros markdown soltos na raiz do projeto. Ninguém os lia assim — e
documentação que ninguém lê é indistinguível de documentação que não existe.
Estão agora agrupados por aquilo para que servem.

Na raiz ficou apenas o [`DEPLOY.md`](../DEPLOY.md), porque é o único que alguém
precisa de ler **antes** de mexer no projeto.

## [`fontes/`](fontes) — de onde vêm os números

Como cada fonte publica os dados e como o projeto os lê. É aqui que está a
resposta para "porque é que este valor é o que é".

Os dois mais importantes:

- [`BRAWLSCOPE_SOURCE_NOTE.md`](fontes/BRAWLSCOPE_SOURCE_NOTE.md) — a convenção
  de sinal do BrawlScope, que é a coisa mais fácil de inverter por engano. A
  fonte publica cada delta na perspetiva do **adversário**: quem countera o
  titular do perfil aparece positivo. O Draft lê ao contrário, na perspetiva do
  brawler que está a ser avaliado. Sem esta inversão, o motor premiava escolher
  um brawler counterado.
- [`BRAWLSCOPE_SYNERGY_SOURCE_NOTE.md`](fontes/BRAWLSCOPE_SYNERGY_SOURCE_NOTE.md)
  — como a percentagem de sinergia por par é validada (WR absoluta − delta = a
  mesma base para todos os pares do titular).

## [`arquitetura/`](arquitetura) — como o sistema está montado

Sincronização em tempo real, esquema dos contextos de counter, recolha de
partidas observadas, migração.

Vale a pena começar por
[`DETECAO_AUTOMATICA_ROSTER.md`](arquitetura/DETECAO_AUTOMATICA_ROSTER.md): é o
que faz o site acompanhar sozinho as trocas de mapas e os brawlers novos, sem
ninguém editar listas a cada temporada.

## [`auditorias/`](auditorias) — o que foi verificado e quando

Registos de validação. São fotografias de um momento: valem como prova de que
uma verificação foi feita, não como descrição do estado atual. Quando uma
auditoria contradiz o código, é o código que manda.

## [`historico/`](historico) — processo e transferência

Memória de conversas, manifesto de replicação, notas de entrega, ideias por
fazer.

---

**Onde está a verdade, na prática:** nos testes. `pnpm test` corre ~365
asserções que descrevem as regras do motor com muito mais precisão — e muito
mais atualizadas — do que qualquer destes documentos.

---

## Ajustes disponíveis a quem usa o site

Todos guardados por navegador; nenhum altera as fontes nem o que os outros veem.

| Ajuste | Onde | O que faz |
|---|---|---|
| Vitória / Uso | Início → Ajustar o Score Híbrido | Ponderação da fórmula base (padrão 70/30). |
| **TopBrawl / Brawl Planet** | Início, ao lado do anterior | Quanto cada fonte conta na taxa de vitória e no uso (padrão 50/50). Quando só uma publica um brawler, vale essa por inteiro. |
| Leitura dos matchups | Draft → Configurar regras | Tabela geral ou tabelas por modo. |
| **Counter por Pick, pick a pick** | Draft → Configurar regras | Multiplicador independente para cada um dos seis picks (0,25× a 3×). |
| Regras percentuais | Draft → Configurar regras | Bans, fit de posição, desbónus. |
