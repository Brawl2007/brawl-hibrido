# Publicar o Brawl Híbrido sem o Manus

Guia de cliques. Não há comandos nenhuns para escrever. São três sítios, por
esta ordem: **GitHub** (guarda o código), **Aiven** (guarda os dados) e
**Render** (põe o site no ar). Nenhum deles pede cartão.

Conta com uma hora à primeira vez, quase toda à espera.

---

## Antes de começar

Vais criar três palavras que não podes perder. Escreve-as num sítio teu:

| O quê | Para que serve |
|---|---|
| Conta GitHub | Guardar o código |
| Conta Aiven | A base de dados |
| Conta Render | O site |
| **Palavra-passe de dono** | Entrares no teu próprio site. Inventa-a tu, com 12 letras ou mais. |

A palavra-passe de dono não existe em lado nenhum antes de a escreveres no
Render. Não é recuperável: se a perderes, mudas o valor no Render e reinicias.

---

## Parte 1 — Pôr o código no GitHub

1. Abre **github.com** e entra na tua conta.
2. Carrega no **+** no canto superior direito → **New repository**.
3. Em *Repository name* escreve `brawl-hibrido`.
4. Escolhe **Private**. O código é teu e não precisa de estar à vista.
5. **Create repository**.
6. Na página que aparece, carrega em **uploading an existing file** (o link no
   meio da página).
7. Abre a pasta do projeto no teu computador, seleciona **tudo o que está lá
   dentro** e arrasta para a janela do GitHub.
8. Espera. São perto de 400 ficheiros e demora alguns minutos. A barra no fundo
   mostra o progresso.
9. Quando parar, carrega no botão verde **Commit changes**.

**Confirmação:** a página do repositório mostra pastas chamadas `client`,
`server`, `shared` e um ficheiro `render.yaml`. Se o `render.yaml` não estiver
lá, o passo 3 da Parte 3 não vai funcionar.

---

## Parte 2 — Criar a base de dados na Aiven

1. Abre **aiven.io** → **Get started for free**. Regista-te (não pede cartão).
2. **Create service** → escolhe **MySQL**.
3. No plano, escolhe **Free**.
4. Na região, escolhe a mais perto de ti na Europa.
5. **Create service**.
6. A base de dados demora uns minutos a ficar pronta. Espera até o estado passar
   de *Rebuilding* para **Running** (verde).
7. Nessa página, procura **Service URI**. É um endereço que começa por
   `mysql://`. Carrega no ícone de copiar ao lado.
8. Cola-o num bloco de notas. É isto que o Render te vai pedir.

**Confirmação:** o endereço copiado parece-se com
`mysql://avnadmin:AVNS_xxxx@brawl-db-teunome.h.aivencloud.com:12345/defaultdb?ssl-mode=REQUIRED`.

> Esse endereço é uma chave: dá acesso completo aos teus dados. Não o mostres a
> ninguém e não o escrevas em conversas.

---

## Parte 3 — Publicar o site no Render

1. Abre **render.com** → **Get Started** → entra **com a conta GitHub**.
2. Autoriza o Render a ver os teus repositórios.
3. No painel, **New +** → **Blueprint**.
4. Escolhe o repositório `brawl-hibrido` → **Connect**.
5. O Render lê o ficheiro `render.yaml` e já sabe o que fazer. Só te pergunta
   duas coisas:
   - **DATABASE_URL** → cola o endereço que copiaste da Aiven.
   - **OWNER_PASSWORD** → escreve a tua palavra-passe de dono (12 letras ou mais).
   - Se também perguntar **BRAWL_STARS_API_KEY**, podes deixar em branco por
     agora.
6. **Apply** (ou *Create*).
7. Agora demora. O primeiro build leva entre 5 e 15 minutos. Vais ver texto a
   correr; é normal. Espera pela palavra **Live** a verde no topo.

**Confirmação:** no topo da página há um endereço parecido com
`https://brawl-hibrido.onrender.com`. Abre-o. O site abre.

---

## Parte 4 — Entrar como dono

1. No teu site, acrescenta `/entrar` ao endereço:
   `https://brawl-hibrido.onrender.com/entrar`
2. Escreve a palavra-passe de dono → **Entrar**.
3. Vai a **Draft → Estado das fontes**.

**Confirmação:** o painel diz `perfil dono` e o botão **Atualizar agora** deixa
de recusar.

Se a página de entrar disser *"Este site ainda não tem palavra-passe"*, a
variável `OWNER_PASSWORD` não chegou ao site: no Render, vai a **Environment**,
confirma que lá está, e carrega em **Manual Deploy → Deploy latest commit**.

---

## O que esperar depois

**O site adormece.** No plano gratuito do Render, 15 minutos sem ninguém a
visitar e o site desliga-se. A visita seguinte acorda-o e demora cerca de um
minuto a abrir. Não está avariado — está a levantar-se. Enquanto dorme, não faz
as recolhas de 15 em 15 minutos; faz uma assim que acorda.

**As tabelas criam-se sozinhas.** Da primeira vez que o site arranca com a base
de dados ligada, cria o que falta. Não tens de correr nada.

**O BrawlScope pode continuar a recusar.** A mudança de casa muda o endereço de
onde os pedidos saem, e é possível que passem a ser aceites — mas não é certo, e
não é por isso que estás a mudar. Vê em **Estado das fontes**: se continuar a
falhar, as outras três fontes continuam a alimentar o site na mesma, e tens a
colagem manual das fichas.

**A base de dados tem 1 GB.** Chega e sobra para o que o site guarda.

---

## Quando quiseres mudar o código

1. Altera os ficheiros no GitHub (ou volta a carregá-los como na Parte 1).
2. O Render repara sozinho e volta a publicar.

Não precisas de mais ninguém para isso. Era esse o objetivo de sair do Manus.

---

## Variáveis, todas juntas

Definem-se no Render, em **Environment**. As duas primeiras são obrigatórias.

| Nome | Valor |
|---|---|
| `DATABASE_URL` | O endereço da Aiven. |
| `OWNER_PASSWORD` | A tua palavra-passe de dono, 8 letras no mínimo. |
| `JWT_SECRET` | Gerado pelo Render. Não lhe toques. |
| `BRAWL_STARS_API_KEY` | A chave da API oficial, se e quando a tiveres. |
| `DATABASE_CA_CERT` | Opcional. O certificado da Aiven, se quiseres a ligação verificada além de cifrada. |
| `OWNER_EMAIL` | Não é preciso: quem sabe a palavra-passe já é o dono. |
