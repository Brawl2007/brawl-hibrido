from pathlib import Path

from youtube_transcript_api import YouTubeTranscriptApi


VIDEO_IDS = ["Vn13u4Uggqc", "aH9oCZG5XkM"]
OUTPUT_DIR = Path("/home/ubuntu/brawl-hibrido/research/youtube")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    api = YouTubeTranscriptApi()

    for video_id in VIDEO_IDS:
        transcript = api.fetch(video_id, languages=["en", "en-US", "pt", "pt-BR"])
        lines = [
            f"{entry.start:.1f}\t{entry.duration:.1f}\t{entry.text}"
            for entry in transcript
        ]
        (OUTPUT_DIR / f"{video_id}.tsv").write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"EXTRAIDO {video_id}: {len(lines)} linhas")


if __name__ == "__main__":
    main()
