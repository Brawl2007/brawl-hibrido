import fs from "node:fs";

const primaryPath = "/home/ubuntu/extract_brawlscope_counters.json";
const supplementPath = "/home/ubuntu/recollect_brawlscope_missing.json";
const outputPath = "/home/ubuntu/brawl-hibrido/research/brawlscopeCountersMerged.json";

const primary = JSON.parse(fs.readFileSync(primaryPath, "utf8"));
const supplement = JSON.parse(fs.readFileSync(supplementPath, "utf8"));

const bySlug = new Map(primary.results.map((entry) => {
  const url = entry.output?.source_url ?? "";
  return [new URL(url).searchParams.get("brawler"), entry];
}));

for (const entry of supplement.results) {
  const output = entry.output;
  if (!output?.has_readable_data || !output.source_url) continue;

  const slug = new URL(output.source_url).searchParams.get("brawler");
  if (!slug) continue;

  bySlug.set(slug, {
    input: output.brawler,
    output: {
      brawler: output.brawler,
      counters_target: output.countered_by,
      has_readable_data: true,
      source_url: output.source_url,
      target_counters: output.targets,
    },
    error: "",
  });
}

const results = [...bySlug.values()].sort((left, right) =>
  String(left.output?.brawler).localeCompare(String(right.output?.brawler)),
);

fs.writeFileSync(outputPath, `${JSON.stringify({ results }, null, 2)}\n`);
console.log(`Wrote ${results.length} BrawlScope records to ${outputPath}`);
