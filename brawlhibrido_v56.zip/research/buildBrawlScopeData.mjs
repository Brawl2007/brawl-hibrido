import fs from "node:fs";
import path from "node:path";

const sourcePath = "/home/ubuntu/brawl-hibrido/research/brawlscopeCountersMerged.json";
const outputPath = "/home/ubuntu/brawl-hibrido/shared/brawlScopeCounterData.ts";

const normalizeList = (value) => String(value || "")
  .split("|")
  .map((item) => item.trim())
  .filter(Boolean);

const TOP_BRAWLSCOPE_RELATIONS = 10;

const topBrawlScopeRelations = (value) => normalizeList(value).slice(0, TOP_BRAWLSCOPE_RELATIONS);

const source = JSON.parse(fs.readFileSync(sourcePath, "utf8"));
const records = {};

for (const entry of source.results) {
  const output = entry.output;
  if (!output || output.has_readable_data !== true) continue;

  const slug = new URL(output.source_url).searchParams.get("brawler");
  if (!slug) continue;

  records[slug] = {
    // BrawlScope's "Best picks against <target>" list: brawlers countered by this target.
    counteredBy: topBrawlScopeRelations(output.counters_target),
    // BrawlScope's "Who <target> punishes" list: brawlers countered by this target.
    targets: topBrawlScopeRelations(output.target_counters),
    sourceUrl: output.source_url,
  };
}

const ordered = Object.fromEntries(Object.entries(records).sort(([left], [right]) => left.localeCompare(right)));
const content = `/**
 * AUTO-GENERATED from public BrawlScope Counter pages on 2026-08-18.
 *
 * Only pages with readable, literal counter lists are included. Missing pages
 * intentionally remain absent: no counter relation is inferred or backfilled.
 * Each direction preserves BrawlScope's published order and is capped at Top ${TOP_BRAWLSCOPE_RELATIONS}.
 * Source pages: https://brawlscope.com/counters?brawler=<slug>
 */
export const brawlScopeCounterData = ${JSON.stringify(ordered, null, 2)} as const;

export type BrawlScopeCounterEntry = (typeof brawlScopeCounterData)[keyof typeof brawlScopeCounterData];
`;

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, content);
console.log(`Wrote ${Object.keys(ordered).length} readable BrawlScope profiles to ${outputPath}`);
