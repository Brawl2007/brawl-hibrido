# Validação da auditoria de counters

## Evidências — 18 de agosto de 2026

A página `/draft` da pré-visualização carregou e apresentou a regra publicada no resumo: **Enemy Counter −5%**, **Pressão Enemy Counter −5% por aliado, até −10%**, e **Counter Top −3%** com a janela dinâmica `20/17/14/11/8/5`.

A captura automática em página inteira não foi concluída pelo ambiente. A validação visual dos cartões continuará através da pré-visualização interativa; a nova auditoria foi implementada apenas com `signal` e `topRecommendationNames` já calculados pelo ranking central, sem uma segunda ordenação ou novo cálculo de score.
