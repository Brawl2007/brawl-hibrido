Starting video analysis...
Submitting video analysis task...
Task submitted (ID: video-analysis-42a21ead-6578-4929-81d8-398fafcc7b1d)
[8s] Status: Analyzing video content with AI...
[34s] Still processing, please wait...
[1m3s] Still processing, please wait...
[1m34s] Still processing, please wait...
[2m3s] Still processing, please wait...
[2m5s] Status: Analysis completed
[2m5s] Analysis completed!
Full analysis result saved to: /home/ubuntu/video_Vn13u4Uggqc_analysis_20260821_162532.md
Note: This tool performs AI-based visual and audio analysis, not verbatim transcription. For detailed speech transcription, use `manus-speech-to-text` instead.
Analysis result:

Com base na análise do vídeo, aqui estão as recomendações explícitas e observáveis sobre o sistema de *Draft* (escolha de brawlers) no Brawl Stars, categorizadas conforme solicitado:

### 1. Papéis de Equipa, Counters e Ordem de Escolha por Classe

O criador do vídeo divide os Brawlers em 7 classes específicas para o Draft, com regras claras para cada uma:

**Lançadores (Throwers) [03:42 - 08:03]**
*   **Ordem de Pick:** Devem ser escolhidos **sempre no último pick** (last pick).
*   **Counters:** São duramente counterados por "Space Makers" (Assassinos/Brawlers com mobilidade).
*   **Exceções:** *Willow* (boa Anti-Tanque, pode ser 1º pick ou 2º/3º pick) e *Berry* (bom curador/dano para Pique-Gema/Zona Estratégica, bom contra composições de baixo dano).

**Criadores de Espaço (Space Makers / Assassinos) [08:04 - 13:30]**
*   **Papel:** Criar espaço no mapa e eliminar Brawlers com pouca vida.
*   **Counters:** Eles counteram Lançadores, Atiradores e Brawlers de Controle. São counterados por Tanques e Anti-Tanques.
*   **Ordem de Pick:** Idealmente escolhidos do meio para o fim do draft, a menos que o time inimigo já tenha mostrado fraqueza contra eles.

**Anti-Tanques [13:31 - 18:30]**
*   **Papel:** São os Brawlers mais consistentes do jogo, com alto dano e poucas fraquezas.
*   **Ordem de Pick:** **Melhor opção para 1º pick** na maioria dos modos de jogo (exceto Caça-Estrelas/Nocaute).
*   **Counters:** Eles counteram Tanques e Space Makers.

**Controle (Control) [18:31 - 20:55]**
*   **Papel:** Dominar o mapa e destruir Brawlers de médio alcance (Anti-Tanques).
*   **Counters:** São duramente counterados por Space Makers (devido à falta de dano explosivo para parar avanços rápidos).
*   **Ordem de Pick:** **Nunca devem ser o 1º pick**. Devem ser escolhidos no 2º ou 3º pick, desde que a sua equipa já tenha um Anti-Tanque.

**Atiradores (Snipers) [20:56 - 23:57]**
*   **Papel:** Dano a longa distância. Pertencem quase exclusivamente aos modos Caça-Estrelas e Nocaute.
*   **Ordem de Pick:** Geralmente devem ser o **último pick**, pois são facilmente punidos por Space Makers.
*   **Exceções:** Belle, Byron e Gus funcionam mais como suporte/dano de médio alcance e podem ser escolhidos mais cedo [21:37].

**Tanques (Tanks) [23:58 - 26:26]**
*   **Papel:** Alta vida e combate a curta distância.
*   **Ordem de Pick:** Escolha-os apenas se a equipa inimiga **não tiver um Anti-Tanque** ou se não tiver dano suficiente para derrubá-los.
*   **Counters:** Eles counteram Space Makers e composições de baixo dano.

**Suporte (Support) [26:27 - 28:57]**
*   **Sinergia:** **Nunca escolha um Suporte se a sua equipa não tiver causadores de dano (Damage Dealers)**. Eles existem para facilitar a vida da equipa, mas não conseguem carregar o jogo sozinhos devido ao baixo dano.
*   **Counters:** Excelentes contra equipas inimigas que não têm dano suficiente para superar a cura/utilidade que o suporte fornece.

---

### 2. Estratégias de Draft por Mapa / Modo de Jogo

O vídeo divide os modos de jogo em dois "Metas" principais de Draft:

**Meta Aggro (Fute-Brawl, Pique-Gema, Roubo, Zona Estratégica) [28:58 - 31:55]**
*   **1º Pick:** Escolha o melhor Anti-Tanque disponível.
*   **2º e 3º Picks:** Escolha um counter para o 1º pick inimigo, OU o próximo melhor Anti-Tanque, OU um Space Maker. Em Pique-Gema, garanta alguém para carregar as gemas.
*   **4º e 5º Picks:** Escolha counters para as fraquezas da equipa inimiga.
*   **Último Pick (6º):** Escolha um counter absoluto (Lançador, Atirador ou um Space Maker específico) para o qual o inimigo não tenha resposta.

**Meta Passivo (Caça-Estrelas e Nocaute) [31:56 - 34:55]**
*   **1º Pick:** Escolha um Brawler sólido que seja bom contra composições agressivas (ex: Gene, Leon, Brawlers com dano perfurante). Evite Atiradores puros no primeiro pick.
*   **2º e 3º Picks:** Countere o 1º pick inimigo ou escolha Brawlers muito fortes no meta (como Belle, Gus, Byron).
*   **4º e 5º Picks:** Fase de counter direto. Se o inimigo escolheu Atiradores, escolha Space Makers. Se escolheram Space Makers, escolha Anti-Tanques.
*   **Último Pick (6º):** Counter absoluto (geralmente um Atirador, Lançador ou um Assassino focado como Mortis).

---

### 3. Sinergia, Bans e Como Lidar com Randoms

**Como lidar com escolhas ruins de aliados (Randoms) [34:56 - 38:08]**
*   Se o seu colega de equipa fizer um 1º pick horrível (ex: Mortis no primeiro pick), **não desista e não faça um pick "troll" de vingança**.
*   **Adapte-se:** Analise o que o inimigo escolheu para counterar o seu aliado e escolha um counter para isso. *Exemplo dado:* Se o seu aliado escolhe Mortis e o inimigo responde com Shelly (Anti-Tanque), você deve escolher um Brawler que countere a Shelly (ex: um Atirador ou Controle), equilibrando a composição.

**Bans [37:16 - 38:00]**
*   Se a equipa inimiga tiver o 1º pick e banir os melhores Brawlers de uma classe (ex: banir os melhores Anti-Tanques), você deve banir os próximos melhores dessa mesma classe para limitar severamente as opções deles, forçando-os a jogar com Brawlers sub-otimizados.
*   Em modos passivos (Caça-Estrelas/Nocaute), se você tiver o 1º pick e quiser jogar com um Atirador, bana os melhores Space Makers/Assassinos.

---

### 4. Erros Fatais a Evitar no Draft

*   **Não repita classes:** Nunca escolha 3 Brawlers da mesma classe (ex: 3 Anti-Tanques ou 3 Atiradores). Isso cria uma fraqueza massiva na equipa que pode ser facilmente explorada pelo último pick inimigo [30:15].
*   **Cuidado com a falta de dano:** Evite composições onde 2 ou 3 Brawlers têm baixo dano (ex: Controle + Suporte sem um Anti-Tanque). O inimigo simplesmente escolherá um Tanque ou Space Maker e atropelará a sua equipa [18:58 / 28:15].
*   **Não escolha Lançadores cedo:** Escolher um Lançador antes do último pick é um convite para a equipa inimiga escolher um Assassino/Space Maker e tornar o seu Lançador inútil [04:53].
*   **Não olhe apenas para o seu confronto direto:** Ao escolher no 4º ou 5º pick, não olhe apenas para o Brawler que você quer counterar. Olhe para a "imagem maior" (Big Picture). Se a sua equipa já tem counters suficientes para um Brawler inimigo, foque em counterar o resto da composição ou preencher a fraqueza da sua própria equipa [11:43].
