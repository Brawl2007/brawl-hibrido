# Fonte da tabela de alcance dos Brawlers

A tabela de alcance usa a página pública do Brawl Planet: <https://www.brawlplanet.com/tier-list/attack_range>. A página classifica o **ataque base** em seis faixas de blocos e lista os 106 brawlers atuais. As faixas publicadas são: S (9,5–10,9), A (8,0–9,4), B (6,5–7,9), C (5,0–6,4), D (3,5–4,9) e F (2,0–3,4).

O Brawl Híbrido deve apresentar estas **faixas**, e não converter cada brawler para uma distância artificialmente precisa. Esta decisão preserva a fonte para brawlers com ataques por fases, transformações ou múltiplos modos.

Como validação complementar de estatísticas individuais, foi consultada a base pública <https://brawlstars-stats.azurewebsites.net/Brawlers>. A tabela usa apenas a classificação por faixa do Brawl Planet, porque esta cobre explicitamente os 106 brawlers, incluindo Wendy.
