# Estrutura validada das fichas do Brawl Planet

Fonte observada em 15-08-2026: https://www.brawlplanet.com/brawlers/sandy

Cada ficha individual contém os seguintes blocos relevantes:

- **Matchups / Strong Against**: cinco brawlers contra os quais o brawler tem vantagem; o valor é a diferença de win rate prevista em pontos percentuais.
- **Matchups / Struggles Against**: cinco brawlers contra os quais o brawler tem desvantagem; o valor é a diferença negativa de win rate prevista.
- **Teammates / Best Teammates**: cinco brawlers com que o brawler tem melhor desempenho conjunto; o valor é a diferença positiva de win rate prevista.
- **Teammates / Worst Teammates**: cinco brawlers com pior desempenho conjunto.

Exemplo Sandy: Strong Against = Stu, Surge, Max, Bonnie, Mina; Struggles Against = Chuck, Mico, Mandy, Jessie, Ziggy; Best Teammates = Rico, Clancy, Colt, Bull, Bibi.

Regra de integração: nenhuma lista pode ser gerada por classe, score híbrido ou qualquer heurística. Cada entrada deve ser extraída diretamente da página pública correspondente do Brawl Planet.
