# Auditoria de fontes de counter — 15 de agosto de 2026

| Fonte | URL | Estrutura pública confirmada | Cobertura visível |
|---|---|---|---|
| Brawl Calculator | https://brawlcalculator.com/ | Possui um diretório `Counters by Brawler`; a página informa que oferece um guia completo por brawler com quem o derrota, quem ele derrota e o motivo do matchup. | 105 brawlers visíveis na grelha principal. |
| Power League Prodigy | https://powerleagueprodigy.com/guides | Possui guias individuais públicos de brawlers, apresentados como `Best build and counters`. | Lista pública de guias para os brawlers atuais, incluindo guias marcados como legacy. |
| TopBrawl | https://topbrawl.com/brawlers | Disponibiliza um diretório de fichas individuais (`/brawlers/{slug}`) com desempenho, builds, win rates, uso e dados por modo/mapa. A página pública auditada não apresenta uma lista explícita de `counters` ou `countered by`. | Cobertura pública dos brawlers e estatísticas por modo/mapa; relações diretas de counter ainda não confirmadas. |

## Regras de integração

- Cada relação deve manter a origem explícita: `Brawl Calculator`, `Power League Prodigy` ou `TopBrawl`.
- Não usar a API oficial como fonte de relações de counter nas fichas individuais.
- Não preencher relações ausentes com heurísticas ou inferências.
- O número de entradas por brawler não terá limite visual artificial; cada ficha apresenta todas as relações extraídas e validadas.
- O TopBrawl pode ser apresentado como fonte de contexto estatístico e build, mas não será identificado como fonte de uma relação de counter enquanto a respetiva ficha pública não fornecer essa relação diretamente.

### Verificação direta adicional do TopBrawl

Em 16 de agosto de 2026 foi aberta diretamente a ficha pública de Brock: https://topbrawl.com/brawlers/brock. A página apresenta build mais desbloqueada, Star Powers, Gadgets, Gears, estatísticas por modo e estatísticas Ranked. Nem o conteúdo renderizado nem o texto público apresentam blocos que enumerem brawlers que Brock countera ou brawlers que o counteram. Consequentemente, o projeto não deve fabricar `Countera` ou `Counterado por` a partir de win rate, uso ou score do TopBrawl. A fonte continua válida para contexto estatístico, mapas e builds, mas não para relações diretas até que publique uma lista explícita.

## Estrutura literal validada no Brawl Calculator

Uma ficha individual, como `https://brawlcalculator.com/counters/brock/`, apresenta dois blocos distintos:

| Bloco da fonte | Significado na ficha local |
|---|---|
| `Best counters to [Brawler]` | Brawlers que counteram o brawler analisado (`counteredBy`). |
| `[Brawler] is a strong pick against` | Brawlers que o brawler analisado countera (`targets`). |

As entradas contêm nome, ligação direta à respetiva ficha e explicação tática. A extração deve conservar os dois sentidos e a fonte `Brawl Calculator`.

## Estrutura literal validada no Brawl Planet para sinergia negativa

As fichas públicas de Brock e Sandy foram novamente verificadas em 16 de agosto de 2026. Dentro de `Teammates`, o Brawl Planet publica dois blocos distintos: `Best Teammates` e `Worst Teammates`. O segundo contém cinco aliados e um delta negativo por aliado. A própria fonte define o delta como a diferença de desempenho da dupla face ao que os win rates gerais de ambos fariam prever.

| Bloco da fonte | Significado no projeto |
|---|---|
| `Best Teammates` | Sinergias positivas literais |
| `Worst Teammates` | Sinergias negativas literais; cada aliado presente ativa -5% no Draft |

Fontes verificadas: https://www.brawlplanet.com/brawlers/brock e https://www.brawlplanet.com/brawlers/sandy.
