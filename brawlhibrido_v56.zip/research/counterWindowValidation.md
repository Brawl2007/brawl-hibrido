# Validação da Janela Counter Top

## Evidência visual do utilizador

As capturas de 18 de agosto mostram Glowy na posição 65 com o chip `Desbônus Counter Top 20 ×5`. Isto prova que a elegibilidade de Counter Top divergira da posição final exibida.

## Verificação de desenvolvimento

Em 18 de agosto, a página `/draft` respondeu no ambiente de desenvolvimento e apresentou a regra visível `Top 20/17/14/11/8/5`, bem como a descrição da Pressão Enemy Counter. A tentativa seguinte de inspecionar os controlos de pesquisa falhou porque o navegador deixou de estar disponível; os testes de motor e apresentação continuam a ser a validação automatizada para o caso Glowy.
