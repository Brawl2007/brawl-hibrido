# Fonte de counter — PL Prodigy

## Evidência pública

O simulador público do PL Prodigy mostra que os seus dados de Draft foram atualizados em **24 de agosto de 2026** e que a interface inclui o catálogo atual de brawlers. A página de guias carrega no cliente uma matriz explícita de relações por ID oficial, com os campos `countersTheseIds` e `counteredByIds`.[1] [2]

O bundle público de guias contém uma matriz `byBrawlerId`. A extração passiva de `guides-page.js`, traduzida pelo catálogo público de IDs, produziu **106 perfis**, **848 relações de counter** e **848 relações de counterado**, sem IDs sem correspondência. A matriz contém oito entradas em cada direção por perfil no estado observado.

## Uso permitido no projeto

Esta integração deve ser apresentada como **PL Prodigy — relações públicas de guias**, com URL de proveniência própria. Não deve ser descrita como a fórmula do Draft nem como uma inferência do sistema de recomendações. As relações permanecem uma fonte separada: BrawlScope, Brawl Calculator e Brawl Planet continuam preservadas.

## Salvaguardas propostas

| Regra | Decisão |
|---|---|
| Direção | `countersTheseIds` significa que o brawler titular countera o alvo; `counteredByIds` significa que o titular é counterado pelo outro brawler. |
| Proveniência | Cada perfil e chip do Draft indica explicitamente PL Prodigy e a respetiva URL pública. |
| Conflitos | Uma divergência não substitui uma direção já publicada por fonte prioritária; pode ser mostrada como evidência adicional. |
| Atualização | A matriz será tratada como snapshot público versionável, não como uma fórmula proprietária ou endpoint privado. |

## Verificação do Draft

Em 24 de agosto de 2026, a rota pública `/draft` foi aberta após o reinício do servidor. O quadro carregou o ranking, a janela Counter Top e a engine de counter sem erro de módulo ou de TypeScript. A origem PL Prodigy é entregue pelo mesmo resolvedor de perfis usado pelo Draft; por isso aparece junto das restantes fontes quando o utilizador abre o detalhe de relações de um brawler, preservando o respetivo nome e URL de origem.

## Referências

[1]: https://powerleagueprodigy.com/plprodigy "PL Prodigy — Draft Simulator"
[2]: https://powerleagueprodigy.com/guides "PL Prodigy — Brawler Guides"
