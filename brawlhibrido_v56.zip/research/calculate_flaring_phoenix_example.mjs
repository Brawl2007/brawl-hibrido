const brawlers = [
  { name: "Pearl", score: 67.04784444075364, effects: [{ label: "Sinergia Pick 3", rate: 0.1 }] },
  { name: "Grom", score: 66.20064848092886, effects: [{ label: "Enemy Counter direto", rate: -0.05 }] },
  { name: "Bolt", score: 63.341202251727765, effects: [{ label: "Sinergia Pick 3", rate: 0.1 }, { label: "Counter banido", rate: 0.05 }] },
  { name: "Starr Nova", score: 54.47773613122794, effects: [{ label: "Mesma classe", rate: -0.06 }] },
  { name: "Nori", score: 53.64959362323468, effects: [{ label: "Counter Top", rate: -0.02 }] },
];

const leaderScore = Math.max(...brawlers.map(({ score }) => score));
const result = brawlers.map(({ name, score, effects }) => {
  const basePoints = (score / leaderScore) * 100;
  const netRate = effects.reduce((total, effect) => total + effect.rate, 0);
  const finalPoints = basePoints * (1 + netRate);
  return {
    name,
    score: score.toFixed(2),
    basePoints: basePoints.toFixed(2),
    effects: effects.map(effect => `${effect.label} ${effect.rate >= 0 ? "+" : ""}${(effect.rate * 100).toFixed(0)}%`).join(" + "),
    netRate: `${netRate >= 0 ? "+" : ""}${(netRate * 100).toFixed(0)}%`,
    finalPoints: finalPoints.toFixed(2),
  };
}).sort((a, b) => Number(b.finalPoints) - Number(a.finalPoints));

console.log(JSON.stringify({ leaderScore: leaderScore.toFixed(2), result }, null, 2));
