# Incidente: Counter Top fora do ranking final

As capturas de 18 de agosto mostram Glowy pesquisado com rank visual 65 e o chip `Desbônus Counter Top 20 -15%`, apesar de não estar entre as recomendações finais visíveis. O cartão lista Tick, Eve, Damian, Charlie e Bonnie como counters presentes no Top 20.

Isto demonstra que a regra de elegibilidade do candidato para Counter Top não está a usar a mesma ordenação final apresentada pela lista. A correção deve preservar a sequência visível Top 20 → 17 → 14 → 11 → 8 → 5 → 0 e garantir que nenhum candidato fora do Top final recebe Counter Top ou Pressão Enemy Counter.

As imagens também mostram Bolt no rank 02 com `Desbônus Counter Top 20`, que é compatível com a regra por estar dentro da janela.
