# Fontes da auditoria de classes

## Taxonomia oficial

- **Supercell Support — Brawler Classes**: https://support.supercell.com/brawl-stars/en/articles/brawler-classes.html
- Consultado em 16 de agosto de 2026.
- A Supercell define sete classes oficiais: **Damage Dealer, Assassin, Marksman, Artillery, Tank, Support e Controller**. A página indica que cada brawler recebe uma classe específica apresentada no canto superior esquerdo da sua ficha no jogo.

## Cobertura pública do elenco

- **NOFF — All 106 Brawl Stars Brawlers**: https://www.noff.gg/brawl-stars/brawlers
- Consultado em 16 de agosto de 2026.
- A página afirma listar 106 brawlers e permite filtrar por classe. A lista visível inclui perfis que estão ausentes do dicionário atual do Draft, como **Mr. P, Najia, Otis e Pierce**, além de um perfil de **Wendy** no início da grelha.

## Constatação inicial no projeto

- O dicionário `shared/draft.ts` contém 100 entradas de classe.
- Os dados extraídos do Brawl Planet contêm 106 perfis normalizados.
- Antes de alterar o motor, a auditoria deve reconciliar estes catálogos e converter as sete classes oficiais para os rótulos em português usados pela interface.

## Confirmação oficial adicional

- **Supercell Support — Brawler Classes**: https://support.supercell.com/brawl-stars/en/articles/brawler-classes.html
- Consultado em 16 de agosto de 2026.
- A página confirma sete classes oficiais: Damage Dealer, Assassin, Marksmen, Artillery, Tank, Support e Controller. Indica que a classe aparece no canto superior esquerdo da ficha do brawler. Não fornece no texto uma tabela completa de brawler → classe; por isso, entradas individuais devem ser validadas por fonte pública de catálogo ou ficha individual.

## Catálogo público de cobertura

- **Noff — All 106 Brawl Stars Brawlers**: https://www.noff.gg/brawl-stars/brawlers
- Consultado em 16 de agosto de 2026.
- A página apresenta 106 perfis e disponibiliza filtros por Rarity, Class e Traits. A extração de texto da página confirmou a cobertura nominal do elenco atual, mas não expôs no Markdown a classe individual de cada cartão; por isso, a página deve ser usada com inspeção DOM/perfil quando necessário.

## Extração DOM das classes

Na consulta DOM realizada em 16 de agosto de 2026, os cartões da Noff expuseram os atributos `data-class`, `data-range`, `data-rarity` e `data-id` para os perfis. A taxonomia observada usa as classes inglesas Damage Dealer, Assassin, Controller, Marksman, Tank, Artillery e Support. Exemplos confirmados: Bonnie = Marksman, Bolt = Tank, Brock = Marksman, Mr. P = Controller, Wendy = Support. A comparação deve normalizar estas classes para a nomenclatura interna do Draft, sem usar uma classe Flex por defeito quando exista uma entrada pública.
