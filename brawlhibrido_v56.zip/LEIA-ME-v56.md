# Brawl Híbrido v56

Correções:
- Detalhes expandidos ocupam a largura inteira do cartão. Auditorias numa coluna, com quebra de linha e sem reticências.
- Os cartões mostram vitória e uso agregados usados no ranking; a estimativa por posição não aparece como vitória publicada.
- Ordenação padrão por Score Híbrido base, respeitando os pesos Vitória/Uso escolhidos (70/30 por padrão), com normalização por mapa já utilizada no projeto.
- A opção «Pontos do Draft · com bónus» mantém a ordenação contextual. Bónus, counters, sinergias e janelas do motor não são alterados pela escolha de ordenação visual.
- O número da lista acompanha a ordenação escolhida. O valor «Pontos finais» continua a incluir os ajustes contextuais, como informa o seletor.
- A tabela híbrida de fontes mostra a mesma vitória agregada usada no cálculo.

Validação: 20 testes aprovados, incluindo Bonnie/Nita (mesma vitória, maior uso), mudança de pesos e monotonicidade em todo o catálogo incluído. TypeScript e compilação aprovados. Dados e estado do site Render não foram acessados; a conferência visual no Chromebook continua necessária.

Substitua o ZIP anterior no GitHub por brawlhibrido_v56.zip, mantendo só um ZIP na raiz. Não precisa extrair. Depois do deploy, confirme v56 no canto superior direito.
