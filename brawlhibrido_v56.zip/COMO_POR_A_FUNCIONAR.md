# Pôr o site a funcionar — lista de verificação

Quatro passos, por ordem. Cada um diz o que vais ver quando estiver certo.
Depois de publicares, abre o **Draft → Estado das fontes**: é aí que tudo se
confirma, sem precisares de ler logs.

---

## 1. Criar as tabelas da base de dados

Numa instalação nova as tabelas não existem, e é isso que produz
`Failed query: select ... from ranked_sync_config`.

```bash
pnpm db:push
```

**Confirmação:** o aviso vermelho *"Base de dados inacessível"* desaparece do
painel.

Sem este passo o site ainda abre — usa o catálogo do projeto — mas nada do que
for recolhido fica guardado: a cada reinício perde-se tudo.

---

## 2. Ser reconhecido como dono

Sem dono, o botão "Atualizar agora" e o diagnóstico recusam.

- **Se não houver dono definido:** sai e volta a entrar. A primeira sessão a
  entrar fica dona.
- **Para fixar de vez:** define nas variáveis de ambiente

  ```
  OWNER_EMAIL=o-teu-email@exemplo.com
  ```

**Confirmação:** o painel mostra `Sessão: ... · perfil dono`.

---

## 3. Ligar a API oficial do Brawl Stars

É esta a fonte que passa a construir a matriz de confrontos do site, a partir de
jogos Ranked reais. Ninguém a pode recusar — a chave é tua.

**3.1 — Descobre o IP do teu servidor.** A chave da Supercell fica presa ao IP
que declarares. Carrega em **Testar fontes agora**; a primeira linha é:

```
Servidor · IP de saída
  IP de saída   203.0.113.45 — é este que tens de declarar ao criar a chave
```

**3.2 — Cria a chave** em https://developer.brawlstars.com (gratuita). Ao criar,
cola esse IP no campo de IPs permitidos.

**3.3 — Define a chave** nas variáveis de ambiente do alojamento:

```
BRAWL_STARS_API_KEY=a-tua-chave
```

**Confirmação:** o painel passa de amarelo *"Inativo: falta definir
BRAWL_STARS_API_KEY"* para verde *"Dados próprios — N partidas · N observações"*,
e o contador sobe a cada 15 minutos.

> **Atenção ao IP:** se o alojamento mudar de IP entre reinícios, a chave passa a
> ser recusada com 403. O sintoma parece um bloqueio de fonte, mas a causa é
> outra. O diagnóstico distingue os dois.

---

## 4. O BrawlScope

Não há passo nenhum. A fonte responde `403` ao servidor — bloqueio de rede, não
de configuração — e o contacto ficou sem resposta. O site continua a funcionar:
os counters vêm do Brawl Planet e do PL Prodigy em direto, e a leitura por modo
assume a tabela geral, dizendo-o.

O passo 3 é o que substitui o que se perdeu, e com vantagem: por **mapa**, e não
apenas por modo.

---

## O que esperar depois

| Quando | O que acontece |
|---|---|
| Imediato | Ranked, Brawl Planet e PL Prodigy atualizam sozinhos a cada 15 min |
| Primeiras horas | O contador de partidas observadas começa a subir |
| Ao fim de dias | Confrontos com 30+ observações no mesmo mapa ficam prontos a entrar no Score |

O passo seguinte — ligar esses números ao Score, com a mesma disciplina de
quarentena do roster — fica para quando houver volume. Ligar uma tabela vazia ao
Score não melhoraria nada e arriscaria o que já funciona.
