# Brawl Híbrido v55

Visual da arena em azul, roxo e amarelo; versão no canto superior direito.

- Tabuleiro e sugestões lado a lado a partir de 1150 px. Em telas menores, sugestões imediatamente depois do tabuleiro.
- Tabuleiro acompanha a rolagem em telas largas; se necessário, tem rolagem própria.
- Cartões compactos com nome, posição, vitória, ajuste contextual e pontuação final.
- Botão «Ver detalhes» revela fatores, counters, bans e builds.
- Estratégia, confrontos, referência e opções adicionais recolhidos.
- 12 sugestões por página; busca e filtros continuam a abranger todos os candidatos.
- Animações curtas nos botões e picks, respeitando movimento reduzido. Retirada a animação de reposicionamento de toda a lista.

Validação: TypeScript, imports, CSS e build aprovados. 147 testes aprovados nas suites de Draft, apresentação, personalização e isolamento por modo; um teste opcional de arquivo externo não executado. Prévia visual no navegador indisponível neste ambiente.

Para Render: substitua o ZIP anterior por este no GitHub, mantendo apenas um ZIP na raiz. Não precisa extrair no Chromebook. Aguarde o deploy e confirme «v55» no canto superior direito.
