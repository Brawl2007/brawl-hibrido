import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { brawlScopeSlugFromName } from "@shared/brawlScopeSlugs";

/**
 * A FILA DE COLAGEM
 *
 * Com o BrawlScope a recusar qualquer servidor, quem traz estes números é uma
 * pessoa — e são 106 brawlers vezes sete vistas. A pessoa não sai do meio; o
 * que sai é o trabalho inútil à volta de cada passagem: escolher o modo de cada
 * vez, carregar num botão, e lembrar-se de cor por onde ia.
 */
const ler = (caminho: string) => readFileSync(resolve(process.cwd(), caminho), "utf-8");

describe("fila de colagem", () => {
  const fila = () => ler("client/src/components/FilaDeColagem.tsx");

  it("o servidor diz QUAIS já foram coladas, não só quantas", () => {
    const counterSync = ler("server/counterSync.ts");
    expect(counterSync).toContain("export function getBrawlScopeColagemFeita");
    const routers = ler("server/routers.ts");
    expect(routers).toMatch(/colagemFeita: publicProcedure/);
  });

  it("guarda assim que se cola, sem botão pelo meio", () => {
    const fonte = fila();
    expect(fonte).toContain("importar.mutate({ html: texto, view: vista })");
    // Guardado dentro de um efeito sobre o texto: é a chegada do texto que
    // dispara, não um clique.
    expect(fonte).toMatch(/useEffect\(\(\) => \{[\s\S]{0,400}importar\.mutate/);
  });

  it("não dispara duas vezes com a mesma colagem", () => {
    const fonte = fila();
    expect(fonte).toContain("importar.isPending) return");
  });

  it("devolve o cursor à caixa depois de guardar", () => {
    expect(fila()).toContain("caixaRef.current?.focus()");
  });

  it("ordena por pontuação, não por alfabeto — parar a meio deixa o melhor feito", () => {
    const fonte = fila();
    expect(fonte).toContain("melhorPontuacao");
    expect(fonte).toMatch(/pontosB - pontosA/);
  });

  it("o endereço da próxima ficha leva o modo escolhido", () => {
    const fonte = fila();
    expect(fonte).toContain("brawlscope.com/counters/");
    expect(fonte).toMatch(/vista === "overall" \? "" : `\?mode=\$\{vista\}`/);
  });

  it("o endereço usa o slug do projeto, com as exceções conhecidas", () => {
    // "Larry & Lawrie" tem um endereço que não sai do nome por regra nenhuma.
    expect(brawlScopeSlugFromName("Larry & Lawrie")).toBe("larry-lawrie");
    expect(brawlScopeSlugFromName("8-Bit")).toBe("8-bit");
    expect(brawlScopeSlugFromName("Mr. P")).toBe("mr-p");
    expect(fila()).toContain("brawlScopeSlugFromName");
  });

  it("não faz um único pedido ao BrawlScope — quem abre a página é a pessoa", () => {
    const fonte = fila();
    expect(fonte).not.toMatch(/\bfetch\s*\(/);
    expect(fonte).not.toMatch(/axios/);
    // A ligação é um <a> que a pessoa carrega, num separador dela.
    expect(fonte).toContain('target="_blank"');
  });

  it("está montada no Draft", () => {
    expect(ler("client/src/pages/Draft.tsx")).toContain("<FilaDeColagem />");
  });
});
