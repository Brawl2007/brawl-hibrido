# Brawl Híbrido v54

Esta versão acrescenta coleta pelo Chrome e importação em lote à Fila de colagem, com progresso salvo e retomada. A fila pode incluir todos os brawlers e as sete vistas do site.

Correção do deploy no Render: a verificação de build compara uma assinatura SHA-256 do código, gravada no final da compilação, em vez das datas dos arquivos do ZIP. Assim, datas futuras não provocam outra compilação na inicialização. Arquivos alterados e assets em falta continuam detectados. Teste: `node --test scripts/ensure-build.test.mjs`.

Para destravar um deploy que já compilou com sucesso: no Render, Settings → Build & Deploy → Start Command, use `node dist/index.js` e salve. Faça o deploy novamente. Ao publicar este ZIP corrigido, também pode usar o comando original `node scripts/ensure-build.mjs && node dist/index.js`.

## Como usar

1. Publique o projeto atualizado seguindo `PUBLICAR.md`.
2. Instale a extensão local da pasta `client/public/brawlscope-helper` conforme o `README.txt` dessa pasta.
3. No Draft, exporte a fila em **Importação em lote**.
4. Carregue a fila na extensão, inicie e exporte os resultados.
5. Importe o JSON no Draft, conectado como dono do site.

A extensão lê páginas abertas normalmente pelo Chrome e pausa diante de bloqueios. Não contorna HTTP 403 ou CAPTCHA. A coleta real ainda precisa ser validada no navegador com o formato atual do BrawlScope.

## Validação desta entrega

- 55 testes de captura/importação e parser passaram.
- 11 testes locais da extensão passaram, com páginas e APIs do Chrome simuladas.
- Verificação TypeScript, imports e tokens CSS passou.
- Build de produção passou.

As fichas são validadas antes da importação; o avanço depende da confirmação de gravação. Deltas publicados, listas de counters e sinergias são preservados. A sincronização e a importação compartilham uma fila de gravação no processo do servidor.

Este ZIP contém o código atualizado. Não publica automaticamente o site nem atualiza dados de produção.
