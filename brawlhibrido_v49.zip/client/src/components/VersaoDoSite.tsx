/**
 * O número da versão, num canto. Ver `shared/version.ts` para o porquê.
 *
 * Fica em cima, à direita. Em baixo ficava debaixo dos avisos que aparecem
 * nesse canto e, no telemóvel, fora do que se vê sem rolar.
 *
 * Não apanha cliques (`pointer-events-none`): serve para ler, nunca para
 * estorvar o que está por baixo.
 */
import { VERSAO_DO_SITE } from "@shared/version";

export default function VersaoDoSite() {
  return (
    <span
      aria-label={`Versão do site ${VERSAO_DO_SITE}`}
      className="pointer-events-none fixed top-1 right-2 z-50 select-none rounded px-1.5 py-0.5 font-mono text-[10px] leading-none text-slate-500/70"
    >
      {VERSAO_DO_SITE}
    </span>
  );
}
