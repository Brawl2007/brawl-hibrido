import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { apenasCriacoes, separarInstrucoes } from "./ensureTables";

/**
 * Ver o cabeçalho de `ensureTables.ts`: num alojamento gratuito não há terminal
 * para correr `pnpm db:push`, e sem tabelas o site guarda tudo em lado nenhum.
 */
const instalador = () => readFileSync(resolve(process.cwd(), "drizzle/criar-tabelas.sql"), "utf-8");

describe("instalador das tabelas no arranque", () => {
  it("lê todas as criações do ficheiro", () => {
    const criacoes = apenasCriacoes(separarInstrucoes(instalador()));
    const noFicheiro = (instalador().match(/CREATE TABLE IF NOT EXISTS/gi) ?? []).length;
    expect(criacoes.length).toBe(noFicheiro);
    expect(criacoes.length).toBeGreaterThan(10);
  });

  it("cria as tabelas de que o site se queixa quando faltam", () => {
    const criacoes = apenasCriacoes(separarInstrucoes(instalador())).join("\n");
    for (const tabela of ["users", "ranked_sync_config", "counter_sync_snapshots", "observed_battles"]) {
      expect(criacoes).toContain(`\`${tabela}\``);
    }
  });

  it("todas usam IF NOT EXISTS — correr no arranque não pode tocar no que já lá está", () => {
    for (const instrucao of apenasCriacoes(separarInstrucoes(instalador()))) {
      expect(instrucao).toMatch(/^CREATE TABLE IF NOT EXISTS/i);
    }
  });

  it("deixa de fora tudo o que não seja criar uma tabela", () => {
    const misturado = [
      "CREATE TABLE IF NOT EXISTS `users` (`id` int);",
      "DROP TABLE `users`;",
      "ALTER TABLE `users` ADD COLUMN `x` int;",
      "TRUNCATE TABLE `users`;",
      "CREATE TABLE `sem_guarda` (`id` int);",
    ].join("\n");
    const passaram = apenasCriacoes(separarInstrucoes(misturado));
    expect(passaram).toHaveLength(1);
    expect(passaram[0]).toContain("IF NOT EXISTS");
  });

  it("o arranque chama o instalador antes de qualquer recolha", () => {
    const liveSync = readFileSync(resolve(process.cwd(), "server/liveSync.ts"), "utf-8");
    expect(liveSync).toContain("ensureTables()");
    expect(liveSync.indexOf("ensureTables()")).toBeLessThan(liveSync.indexOf("runLiveSyncCycle(\"bootstrap\")"));
  });
});
