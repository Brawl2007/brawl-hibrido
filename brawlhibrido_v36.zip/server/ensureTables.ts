/**
 * Criação das tabelas no arranque.
 *
 * POR QUE ISTO EXISTE
 *
 * As tabelas eram criadas por `pnpm db:push`, um comando de terminal. Isso
 * pressupõe que quem publica o site tem terminal — e nos alojamentos gratuitos
 * não tem: há um painel com botões e mais nada. Sem esse comando, o site sobe,
 * abre, e depois falha em tudo o que precise de guardar seja o que for, com
 * `Failed query: select ... from ranked_sync_config`.
 *
 * O ficheiro `drizzle/criar-tabelas.sql` já era seguro de correr as vezes que
 * fossem: só tem `CREATE TABLE IF NOT EXISTS`, nunca altera nem apaga. Sendo
 * assim, não há motivo para exigir uma pessoa a correr à mão uma coisa que o
 * arranque pode fazer sozinho — e é o mesmo que `app_settings` já fazia.
 *
 * Nada aqui é fatal: uma base de dados inacessível deixa o site a servir o
 * catálogo do repositório, que é o comportamento que já existia.
 */

import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { sql } from "drizzle-orm";
import { getDb } from "./db";

let jaCorreu = false;

/** Só para os testes. */
export function resetEnsureTablesForTests() {
  jaCorreu = false;
}

/**
 * As instruções do instalador, uma a uma.
 *
 * Corta pelos `;` no fim de linha — o mesmo critério de `scripts/db-setup.mjs`,
 * para os dois lerem o ficheiro da mesma maneira.
 */
export function separarInstrucoes(conteudo: string): string[] {
  return conteudo
    .split(/;\s*(?:\r?\n|$)/)
    .map((bloco) => bloco.replace(/^\s*--.*$/gm, "").trim())
    .filter((bloco) => bloco.length > 0);
}

/**
 * Só instruções de criação passam.
 *
 * O ficheiro é de confiança, mas este arranque corre sem ninguém a ver e contra
 * a base de dados verdadeira. Um `ALTER` ou um `DROP` que ali aparecesse um dia
 * por engano não vai ser executado às escondidas por causa de um reinício.
 */
export function apenasCriacoes(instrucoes: readonly string[]) {
  return instrucoes.filter((instrucao) => /^CREATE TABLE IF NOT EXISTS/i.test(instrucao));
}

function lerInstalador(): string | undefined {
  const candidatos = [
    resolve(process.cwd(), "drizzle/criar-tabelas.sql"),
    resolve(process.cwd(), "../drizzle/criar-tabelas.sql"),
  ];
  for (const caminho of candidatos) {
    try {
      return readFileSync(caminho, "utf-8");
    } catch {
      // Tenta o caminho seguinte.
    }
  }
  return undefined;
}

export async function ensureTables(): Promise<{ criadas: number; total: number } | undefined> {
  if (jaCorreu) return undefined;
  jaCorreu = true;

  const db = await getDb();
  if (!db) return undefined;

  const conteudo = lerInstalador();
  if (!conteudo) {
    console.warn("[Tabelas] Não encontrei drizzle/criar-tabelas.sql. Se as tabelas faltarem, corre `pnpm db:push`.");
    return undefined;
  }

  const instrucoes = apenasCriacoes(separarInstrucoes(conteudo));
  let criadas = 0;
  for (const instrucao of instrucoes) {
    try {
      await db.execute(sql.raw(instrucao));
      criadas += 1;
    } catch (error) {
      // Uma tabela que já exista não chega aqui (o IF NOT EXISTS trata disso);
      // o que chega é um problema real de permissões ou de sintaxe, e vale mais
      // registá-lo e continuar do que impedir o site de arrancar.
      console.warn("[Tabelas] Instrução falhou:", error instanceof Error ? error.message : error);
    }
  }

  console.log(`[Tabelas] Instalador corrido: ${criadas} de ${instrucoes.length} instruções sem erro.`);
  return { criadas, total: instrucoes.length };
}
